# Position Monitor Service - US Markets (dev_claude)

**Name of Application:** Catalyst Trading System  
**Name of file:** position-monitor-service-us-design.md  
**Version:** 1.0.0  
**Last Updated:** 2026-01-16  
**Purpose:** Persistent systemd service for continuous US position monitoring

---

## REVISION HISTORY

- **v1.0.0 (2026-01-16)** - Initial implementation for US markets
  - Adapted from HKEX version for US markets
  - Alpaca broker integration
  - US market hours (9:30 AM - 4:00 PM ET, continuous)
  - dev_claude consciousness integration

---

## 1. Executive Summary

This document describes the Position Monitor Service for US markets. The service runs as a persistent systemd daemon, continuously monitoring all open positions during market hours and executing exits when signals indicate.

### Key Differences from HKEX Version

| Aspect | HKEX (intl_claude) | US (dev_claude) |
|--------|---------------------|-----------------|
| **Timezone** | Asia/Hong_Kong | America/New_York |
| **Market Hours** | 9:30-12:00, 13:00-16:00 HKT | 9:30-16:00 ET |
| **Lunch Break** | Yes (12:00-13:00) | No |
| **Broker** | Moomoo | Alpaca |
| **Database** | catalyst_intl | catalyst_dev |
| **Directory** | `/root/Catalyst-Trading-System-International/catalyst-international` | `/root/catalyst-dev` |
| **Agent ID** | intl_claude | dev_claude |
| **Currency** | HKD | USD |
| **Stop Loss (Strong)** | -3% | -5% |
| **Take Profit (Strong)** | +8% | +10% |
| **Trailing Stop** | 2% | 3% |

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Position Monitor Service                      │
│                         (systemd daemon)                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌──────────────┐    ┌──────────────┐    ┌──────────────┐     │
│   │   Database   │    │    Alpaca    │    │  Anthropic   │     │
│   │  (asyncpg)   │    │   (alpaca-py)│    │   (Haiku)    │     │
│   └──────┬───────┘    └──────┬───────┘    └──────┬───────┘     │
│          │                   │                   │              │
│          ▼                   ▼                   ▼              │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │              Signal Detection Engine                     │  │
│   │                                                          │  │
│   │   • Stop Loss (Strong: -5%, Moderate: -3%)              │  │
│   │   • Take Profit (Strong: +10%, Moderate: +6%)           │  │
│   │   • Trailing Stop (3% from high)                        │  │
│   │   • RSI (Overbought: 85/75)                             │  │
│   │   • Volume Collapse (25%/40%)                           │  │
│   │   • Time-based (Near Close)                             │  │
│   └─────────────────────────────────────────────────────────┘  │
│                           │                                     │
│                           ▼                                     │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                  Decision Flow                           │  │
│   │                                                          │  │
│   │   STRONG signal  ─────────────────────────▶  EXIT NOW   │  │
│   │   MODERATE signal ─────▶ Consult Haiku ─▶ EXIT/HOLD     │  │
│   │   WEAK signal    ─────────────────────────▶  HOLD       │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Consciousness Framework                       │
│                     (catalyst_research DB)                       │
│                                                                  │
│   • Exit notifications to big_bro                               │
│   • Observations recorded for learning                          │
│   • Service health monitoring                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Market Hours

### US Markets (NYSE/NASDAQ)

```
Pre-Market:      4:00 AM - 9:30 AM ET  (not monitored)
Regular Hours:   9:30 AM - 4:00 PM ET  (ACTIVE)
After Hours:     4:00 PM - 8:00 PM ET  (not monitored)
```

**Key Points:**
- No lunch break (continuous trading)
- Service sleeps outside regular hours
- Weekend detection (Saturday/Sunday)

### Time-Based Signals

| Time (ET) | Signal | Strength | Action |
|-----------|--------|----------|--------|
| 3:45 PM - 4:00 PM | Near Close | STRONG | Exit immediately |
| 3:00 PM - 3:30 PM | Power Hour | WEAK | Warning only |

---

## 4. Signal Thresholds

### P&L Signals (adjusted for US volatility)

| Signal | Threshold | Strength | Action |
|--------|-----------|----------|--------|
| Stop Loss | ≤ -5% | STRONG | Exit immediately |
| Stop Loss | ≤ -3% | MODERATE | Consult Haiku |
| Stop Loss | ≤ -2% | WEAK | Monitor |
| Take Profit | ≥ +10% | STRONG | Exit immediately |
| Take Profit | ≥ +6% | MODERATE | Consult Haiku |

### Technical Signals

| Signal | Threshold | Strength |
|--------|-----------|----------|
| RSI Overbought | ≥ 85 | STRONG |
| RSI Overbought | ≥ 75 | MODERATE |
| Volume Collapse | ≤ 25% of entry | STRONG |
| Volume Collapse | ≤ 40% of entry | MODERATE |
| Trailing Stop | ≥ 3% from high | MODERATE |
| MACD Bearish | < -0.5 | MODERATE |

---

## 5. File Structure

```
/root/catalyst-dev/
├── position_monitor_service.py    # Main service (this file)
├── unified_agent.py               # Main trading agent
├── signals.py                     # Signal detection (shared)
├── position_monitor.py            # Trade-triggered monitor (existing)
├── config/
│   └── dev_claude_config.yaml
├── venv/                          # Python virtual environment
├── logs/                          # Agent logs
└── .env                           # Environment variables
```

---

## 6. Environment Variables

```bash
# Required
DATABASE_URL=postgresql://...catalyst_dev?sslmode=require
ALPACA_API_KEY=PKxxx
ALPACA_SECRET_KEY=xxx
ALPACA_BASE_URL=https://paper-api.alpaca.markets

# Optional
RESEARCH_DATABASE_URL=postgresql://...catalyst_research?sslmode=require
ANTHROPIC_API_KEY=sk-ant-...
MONITOR_CHECK_INTERVAL=300      # Check every 5 minutes (default)
MONITOR_DRY_RUN=false           # Set to 'true' for testing
```

---

## 7. Installation

### Quick Install

```bash
# 1. Upload files to server
scp position_monitor_service.py position-monitor-us.service install-position-monitor-us.sh root@catalyst-dev:/tmp/

# 2. SSH to server
ssh root@catalyst-dev

# 3. Run install script
cd /tmp
chmod +x install-position-monitor-us.sh
./install-position-monitor-us.sh
```

### Manual Install

```bash
# 1. Copy Python script
cp position_monitor_service.py /root/catalyst-dev/
chmod +x /root/catalyst-dev/position_monitor_service.py

# 2. Install systemd service
cp position-monitor-us.service /etc/systemd/system/
chmod 644 /etc/systemd/system/position-monitor-us.service

# 3. Apply database schema (if needed)
psql -h <host> -U <user> -d catalyst_dev -f position_monitor_service_schema.sql

# 4. Enable and start service
systemctl daemon-reload
systemctl enable position-monitor-us
systemctl start position-monitor-us
```

---

## 8. Operations

### Service Management

```bash
# Start service
systemctl start position-monitor-us

# Stop service
systemctl stop position-monitor-us

# Restart service
systemctl restart position-monitor-us

# Check status
systemctl status position-monitor-us

# View live logs
journalctl -u position-monitor-us -f

# View last 100 lines
journalctl -u position-monitor-us -n 100

# View logs since specific time
journalctl -u position-monitor-us --since "1 hour ago"
```

### Dry Run Testing

```bash
# Set dry run mode in .env
echo "MONITOR_DRY_RUN=true" >> /root/catalyst-dev/.env

# Restart service
systemctl restart position-monitor-us

# Watch logs - exits will be logged but not executed
journalctl -u position-monitor-us -f
```

---

## 9. Monitoring

### Service Health Table

The service updates the `service_health` table in `catalyst_dev`:

```sql
SELECT * FROM service_health WHERE service_name = 'position_monitor_us';
```

Fields:
- `status` - running/stopped/error
- `last_heartbeat` - Last successful check
- `last_check_count` - Total monitoring cycles
- `positions_monitored` - Total positions checked
- `exits_executed` - Total exits executed
- `haiku_calls` - Total AI consultations

### Consciousness Messages

Exit notifications are sent to `big_bro` via the consciousness framework:

```sql
SELECT * FROM claude_messages 
WHERE from_agent = 'dev_claude' 
ORDER BY created_at DESC 
LIMIT 10;
```

---

## 10. Troubleshooting

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| Service won't start | Missing .env | Check `journalctl -u position-monitor-us -n 50` |
| No quotes returned | Alpaca connection | Verify API keys in .env |
| Haiku not working | Missing API key | Add ANTHROPIC_API_KEY to .env |
| No positions found | Empty database | Normal if no open positions |

### Log Analysis

```bash
# Find errors
journalctl -u position-monitor-us | grep -i error

# Find exits
journalctl -u position-monitor-us | grep "Exit complete"

# Find Haiku decisions
journalctl -u position-monitor-us | grep "Haiku says"
```

---

## 11. Dependencies

### Python Packages

```
alpaca-py>=0.43.0
asyncpg>=0.31.0
anthropic>=0.76.0  (optional, for Haiku)
```

### Install Dependencies

```bash
source /root/catalyst-dev/venv/bin/activate
pip install alpaca-py asyncpg anthropic
```

---

## 12. Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-01-16 | Initial US implementation |

---

## 13. Related Documents

- `position-monitor-service-design.md` - HKEX version (original)
- `dev_claude_us_implementation.md` - dev_claude agent design
- `current-architecture.md` - System architecture
- `database-schema.md` - Full database schema

---

*Document created by Claude for the Catalyst Trading System*
