#!/usr/bin/env python3
"""
Name of Application: Catalyst Trading System
Name of file: alpaca_helper.py
Version: 1.0.0
Last Updated: 2026-02-01
Purpose: Minimal Python helper for complex Alpaca operations

REVISION HISTORY:
v1.0.0 (2026-02-01) - Initial implementation
  - Bracket order support
  - Historical data fetching
  - Called from bash scripts when needed

Usage:
  python3 helpers/alpaca_helper.py bracket AAPL buy 10 175.00 170.00 185.00
  python3 helpers/alpaca_helper.py history AAPL 30
"""

import os
import sys
import json
from datetime import datetime, timedelta

# Alpaca SDK (if available) or requests fallback
try:
    from alpaca.trading.client import TradingClient
    from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
    from alpaca.trading.enums import OrderSide, TimeInForce, OrderClass
    from alpaca.data import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame
    ALPACA_SDK = True
except ImportError:
    import requests
    ALPACA_SDK = False


def get_env():
    """Load environment variables."""
    return {
        'api_key': os.environ.get('ALPACA_API_KEY'),
        'secret_key': os.environ.get('ALPACA_SECRET_KEY'),
        'base_url': os.environ.get('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')
    }


def bracket_order(symbol: str, side: str, qty: int, entry_price: float, stop_price: float, take_profit: float):
    """
    Submit a bracket order (entry + stop loss + take profit).
    
    This is more complex than a simple market order, so we use Python.
    """
    env = get_env()
    
    if ALPACA_SDK:
        client = TradingClient(env['api_key'], env['secret_key'], paper=True)
        
        order_side = OrderSide.BUY if side.lower() == 'buy' else OrderSide.SELL
        
        # Bracket order request
        order_data = {
            'symbol': symbol,
            'qty': qty,
            'side': order_side,
            'type': 'limit',
            'limit_price': entry_price,
            'time_in_force': TimeInForce.DAY,
            'order_class': OrderClass.BRACKET,
            'stop_loss': {'stop_price': stop_price},
            'take_profit': {'limit_price': take_profit}
        }
        
        try:
            order = client.submit_order(order_data)
            print(json.dumps({
                'status': 'submitted',
                'order_id': str(order.id),
                'symbol': symbol,
                'qty': qty,
                'entry': entry_price,
                'stop': stop_price,
                'target': take_profit
            }, indent=2))
        except Exception as e:
            print(json.dumps({'status': 'error', 'message': str(e)}))
            sys.exit(1)
    else:
        # Fallback to REST API
        headers = {
            'APCA-API-KEY-ID': env['api_key'],
            'APCA-API-SECRET-KEY': env['secret_key'],
            'Content-Type': 'application/json'
        }
        
        data = {
            'symbol': symbol,
            'qty': str(qty),
            'side': side.lower(),
            'type': 'limit',
            'limit_price': str(entry_price),
            'time_in_force': 'day',
            'order_class': 'bracket',
            'stop_loss': {'stop_price': str(stop_price)},
            'take_profit': {'limit_price': str(take_profit)}
        }
        
        response = requests.post(
            f"{env['base_url']}/v2/orders",
            headers=headers,
            json=data
        )
        
        if response.status_code == 200:
            order = response.json()
            print(json.dumps({
                'status': 'submitted',
                'order_id': order['id'],
                'symbol': symbol,
                'qty': qty,
                'entry': entry_price,
                'stop': stop_price,
                'target': take_profit
            }, indent=2))
        else:
            print(json.dumps({
                'status': 'error',
                'message': response.json().get('message', 'Unknown error')
            }))
            sys.exit(1)


def get_history(symbol: str, days: int = 30):
    """
    Get historical daily bars for a symbol.
    
    Used for more detailed analysis than the bash scripts provide.
    """
    env = get_env()
    
    end = datetime.now()
    start = end - timedelta(days=days)
    
    if ALPACA_SDK:
        client = StockHistoricalDataClient(env['api_key'], env['secret_key'])
        
        request = StockBarsRequest(
            symbol_or_symbols=symbol,
            timeframe=TimeFrame.Day,
            start=start,
            end=end
        )
        
        bars = client.get_stock_bars(request)
        
        result = []
        for bar in bars[symbol]:
            result.append({
                'date': bar.timestamp.strftime('%Y-%m-%d'),
                'open': float(bar.open),
                'high': float(bar.high),
                'low': float(bar.low),
                'close': float(bar.close),
                'volume': int(bar.volume)
            })
        
        print(json.dumps(result, indent=2))
    else:
        # Fallback to REST API
        headers = {
            'APCA-API-KEY-ID': env['api_key'],
            'APCA-API-SECRET-KEY': env['secret_key']
        }
        
        response = requests.get(
            f"{env['base_url']}/v2/stocks/{symbol}/bars",
            headers=headers,
            params={
                'timeframe': '1Day',
                'start': start.isoformat() + 'Z',
                'end': end.isoformat() + 'Z',
                'limit': days,
                'feed': 'iex'
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            result = []
            for bar in data.get('bars', []):
                result.append({
                    'date': bar['t'][:10],
                    'open': bar['o'],
                    'high': bar['h'],
                    'low': bar['l'],
                    'close': bar['c'],
                    'volume': bar['v']
                })
            print(json.dumps(result, indent=2))
        else:
            print(json.dumps({
                'status': 'error',
                'message': response.json().get('message', 'Unknown error')
            }))
            sys.exit(1)


def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python3 alpaca_helper.py bracket SYMBOL SIDE QTY ENTRY STOP TARGET")
        print("  python3 alpaca_helper.py history SYMBOL [DAYS]")
        sys.exit(1)
    
    command = sys.argv[1].lower()
    
    if command == 'bracket':
        if len(sys.argv) != 8:
            print("Usage: python3 alpaca_helper.py bracket SYMBOL SIDE QTY ENTRY STOP TARGET")
            sys.exit(1)
        bracket_order(
            symbol=sys.argv[2].upper(),
            side=sys.argv[3],
            qty=int(sys.argv[4]),
            entry_price=float(sys.argv[5]),
            stop_price=float(sys.argv[6]),
            take_profit=float(sys.argv[7])
        )
    
    elif command == 'history':
        if len(sys.argv) < 3:
            print("Usage: python3 alpaca_helper.py history SYMBOL [DAYS]")
            sys.exit(1)
        days = int(sys.argv[3]) if len(sys.argv) > 3 else 30
        get_history(sys.argv[2].upper(), days)
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == '__main__':
    main()
