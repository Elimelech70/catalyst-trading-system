#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: log.sh
# Version: 1.1.0
# Last Updated: 2026-02-01
# Purpose: Log messages to agent_logs table with trading state context
#
# REVISION HISTORY:
# v1.1.0 (2026-02-01) - Added trading state awareness, enhanced context
# v1.0.0 (2026-02-01) - Initial implementation
#
# Usage: ./tools/log.sh "INFO" "Message here"
#        ./tools/log.sh "TRADE" "BUY 10 AAPL @ $175.50" "AAPL"
#
# Levels:
#   INFO        - General information
#   TRADE       - Trade execution (include symbol as 3rd arg)
#   SCAN        - Scan results and candidates
#   OBSERVATION - Pattern/behavior noticed (feeds to consciousness)
#   LEARNING    - Validated insight (feeds to consciousness)
#   QUESTION    - Something to investigate
#   DECISION    - Trading decision made (and why)
#   ALERT       - Needs attention
#   ERROR       - Something went wrong
#   HELP        - Stuck, needs manual intervention
#   STATE       - Trading state transition
#   EOD         - End of day summary
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: ./tools/log.sh LEVEL MESSAGE [SYMBOL]"
    echo ""
    echo "Levels:"
    echo "  INFO        - General information"
    echo "  TRADE       - Trade execution (add symbol as 3rd arg)"
    echo "  SCAN        - Scan results and candidates"
    echo "  OBSERVATION - Something noticed (feeds to consciousness)"
    echo "  LEARNING    - Validated insight (feeds to consciousness)"
    echo "  QUESTION    - Something to investigate"
    echo "  DECISION    - Trading decision and rationale"
    echo "  ALERT       - Needs attention"
    echo "  ERROR       - Something went wrong"
    echo "  HELP        - Stuck, needs manual intervention"
    echo "  STATE       - Trading state transition"
    echo "  EOD         - End of day summary"
    echo ""
    echo "Examples:"
    echo "  ./tools/log.sh INFO 'Pre-market scan complete, watching AAPL'"
    echo "  ./tools/log.sh TRADE 'BUY 10 @ \$175.50' AAPL"
    echo "  ./tools/log.sh DECISION 'Skipping NVDA - RSI too high at 78'"
    echo "  ./tools/log.sh OBSERVATION 'Breakouts work better after 10:30 AM'"
    exit 1
fi

LEVEL=$(echo "$1" | tr '[:lower:]' '[:upper:]')
MESSAGE="$2"
SYMBOL="${3:-}"

# Escape single quotes in message for SQL
MESSAGE_ESCAPED=$(echo "$MESSAGE" | sed "s/'/''/g")

# Get current trading state
STATE_JSON=$("$SCRIPT_DIR/state.sh" --json 2>/dev/null || echo '{"state":"UNKNOWN","time_est":"00:00"}')
TRADING_STATE=$(echo "$STATE_JSON" | jq -r '.state // "UNKNOWN"')
TIME_EST=$(echo "$STATE_JSON" | jq -r '.time_est // "00:00"')
DATE_EST=$(echo "$STATE_JSON" | jq -r '.date // "unknown"')

# Build context JSON with state info
if [ -n "$SYMBOL" ]; then
    CONTEXT=$(cat <<EOF
{
  "agent": "dev_claude",
  "architecture": "claude_code",
  "level": "$LEVEL",
  "trading_state": "$TRADING_STATE",
  "time_est": "$TIME_EST",
  "date": "$DATE_EST",
  "symbol": "$SYMBOL"
}
EOF
)
else
    CONTEXT=$(cat <<EOF
{
  "agent": "dev_claude",
  "architecture": "claude_code",
  "level": "$LEVEL",
  "trading_state": "$TRADING_STATE",
  "time_est": "$TIME_EST",
  "date": "$DATE_EST"
}
EOF
)
fi

# Minify JSON for SQL
CONTEXT_MIN=$(echo "$CONTEXT" | tr -d '\n' | tr -s ' ')

# Insert into agent_logs
psql "$DATABASE_URL" -q -c "
INSERT INTO agent_logs (level, source, message, context, timestamp)
VALUES ('$LEVEL', 'dev_claude', '$MESSAGE_ESCAPED', '$CONTEXT_MIN'::jsonb, NOW())
"

# Also log to local file for immediate review
LOG_FILE="$SCRIPT_DIR/../logs/trading.log"
mkdir -p "$SCRIPT_DIR/../logs"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$TIMESTAMP] [$TRADING_STATE] $LEVEL: $MESSAGE" >> "$LOG_FILE"

# Echo confirmation with state context
echo "[$TIME_EST EST] [$TRADING_STATE] $LEVEL: $MESSAGE"

# Special handling based on level and state
case "$LEVEL" in
    OBSERVATION|LEARNING|QUESTION)
        echo "  -> Logged for consciousness framework"
        ;;
    TRADE)
        if [ "$TRADING_STATE" != "TRADING" ]; then
            echo "  -> WARNING: Trade logged outside TRADING state ($TRADING_STATE)"
        fi
        ;;
    DECISION)
        echo "  -> Decision recorded for analysis"
        ;;
    ALERT|ERROR|HELP)
        echo "  -> Review recommended"
        ;;
    EOD)
        echo "  -> End of day summary recorded"
        ;;
    STATE)
        echo "  -> State transition logged"
        ;;
esac

# State-specific warnings
case "$TRADING_STATE" in
    MARKET_CLOSED)
        if [ "$LEVEL" = "TRADE" ]; then
            echo "  -> ERROR: Cannot trade when market is closed!"
        fi
        ;;
    PRE_MARKET)
        if [ "$LEVEL" = "TRADE" ]; then
            echo "  -> WARNING: Trade during pre-market - verify this is allowed"
        fi
        ;;
    MARKET_OPENING)
        if [ "$LEVEL" = "TRADE" ]; then
            echo "  -> CAUTION: Trading in first 30 min - high volatility"
        fi
        ;;
    MARKET_CLOSING)
        if [ "$LEVEL" = "TRADE" ] && [[ "$MESSAGE" == *"BUY"* ]]; then
            echo "  -> WARNING: Opening position during market close - consider waiting"
        fi
        ;;
esac
