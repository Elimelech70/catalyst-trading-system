#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: deploy.sh
# Version: 1.1.0
# Last Updated: 2026-02-01
# Purpose: Deploy dev_claude Claude Code agent to US droplet
#
# REVISION HISTORY:
# v1.1.0 (2026-02-01) - Added state.sh deployment
# v1.0.0 (2026-02-01) - Initial implementation
#
# Usage: ./deploy.sh
# ============================================================================

set -e

echo "=== Deploying dev_claude Claude Code Agent v1.1.0 ==="
echo ""

# Check if we're on the target droplet
if [ ! -d "/root" ]; then
    echo "ERROR: This script should be run on the US droplet as root"
    exit 1
fi

# Create directory structure
echo "Creating directory structure..."
mkdir -p /root/catalyst-dev/{tools,helpers,config,logs,sql}

# Copy files
echo "Copying files..."

# CLAUDE.md (the brain)
if [ -f "CLAUDE.md" ]; then
    cp CLAUDE.md /root/catalyst-dev/
    echo "  ✓ CLAUDE.md"
fi

# README
if [ -f "README.md" ]; then
    cp README.md /root/catalyst-dev/
    echo "  ✓ README.md"
fi

# Tools (including new state.sh)
TOOLS="state scan quote technicals patterns news portfolio account check-risk trade close close-all log"
for tool in $TOOLS; do
    if [ -f "${tool}.sh" ]; then
        cp "${tool}.sh" /root/catalyst-dev/tools/
        echo "  ✓ tools/${tool}.sh"
    elif [ -f "tools/${tool}.sh" ]; then
        cp "tools/${tool}.sh" /root/catalyst-dev/tools/
        echo "  ✓ tools/${tool}.sh"
    fi
done

# Make tools executable
chmod +x /root/catalyst-dev/tools/*.sh

# Helpers
if [ -f "alpaca_helper.py" ]; then
    cp alpaca_helper.py /root/catalyst-dev/helpers/
    echo "  ✓ helpers/alpaca_helper.py"
elif [ -f "helpers/alpaca_helper.py" ]; then
    cp helpers/alpaca_helper.py /root/catalyst-dev/helpers/
    echo "  ✓ helpers/alpaca_helper.py"
fi

# Config
if [ -f "limits.yaml" ]; then
    cp limits.yaml /root/catalyst-dev/config/
    echo "  ✓ config/limits.yaml"
elif [ -f "config/limits.yaml" ]; then
    cp config/limits.yaml /root/catalyst-dev/config/
    echo "  ✓ config/limits.yaml"
fi

if [ -f ".env.example" ]; then
    cp .env.example /root/catalyst-dev/config/
    echo "  ✓ config/.env.example"
elif [ -f "config/.env.example" ]; then
    cp config/.env.example /root/catalyst-dev/config/
    echo "  ✓ config/.env.example"
fi

# Cron file
if [ -f "catalyst-dev-claude-code.cron" ]; then
    cp catalyst-dev-claude-code.cron /root/catalyst-dev/config/
    echo "  ✓ config/catalyst-dev-claude-code.cron"
elif [ -f "config/catalyst-dev-claude-code.cron" ]; then
    cp config/catalyst-dev-claude-code.cron /root/catalyst-dev/config/
    echo "  ✓ config/catalyst-dev-claude-code.cron"
fi

# Check for existing .env
if [ ! -f "/root/catalyst-dev/config/.env" ]; then
    echo ""
    echo "⚠️  No .env file found. Creating from template..."
    cp /root/catalyst-dev/config/.env.example /root/catalyst-dev/config/.env
    echo "   IMPORTANT: Edit /root/catalyst-dev/config/.env with your credentials!"
fi

# Install dependencies
echo ""
echo "Installing Python dependencies..."
pip3 install requests pyyaml --break-system-packages 2>/dev/null || pip3 install requests pyyaml

# Optional: Install Alpaca SDK
echo "Installing Alpaca SDK (optional)..."
pip3 install alpaca-py --break-system-packages 2>/dev/null || pip3 install alpaca-py || echo "  (Alpaca SDK optional - will use REST API fallback)"

# Verify jq is installed (for bash JSON parsing)
if ! command -v jq &> /dev/null; then
    echo "Installing jq..."
    apt-get update && apt-get install -y jq
else
    echo "  ✓ jq already installed"
fi

# Verify bc is installed (for math)
if ! command -v bc &> /dev/null; then
    echo "Installing bc..."
    apt-get install -y bc
else
    echo "  ✓ bc already installed"
fi

# Verify psql is installed
if ! command -v psql &> /dev/null; then
    echo "Installing postgresql-client..."
    apt-get install -y postgresql-client
else
    echo "  ✓ postgresql-client already installed"
fi

# Install cron schedule (optional)
echo ""
read -p "Install cron schedule for autonomous trading? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    if [ -f "/root/catalyst-dev/config/catalyst-dev-claude-code.cron" ]; then
        cp /root/catalyst-dev/config/catalyst-dev-claude-code.cron /etc/cron.d/catalyst-dev-claude-code
        chmod 644 /etc/cron.d/catalyst-dev-claude-code
        systemctl restart cron
        echo "✅ Cron schedule installed"
    else
        echo "⚠️  Cron file not found"
    fi
fi

# Verify Claude Code is installed
echo ""
if command -v claude &> /dev/null; then
    echo "✅ Claude Code CLI found"
else
    echo "⚠️  Claude Code CLI not found"
    echo "   Install from: https://github.com/anthropics/claude-code"
fi

# Test state tool
echo ""
echo "Testing state.sh..."
cd /root/catalyst-dev
source config/.env 2>/dev/null || true
if ./tools/state.sh > /dev/null 2>&1; then
    echo "✅ state.sh working"
    ./tools/state.sh
else
    echo "⚠️  state.sh test failed - check configuration"
fi

# Summary
echo ""
echo "=== Deployment Complete ==="
echo ""
echo "Directory: /root/catalyst-dev/"
echo ""
echo "Files:"
ls -la /root/catalyst-dev/
echo ""
echo "Tools:"
ls -la /root/catalyst-dev/tools/
echo ""
echo "Next steps:"
echo "  1. Edit /root/catalyst-dev/config/.env with your Alpaca credentials"
echo "  2. Test state: cd /root/catalyst-dev && ./tools/state.sh"
echo "  3. Test tools: source config/.env && ./tools/account.sh"
echo "  4. Run Claude Code: cd /root/catalyst-dev && claude"
echo ""
echo "Manual test sequence:"
echo "  ./tools/state.sh      # Check trading state"
echo "  ./tools/account.sh    # Check account"
echo "  ./tools/scan.sh       # Scan market"
echo "  ./tools/quote.sh AAPL # Get quote"
echo "  ./tools/portfolio.sh  # Check positions"
