#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: log.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Log messages to agent_logs table in database
#
# Usage: ./tools/log.sh "INFO" "Message here"
# Levels: INFO, TRADE, OBSERVATION, LEARNING, QUESTION, ALERT, ERROR, HELP
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: ./tools/log.sh LEVEL MESSAGE"
    echo ""
    echo "Levels:"
    echo "  INFO        - General information"
    echo "  TRADE       - Trade execution"
    echo "  OBSERVATION - Something noticed (feeds to consciousness)"
    echo "  LEARNING    - Validated insight (feeds to consciousness)"
    echo "  QUESTION    - Something to investigate"
    echo "  ALERT       - Needs attention"
    echo "  ERROR       - Something went wrong"
    echo "  HELP        - Stuck, needs manual intervention"
    echo ""
    echo "Example: ./tools/log.sh INFO 'Pre-market scan complete, watching AAPL'"
    exit 1
fi

LEVEL=$(echo "$1" | tr '[:lower:]' '[:upper:]')
MESSAGE="$2"

# Escape single quotes in message for SQL
MESSAGE_ESCAPED=$(echo "$MESSAGE" | sed "s/'/''/g")

# Build context JSON
CONTEXT="{\"agent\": \"dev_claude\", \"architecture\": \"claude_code\", \"level\": \"$LEVEL\"}"

# Insert into agent_logs
psql "$DATABASE_URL" -q -c "
INSERT INTO agent_logs (level, source, message, context, timestamp)
VALUES ('$LEVEL', 'dev_claude', '$MESSAGE_ESCAPED', '$CONTEXT'::jsonb, NOW())
"

# Echo confirmation
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$TIMESTAMP] $LEVEL: $MESSAGE"

# Special handling for consciousness-related levels
case "$LEVEL" in
    OBSERVATION|LEARNING|QUESTION)
        echo "  → Logged for consciousness framework"
        ;;
    ALERT|ERROR|HELP)
        echo "  → ⚠️  Review recommended"
        ;;
esac
