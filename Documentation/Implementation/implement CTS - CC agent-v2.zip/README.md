# dev_claude - Claude Code Trading Agent

**Name of Application:** Catalyst Trading System  
**Name of file:** README.md  
**Version:** 1.0.0  
**Last Updated:** 2026-02-01  
**Purpose:** Claude Code agent for US market paper trading

---

## Overview

dev_claude is an **experimental** trading agent that uses **Claude Code** (not Python) as its execution engine. This is a fundamentally different architecture from intl_claude (Python Agent).

| Aspect | dev_claude (This) | intl_claude |
|--------|-------------------|-------------|
| Execution | Claude Code + Bash | Python + Claude API |
| Control | AI autonomous | Programmatic |
| Codebase | ~400 lines | ~1,200 lines |
| Market | US (Paper) | HKEX (Real) |
| Trust Level | High | Lower |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     CLAUDE CODE                                  │
│                  (Execution Engine)                              │
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                    CLAUDE.md                             │   │
│   │                   (The Brain)                            │   │
│   │                                                          │   │
│   │  • Identity & mission                                    │   │
│   │  • Hard constraints                                      │   │
│   │  • Available tools                                       │   │
│   │  • Trading strategy                                      │   │
│   │  • Error handling                                        │   │
│   │  • Learning objectives                                   │   │
│   └─────────────────────────────────────────────────────────┘   │
│                            │                                     │
│                            ▼                                     │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                   BASH TOOLS                             │   │
│   │                                                          │   │
│   │  scan.sh     quote.sh    technicals.sh   news.sh        │   │
│   │  portfolio.sh account.sh check-risk.sh                   │   │
│   │  trade.sh    close.sh    close-all.sh    log.sh         │   │
│   │                                                          │   │
│   └─────────────────────────────────────────────────────────┘   │
│                            │                                     │
└────────────────────────────┼─────────────────────────────────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
        ┌──────────┐  ┌──────────┐  ┌──────────┐
        │  ALPACA  │  │  MARKET  │  │ DATABASE │
        │  (Paper) │  │  DATA    │  │  (logs)  │
        └──────────┘  └──────────┘  └──────────┘
```

## File Structure

```
/root/catalyst-dev/
├── CLAUDE.md                 # The brain - all instructions
├── tools/
│   ├── scan.sh               # Market scanner
│   ├── quote.sh              # Get quote
│   ├── technicals.sh         # RSI, MACD, MAs
│   ├── patterns.sh           # Chart pattern detection
│   ├── news.sh               # News headlines
│   ├── portfolio.sh          # Current positions
│   ├── account.sh            # Account balance
│   ├── check-risk.sh         # Risk validation
│   ├── trade.sh              # Execute order
│   ├── close.sh              # Close position
│   ├── close-all.sh          # Emergency close all
│   └── log.sh                # Log to database
├── helpers/
│   └── alpaca_helper.py      # Complex operations
├── config/
│   ├── .env                  # Credentials
│   └── limits.yaml           # Risk limits
└── logs/                     # Local logs
```

## Quick Start

### 1. Deploy

```bash
# On US droplet
git clone <repo> /tmp/catalyst-dev
cd /tmp/catalyst-dev
./deploy.sh
```

### 2. Configure

```bash
# Edit credentials
vim /root/catalyst-dev/config/.env

# Add your Alpaca keys:
# ALPACA_API_KEY=PKxxxx
# ALPACA_SECRET_KEY=xxxx
```

### 3. Test Tools

```bash
cd /root/catalyst-dev
source config/.env

# Test account connection
./tools/account.sh

# Test market scan
./tools/scan.sh

# Test quote
./tools/quote.sh AAPL
```

### 4. Run Claude Code

```bash
cd /root/catalyst-dev
claude
```

Claude Code will read CLAUDE.md and understand its role, constraints, and available tools.

## Hard Constraints

These are enforced in CLAUDE.md and check-risk.sh:

| Constraint | Value |
|------------|-------|
| Account Type | Paper trading ONLY |
| Max Positions | 5 |
| Max Position Value | $1,000 |
| Daily Loss Limit | $500 |
| Stop Loss | 3% |
| Blocked | Short selling, options, margin |

## Tools Reference

### Market Data

| Tool | Usage | Output |
|------|-------|--------|
| `scan.sh` | `./tools/scan.sh` | Top movers table |
| `quote.sh` | `./tools/quote.sh AAPL` | Bid/ask, last price |
| `technicals.sh` | `./tools/technicals.sh AAPL` | RSI, MAs, trend |
| `patterns.sh` | `./tools/patterns.sh AAPL` | Chart patterns (breakout, bull flag, etc.) |
| `news.sh` | `./tools/news.sh AAPL` | Recent headlines |

### Portfolio

| Tool | Usage | Output |
|------|-------|--------|
| `portfolio.sh` | `./tools/portfolio.sh` | Open positions |
| `account.sh` | `./tools/account.sh` | Balance, equity |

### Trading

| Tool | Usage | Output |
|------|-------|--------|
| `check-risk.sh` | `./tools/check-risk.sh AAPL buy 10` | Pass/fail |
| `trade.sh` | `./tools/trade.sh AAPL buy 10` | Order confirmation |
| `close.sh` | `./tools/close.sh AAPL` | Close confirmation |
| `close-all.sh` | `./tools/close-all.sh` | Emergency close |

### Logging

| Tool | Usage | Levels |
|------|-------|--------|
| `log.sh` | `./tools/log.sh INFO "message"` | INFO, TRADE, OBSERVATION, LEARNING, QUESTION, ALERT, ERROR, HELP |

## Cron Schedule

US Market Hours (EST → UTC):

| Time (EST) | Time (UTC) | Action |
|------------|------------|--------|
| 08:00 | 13:00 | Pre-market scan |
| 09:30 | 14:30 | Market open |
| 10:00-15:00 | 15:00-20:00 | Hourly check-ins |
| 16:00 | 21:00 | Market close, EOD review |

Install cron:
```bash
cp config/catalyst-dev-claude-code.cron /etc/cron.d/
chmod 644 /etc/cron.d/catalyst-dev-claude-code
systemctl restart cron
```

## Learning Flow

```
dev_claude observes pattern
     │
     ▼
./tools/log.sh OBSERVATION "NVDA breakouts work in first 30min"
     │
     ▼
Logged to agent_logs (catalyst_dev)
     │
     ▼
big_bro reads agent_logs
     │
     ▼
If validated → becomes claude_learning
     │
     ▼
May be promoted to intl_claude production strategy
```

## Comparison: Claude Code vs Python Agent

| Aspect | Claude Code (dev_claude) | Python Agent (intl_claude) |
|--------|--------------------------|----------------------------|
| Decision Making | AI decides what to do | Python loops + API calls |
| Tool Execution | Bash scripts | Python functions |
| Error Handling | AI self-corrects | Try/except in code |
| Complexity | Simple (~400 lines) | Complex (~1,200 lines) |
| Debuggability | Watch Claude think | Read Python logs |
| Trust Required | High | Lower |
| Best For | Experimentation | Production |

## Safety

1. **Paper trading only** - No real money at risk
2. **Hard limits** - Enforced in check-risk.sh
3. **All actions logged** - Full audit trail
4. **Self-correction** - Claude handles errors
5. **Emergency close** - close-all.sh available

## Monitoring

```bash
# Watch live logs
tail -f /root/catalyst-dev/logs/trade.log

# Check database logs
psql $DATABASE_URL -c "SELECT * FROM agent_logs WHERE source='dev_claude' ORDER BY timestamp DESC LIMIT 20;"

# Check positions
./tools/portfolio.sh
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Insufficient buying power" | Check account.sh, reduce position size |
| "Symbol not found" | Verify ticker symbol |
| "Rate limited" | Wait 60 seconds |
| "Market closed" | Run during market hours |
| "jq not found" | `apt install jq` |

---

*dev_claude - Claude Code Trading Agent*  
*Part of the Catalyst Trading System*  
*"Trust, but verify. Then trust more."*
