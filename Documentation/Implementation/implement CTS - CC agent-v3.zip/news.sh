#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: news.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Get recent news for a symbol
#
# Usage: ./tools/news.sh AAPL
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ]; then
    echo "Usage: ./tools/news.sh SYMBOL"
    echo "Example: ./tools/news.sh AAPL"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')

echo "Getting news for $SYMBOL..."
echo ""

# Get news from Alpaca
NEWS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "https://data.alpaca.markets/v1beta1/news?symbols=${SYMBOL}&limit=5")

# Check for errors
if echo "$NEWS" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$NEWS" | jq -r '.message')"
    echo ""
    echo "Note: News API may require a paid subscription."
    echo "Proceeding without news data."
    exit 0
fi

# Check if we have news
NEWS_COUNT=$(echo "$NEWS" | jq '.news | length')

if [ "$NEWS_COUNT" -eq 0 ]; then
    echo "No recent news found for $SYMBOL"
    exit 0
fi

echo "=== NEWS: $SYMBOL (Last 5) ==="
echo ""

# Display each news item
echo "$NEWS" | jq -r '.news[] | "[\(.created_at | split("T")[0])] \(.headline)\n  Source: \(.source)\n  Sentiment: \(.sentiment // "N/A")\n"'

echo "---"
echo "Tip: Check for earnings dates, FDA approvals, or major announcements"
echo "Tip: Negative news = avoid entry. Positive catalyst = potential momentum"
