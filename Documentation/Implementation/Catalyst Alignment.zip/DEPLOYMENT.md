# dev_claude Alignment Package - Deployment Guide

**Name of Application:** Catalyst Trading System  
**Name of File:** DEPLOYMENT.md  
**Version:** 1.0.0  
**Last Updated:** 2026-01-17  
**Purpose:** Deploy dev_claude (US) aligned with intl_claude (HKEX)

---

## Package Contents

```
catalyst-dev-alignment/
├── unified_agent.py          # v3.0.0 - Main agent with Claude AI loop
├── tool_executor.py          # v1.0.0 - Routes tool calls to implementations
├── tools.py                  # v1.0.0 - Tool definitions for Claude
├── signals.py                # v2.0.0 - Exit signal detection
├── brokers/
│   ├── __init__.py
│   └── alpaca.py             # v1.0.0 - Alpaca broker wrapper
├── data/
│   ├── __init__.py
│   └── database.py           # v1.0.0 - Database connection manager
└── config/
    └── dev_claude_config.yaml # v2.0.0 - Agent configuration
```

---

## Architecture Alignment

| Component | intl_claude (HKEX) | dev_claude (US) | Status |
|-----------|-------------------|-----------------|--------|
| unified_agent.py | v3.0.0 | v3.0.0 | ✅ Aligned |
| tool_executor.py | v2.6.0 | v1.0.0 | ✅ Aligned |
| tools.py | v1.0.0 | v1.0.0 | ✅ Aligned |
| signals.py | v2.0.0 | v2.0.0 | ✅ Aligned |
| brokers/ | moomoo.py | alpaca.py | ✅ Aligned |
| data/database.py | v1.0.0 | v1.0.0 | ✅ Aligned |
| config YAML | v2.0.0 | v2.0.0 | ✅ Aligned |

---

## Key Differences (Market-Specific)

| Aspect | intl_claude (HKEX) | dev_claude (US) |
|--------|-------------------|-----------------|
| Broker | Moomoo (OpenD) | Alpaca API |
| Timezone | HK_TZ (UTC+8) | ET (UTC-5/4) |
| Market Hours | 9:30-12:00, 13:00-16:00 HKT | 9:30-16:00 ET |
| Lunch Break | Yes (12:00-13:00) | No |
| Tick Sizes | HKEX 11-tier table | 2 decimal places |
| Currency | HKD | USD |
| Bracket Orders | Via conditional orders | Native support |

---

## Deployment Steps

### 1. Backup Current Code

```bash
ssh root@US_DROPLET
cd /root
cp -r catalyst-dev catalyst-dev.backup.$(date +%Y%m%d)
```

### 2. Deploy New Files

```bash
# Copy files to droplet
scp -r catalyst-dev-alignment/* root@US_DROPLET:/root/catalyst-dev/

# Or via git
cd /root/catalyst-dev
git pull origin main
```

### 3. Verify Environment

```bash
# Check .env has required variables
cat /root/catalyst-dev/.env

# Required:
# ALPACA_API_KEY=your_key
# ALPACA_SECRET_KEY=your_secret
# ALPACA_PAPER=true
# DATABASE_URL=postgresql://...
# RESEARCH_DATABASE_URL=postgresql://...
# ANTHROPIC_API_KEY=your_key
```

### 4. Install Dependencies

```bash
cd /root/catalyst-dev
source venv/bin/activate
pip install alpaca-py asyncpg pyyaml anthropic pytz
```

### 5. Test Connection

```bash
# Test broker connection
python3 -c "
from brokers.alpaca import AlpacaClient
client = AlpacaClient(paper=True)
client.connect()
print(client.get_portfolio())
client.disconnect()
"

# Test database connection
python3 -c "
import asyncio
from data.database import init_database
async def test():
    db = await init_database()
    print('Connected:', db.is_connected())
asyncio.run(test())
"
```

### 6. Test Agent Run

```bash
# Dry run (heartbeat mode)
python3 unified_agent.py --mode heartbeat --force

# Scan mode test
python3 unified_agent.py --mode scan --force
```

---

## Cron Schedule (US Eastern)

```cron
# Pre-market scan (08:00 ET = 13:00 UTC)
0 13 * * 1-5 cd /root/catalyst-dev && ./venv/bin/python3 unified_agent.py --mode scan >> logs/cron.log 2>&1

# Trading cycles (hourly 09:30-15:00 ET)
30 14 * * 1-5 cd /root/catalyst-dev && ./venv/bin/python3 unified_agent.py --mode trade >> logs/cron.log 2>&1
0 15,16,17,18,19,20 * * 1-5 cd /root/catalyst-dev && ./venv/bin/python3 unified_agent.py --mode trade >> logs/cron.log 2>&1

# End-of-day close (16:00 ET = 21:00 UTC)
0 21 * * 1-5 cd /root/catalyst-dev && ./venv/bin/python3 unified_agent.py --mode close >> logs/cron.log 2>&1

# Off-hours heartbeat
0 0,3,6,9,12 * * 1-5 cd /root/catalyst-dev && ./venv/bin/python3 unified_agent.py --mode heartbeat >> logs/cron.log 2>&1
```

---

## Position Monitor Service

Position monitoring is handled by a separate systemd service, not inline.

### Install Service

```bash
# Copy service file
cp position-monitor-us.service /etc/systemd/system/

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable position-monitor-us
sudo systemctl start position-monitor-us

# Check status
sudo systemctl status position-monitor-us
```

---

## Verification Checklist

- [ ] Files deployed to `/root/catalyst-dev/`
- [ ] Environment variables set in `.env`
- [ ] Python dependencies installed
- [ ] Broker connection test passed
- [ ] Database connection test passed
- [ ] Heartbeat mode test passed
- [ ] Cron jobs installed
- [ ] Position monitor service running

---

## Rollback

```bash
# If issues, restore backup
cd /root
rm -rf catalyst-dev
mv catalyst-dev.backup.YYYYMMDD catalyst-dev
```

---

## Files Not Included (Keep Existing)

These files should remain from existing deployment:

- `.env` - Environment configuration
- `logs/` - Log directory
- `startup_monitor.py` - Pre-market reconciliation
- `position_monitor_service.py` - Systemd daemon
- `position-monitor-us.service` - Systemd unit file

---

**Created:** 2026-01-17  
**Author:** Claude + Craig  
**Status:** Ready for deployment
