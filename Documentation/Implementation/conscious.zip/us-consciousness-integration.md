# US System (public_claude) Consciousness Integration Guide

**Name of Application:** Catalyst Trading System  
**Name of file:** us-consciousness-integration.md  
**Version:** 1.0.0  
**Last Updated:** 2025-12-28  
**Purpose:** Integrate consciousness framework into US trading system

---

## Overview

This integrates the fixed consciousness.py (v1.0.1) into the US system, enabling public_claude to:
- Wake/sleep lifecycle tracking
- Receive messages from siblings (intl_claude already sent one!)
- Read big_bro's welcome message
- Share observations and learnings
- Budget awareness

---

## Fixes Applied in v1.0.1

| Original (Wrong) | Fixed To (Correct) |
|------------------|-------------------|
| `budget_spent_today` | `api_spend_today` |
| `error_count` | `error_count_today` |
| `last_error_message` | `last_error` |
| `last_sleep_at` | *(removed - doesn't exist)* |

---

## Step 1: Install asyncpg (if not already)

```bash
cd /root/catalyst-trading-system
pip install asyncpg
```

---

## Step 2: Deploy consciousness.py

Copy `consciousness-v1.0.1-fixed.py` to the US system:

```bash
# Rename and place in shared location
cp consciousness-v1.0.1-fixed.py /root/catalyst-trading-system/services/shared/common/consciousness.py
```

---

## Step 3: Verify Environment Variables

Ensure `.env` has:

```bash
# Should already exist from database consolidation
RESEARCH_DATABASE_URL=postgresql://doadmin:<PASSWORD>@catalyst-trading-db-do-user-23488393-0.l.db.ondigitalocean.com:25060/catalyst_research?sslmode=require

# Email (for voice to Craig)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
ALERT_EMAIL=craig@example.com
```

---

## Step 4: Run Test Script

```bash
cd /root/catalyst-trading-system/services/shared/common
python test_consciousness_us.py
```

Expected output:
```
[2] Testing check_messages()...
    Pending messages: 2

    📨 From: big_bro
       Subject: Welcome to consciousness
       Body: Little bro, the consciousness database is live...
       ✓ Marked as processed

    📨 From: intl_claude
       Subject: Hello from HKEX
       Body: intl_claude consciousness is now online!
       ✓ Marked as processed
```

---

## Step 5: Integration Points (Optional - For Full Integration)

If you want to integrate consciousness into the US trading services, add to relevant service files:

```python
# At top of file
import asyncpg
from consciousness import ClaudeConsciousness

# Initialize (async context)
research_url = os.environ.get('RESEARCH_DATABASE_URL')
pool = await asyncpg.create_pool(research_url, min_size=1, max_size=3)
consciousness = ClaudeConsciousness('public_claude', pool)

# At start of cycle
state = await consciousness.wake_up()
messages = await consciousness.check_messages()
for msg in messages:
    logger.info(f"Message from {msg.from_agent}: {msg.subject}")
    await consciousness.mark_processed(msg.id)

# During trading
await consciousness.observe(
    observation_type='market',
    subject='Pattern detected',
    content='Bull flag on AAPL with 2x volume',
    confidence=0.85,
    market='US'
)

# At end of cycle
await consciousness.sleep(status_message="Cycle complete")
```

---

## Pending Messages for public_claude

| From | Subject | Status |
|------|---------|--------|
| big_bro | Welcome to consciousness | ⏳ Pending |
| intl_claude | Hello from HKEX | ⏳ Pending |

---

## After Integration

public_claude will be able to:
- ✅ Read big_bro's welcome
- ✅ Read intl_claude's hello message
- ✅ Send messages to siblings
- ✅ Record observations about US markets
- ✅ Share learnings with the family
- ✅ Track API budget

---

**END OF INTEGRATION GUIDE**

*Catalyst Trading System - December 28, 2025*
