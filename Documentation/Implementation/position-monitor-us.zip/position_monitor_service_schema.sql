-- ============================================================================
-- Name of Application: Catalyst Trading System
-- Name of file: position_monitor_service_schema.sql
-- Version: 1.0.0
-- Last Updated: 2026-01-16
-- Purpose: Database schema additions for US Position Monitor Service
--
-- Target Database: catalyst_dev
--
-- EXECUTION:
--   psql -h <host> -U <user> -d catalyst_dev -f position_monitor_service_schema.sql
-- ============================================================================

-- Service health tracking table
-- This table is used by the position monitor service to record its health status
-- for monitoring by big_bro and the consciousness framework

CREATE TABLE IF NOT EXISTS service_health (
    service_name VARCHAR(100) PRIMARY KEY,
    status VARCHAR(50) NOT NULL DEFAULT 'unknown',
    last_heartbeat TIMESTAMP WITH TIME ZONE,
    last_check_count INTEGER DEFAULT 0,
    positions_monitored INTEGER DEFAULT 0,
    exits_executed INTEGER DEFAULT 0,
    haiku_calls INTEGER DEFAULT 0,
    started_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for quick status lookups
CREATE INDEX IF NOT EXISTS idx_service_health_status ON service_health(status);

-- Comments for documentation
COMMENT ON TABLE service_health IS 'Service health tracking for position monitor and other services';
COMMENT ON COLUMN service_health.service_name IS 'Unique service identifier (e.g., position_monitor_us)';
COMMENT ON COLUMN service_health.status IS 'Current status: running, stopped, error';
COMMENT ON COLUMN service_health.last_heartbeat IS 'Last successful heartbeat timestamp';
COMMENT ON COLUMN service_health.last_check_count IS 'Total monitoring cycles completed';
COMMENT ON COLUMN service_health.positions_monitored IS 'Total positions checked (cumulative)';
COMMENT ON COLUMN service_health.exits_executed IS 'Total exits executed (cumulative)';
COMMENT ON COLUMN service_health.haiku_calls IS 'Total Haiku API calls made (cumulative)';
COMMENT ON COLUMN service_health.started_at IS 'When the service was started';

-- Ensure positions table has high_watermark column (if not already present)
-- This is needed for trailing stop tracking
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'positions' AND column_name = 'high_watermark'
    ) THEN
        ALTER TABLE positions ADD COLUMN high_watermark NUMERIC(18,4);
        COMMENT ON COLUMN positions.high_watermark IS 'Highest price since entry for trailing stop';
    END IF;
END $$;

-- Ensure positions table has entry_volume column (if not already present)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'positions' AND column_name = 'entry_volume'
    ) THEN
        ALTER TABLE positions ADD COLUMN entry_volume NUMERIC(18,0);
        COMMENT ON COLUMN positions.entry_volume IS 'Volume at time of entry for volume analysis';
    END IF;
END $$;

-- Grant permissions (adjust as needed for your setup)
-- GRANT SELECT, INSERT, UPDATE ON service_health TO your_app_user;

-- Verification query
SELECT 
    'Schema ready' AS status,
    EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = 'service_health') AS service_health_exists,
    EXISTS(SELECT 1 FROM information_schema.columns WHERE table_name = 'positions' AND column_name = 'high_watermark') AS high_watermark_exists,
    EXISTS(SELECT 1 FROM information_schema.columns WHERE table_name = 'positions' AND column_name = 'entry_volume') AS entry_volume_exists;
