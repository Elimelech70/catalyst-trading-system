# Dashboard Command Center Design

**Name of Application:** Catalyst Trading System  
**Name of file:** dashboard-commands-design-v1.0.0.md  
**Version:** 1.0.0  
**Last Updated:** 2025-12-31  
**Purpose:** Add task/command interface to mobile dashboard

---

## 1. Overview

Craig needs to send commands to the Claude Family from his phone when away from computer.

### Current State
- Can view agents, messages, observations
- Can approve/deny escalations
- Message form exists but not prominent

### Target State
- Quick command buttons for common tasks
- Send to specific agent or broadcast
- Free-form message input
- Visible on home page

---

## 2. UI Design

### 2.1 Home Page Layout (Updated)

```
┌─────────────────────────────────────────────────────────────────────┐
│  🧠 Catalyst Consciousness                     [16:45 AWST]         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ⚠️ PENDING APPROVALS (if any - red pulsing)                       │
│  └─ [approval cards...]                                            │
│                                                                     │
│  ────────────────────────────────────────────────────────────────  │
│                                                                     │
│  📡 COMMAND CENTER                                    [NEW SECTION] │
│                                                                     │
│  Quick Commands:                                                    │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐                   │
│  │📊 Report│ │🔍 Status│ │🛑 Stop  │ │🔄 Health│                   │
│  │  HKEX   │ │   All   │ │ Trading │ │  Check  │                   │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘                   │
│                                                                     │
│  Send Message:                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ To: [▼ intl_claude    ]                                     │   │
│  ├─────────────────────────────────────────────────────────────┤   │
│  │ Subject: [                                    ]             │   │
│  ├─────────────────────────────────────────────────────────────┤   │
│  │ Message:                                                    │   │
│  │ [                                                         ] │   │
│  │ [                                                         ] │   │
│  └─────────────────────────────────────────────────────────────┘   │
│  [ 📤 Send Message ]                                               │
│                                                                     │
│  ────────────────────────────────────────────────────────────────  │
│                                                                     │
│  👥 AGENTS                                                          │
│  └─ [agent cards...]                                               │
│                                                                     │
│  💬 RECENT MESSAGES                                                 │
│  └─ [message cards...]                                             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 2.2 Quick Command Buttons

| Button | Target Agent | Action |
|--------|--------------|--------|
| 📊 Report HKEX | intl_claude | "Generate and send today's trading report" |
| 📊 Report US | public_claude | "Generate and send today's trading report" |
| 🔍 Status All | big_bro | "Give me status on all systems and agents" |
| 🛑 Stop Trading | broadcast | "Stop all trading immediately - human override" |
| 🔄 Health Check | big_bro | "Run health check on all agents and report" |
| 💰 P&L Summary | big_bro | "What's our current P&L across all markets?" |

### 2.3 Configurable Quick Commands

Store in database for easy updates:

```sql
CREATE TABLE dashboard_quick_commands (
    id SERIAL PRIMARY KEY,
    label VARCHAR(50) NOT NULL,
    icon VARCHAR(10),
    to_agent VARCHAR(50) NOT NULL,
    subject VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    priority VARCHAR(20) DEFAULT 'high',
    display_order INTEGER DEFAULT 0,
    enabled BOOLEAN DEFAULT TRUE
);

-- Seed data
INSERT INTO dashboard_quick_commands (label, icon, to_agent, subject, body, priority, display_order) VALUES
('Report HKEX', '📊', 'intl_claude', 'Request: Daily Report', 'Please generate today''s trading report and store in consciousness.', 'high', 1),
('Report US', '📊', 'public_claude', 'Request: Daily Report', 'Please generate today''s trading report.', 'high', 2),
('Status All', '🔍', 'big_bro', 'Request: System Status', 'Please provide status on all agents and systems.', 'normal', 3),
('Stop Trading', '🛑', 'broadcast', 'URGENT: Stop Trading', 'Human override - stop all trading activity immediately.', 'urgent', 4),
('Health Check', '🔄', 'big_bro', 'Request: Health Check', 'Run health check on all agents and report findings.', 'normal', 5),
('P&L Summary', '💰', 'big_bro', 'Request: P&L Summary', 'What is our current P&L across all markets?', 'normal', 6);
```

---

## 3. Implementation

### 3.1 New Endpoints

```python
# Quick command execution
POST /command/{command_id}    → Execute a quick command

# Message sending (existing, but make more prominent)
POST /message                 → Send custom message
```

### 3.2 HTML for Command Center

```python
def command_center_html(token: str, commands: list) -> str:
    """Generate command center HTML."""
    
    # Quick command buttons
    buttons = ""
    for cmd in commands:
        buttons += f'''
        <form method="POST" action="/command/{cmd['id']}?token={token}" style="display:inline-block;">
            <button type="submit" class="quick-cmd">
                <span class="cmd-icon">{cmd['icon']}</span>
                <span class="cmd-label">{cmd['label']}</span>
            </button>
        </form>
        '''
    
    html = f'''
    <h2>📡 COMMAND CENTER</h2>
    
    <div class="quick-commands">
        {buttons}
    </div>
    
    <div class="message-form">
        <form method="POST" action="/message?token={token}">
            <label>To:</label>
            <select name="to_agent">
                <option value="intl_claude">intl_claude (HKEX)</option>
                <option value="public_claude">public_claude (US)</option>
                <option value="big_bro">big_bro (Strategy)</option>
                <option value="broadcast">📢 Broadcast All</option>
            </select>
            
            <label>Priority:</label>
            <select name="priority">
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="urgent">🚨 Urgent</option>
            </select>
            
            <label>Subject:</label>
            <input type="text" name="subject" placeholder="Brief subject..." required>
            
            <label>Message:</label>
            <textarea name="body" rows="3" placeholder="Your message..." required></textarea>
            
            <button type="submit">📤 Send Message</button>
        </form>
    </div>
    '''
    
    return html
```

### 3.3 CSS for Quick Commands

```css
.quick-commands {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
    margin: 12px 0;
}

.quick-cmd {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 12px 8px;
    background: #1a1a2e;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    cursor: pointer;
}

.quick-cmd:hover {
    background: #252545;
    border-color: #00d4ff;
}

.quick-cmd:active {
    background: #00d4ff;
    color: #000;
}

.cmd-icon {
    font-size: 1.5em;
    margin-bottom: 4px;
}

.cmd-label {
    font-size: 0.8em;
    color: #aaa;
}

.quick-cmd:hover .cmd-label {
    color: #fff;
}

/* Urgent button styling */
.quick-cmd.urgent {
    border-color: #f44;
    background: #2a1a1a;
}

.quick-cmd.urgent:hover {
    background: #f44;
    color: #fff;
}

.message-form {
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid #333;
}
```

### 3.4 Command Execution Endpoint

```python
@app.post("/command/{command_id}")
async def execute_command(
    command_id: int,
    request: Request,
    token: str = Depends(verify_token)
):
    """Execute a quick command."""
    pool = await get_pool()
    
    try:
        async with pool.acquire() as conn:
            # Get command details
            cmd = await conn.fetchrow("""
                SELECT to_agent, subject, body, priority
                FROM dashboard_quick_commands
                WHERE id = $1 AND enabled = TRUE
            """, command_id)
            
            if not cmd:
                raise HTTPException(404, "Command not found")
            
            # Handle broadcast
            if cmd['to_agent'] == 'broadcast':
                agents = ['intl_claude', 'public_claude', 'big_bro']
            else:
                agents = [cmd['to_agent']]
            
            # Send message to each agent
            for agent in agents:
                await conn.execute("""
                    INSERT INTO claude_messages 
                    (from_agent, to_agent, subject, body, priority, msg_type)
                    VALUES ('craig_mobile', $1, $2, $3, $4, 'task')
                """, agent, cmd['subject'], cmd['body'], cmd['priority'])
            
    finally:
        await pool.close()
    
    return RedirectResponse(url=f"/?token={token}&msg=Command+sent", status_code=303)
```

---

## 4. Implementation Priority

### Phase 1: Basic Commands (Today)
1. Add command center section to home page
2. Hardcode 4-6 quick commands (no DB table yet)
3. Improve message form visibility

### Phase 2: Database Commands (Later)
4. Create dashboard_quick_commands table
5. Make commands configurable
6. Add command management page

---

## 5. Files to Modify

| File | Changes |
|------|---------|
| `web_dashboard.py` | Add command center HTML/CSS, `/command` endpoint |

---

## 6. Quick Implementation (No DB)

For fastest deployment, hardcode commands in Python:

```python
QUICK_COMMANDS = [
    {"id": 1, "icon": "📊", "label": "Report HKEX", "to_agent": "intl_claude", 
     "subject": "Request: Daily Report", "body": "Generate today's trading report.", "priority": "high"},
    {"id": 2, "icon": "📊", "label": "Report US", "to_agent": "public_claude",
     "subject": "Request: Daily Report", "body": "Generate today's trading report.", "priority": "high"},
    {"id": 3, "icon": "🔍", "label": "Status", "to_agent": "big_bro",
     "subject": "Request: Status", "body": "Status on all agents and systems.", "priority": "normal"},
    {"id": 4, "icon": "🛑", "label": "Stop", "to_agent": "broadcast",
     "subject": "STOP TRADING", "body": "Human override - stop all trading.", "priority": "urgent"},
    {"id": 5, "icon": "🔄", "label": "Health", "to_agent": "big_bro",
     "subject": "Health Check", "body": "Run health check on all systems.", "priority": "normal"},
    {"id": 6, "icon": "💰", "label": "P&L", "to_agent": "big_bro",
     "subject": "P&L Summary", "body": "Current P&L across all markets?", "priority": "normal"},
]
```

This avoids DB migration and can be deployed immediately.
