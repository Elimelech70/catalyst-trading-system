#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: technicals.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Get technical indicators for a symbol
#
# Usage: ./tools/technicals.sh AAPL
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ]; then
    echo "Usage: ./tools/technicals.sh SYMBOL"
    echo "Example: ./tools/technicals.sh AAPL"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')

echo "Calculating technicals for $SYMBOL..."
echo ""

# Get historical bars (last 50 days for MA calculations)
END_DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ)
START_DATE=$(date -u -d "60 days ago" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -v-60d -u +%Y-%m-%dT%H:%M:%SZ)

BARS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/stocks/${SYMBOL}/bars?timeframe=1Day&start=${START_DATE}&limit=50&feed=iex")

# Check for errors
if echo "$BARS" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$BARS" | jq -r '.message')"
    exit 1
fi

# Extract close prices
CLOSES=$(echo "$BARS" | jq -r '[.bars[].c] | reverse')
VOLUMES=$(echo "$BARS" | jq -r '[.bars[].v] | reverse')
HIGHS=$(echo "$BARS" | jq -r '[.bars[].h] | reverse')
LOWS=$(echo "$BARS" | jq -r '[.bars[].l] | reverse')

# Get latest values
LATEST_CLOSE=$(echo "$CLOSES" | jq '.[0]')
LATEST_VOLUME=$(echo "$VOLUMES" | jq '.[0]')
LATEST_HIGH=$(echo "$HIGHS" | jq '.[0]')
LATEST_LOW=$(echo "$LOWS" | jq '.[0]')

# Calculate Simple Moving Averages
SMA_10=$(echo "$CLOSES" | jq '[.[0:10]] | add / length')
SMA_20=$(echo "$CLOSES" | jq '[.[0:20]] | add / length')
SMA_50=$(echo "$CLOSES" | jq '[.[0:50]] | add / length')

# Calculate Average Volume (20-day)
AVG_VOLUME=$(echo "$VOLUMES" | jq '[.[0:20]] | add / length | floor')

# Calculate RSI (14-period simplified)
# RSI = 100 - (100 / (1 + RS)) where RS = Avg Gain / Avg Loss
python3 - <<EOF
import json

closes = json.loads('$CLOSES')
if len(closes) < 15:
    print("RSI: N/A (insufficient data)")
else:
    gains = []
    losses = []
    for i in range(1, 15):
        change = closes[i-1] - closes[i]
        if change > 0:
            gains.append(change)
            losses.append(0)
        else:
            gains.append(0)
            losses.append(abs(change))
    
    avg_gain = sum(gains) / 14
    avg_loss = sum(losses) / 14
    
    if avg_loss == 0:
        rsi = 100
    else:
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
    
    print(f"RSI (14): {rsi:.1f}")
    if rsi > 70:
        print("  → OVERBOUGHT - Consider taking profits")
    elif rsi < 30:
        print("  → OVERSOLD - Potential bounce")
    else:
        print("  → Neutral")
EOF

echo ""
echo "=== TECHNICALS: $SYMBOL ==="
echo ""
echo "Price: \$$LATEST_CLOSE"
echo "Day Range: \$$LATEST_LOW - \$$LATEST_HIGH"
echo "Volume: $(printf "%'d" $LATEST_VOLUME) (Avg: $(printf "%'d" $(echo "$AVG_VOLUME" | cut -d'.' -f1)))"
echo ""
echo "Moving Averages:"
printf "  SMA(10): \$%.2f\n" $SMA_10
printf "  SMA(20): \$%.2f\n" $SMA_20
printf "  SMA(50): \$%.2f\n" $SMA_50
echo ""

# Price vs MAs analysis
python3 - <<EOF
price = $LATEST_CLOSE
sma10 = $SMA_10
sma20 = $SMA_20
sma50 = $SMA_50

print("Trend Analysis:")
if price > sma10 > sma20 > sma50:
    print("  → STRONG UPTREND (Price > 10 > 20 > 50)")
elif price > sma20 > sma50:
    print("  → UPTREND (Price > 20 > 50)")
elif price < sma10 < sma20 < sma50:
    print("  → STRONG DOWNTREND (Price < 10 < 20 < 50)")
elif price < sma20 < sma50:
    print("  → DOWNTREND (Price < 20 < 50)")
else:
    print("  → MIXED/CONSOLIDATING")

# Support/Resistance
print(f"\nKey Levels:")
print(f"  Resistance: \${max(sma10, sma20, sma50):.2f}")
print(f"  Support: \${min(sma10, sma20, sma50):.2f}")
EOF
