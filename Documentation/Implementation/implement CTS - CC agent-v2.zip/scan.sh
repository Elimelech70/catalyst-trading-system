#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: scan.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Scan for trading opportunities using Alpaca API
#
# REVISION HISTORY:
# v1.0.0 (2026-02-01) - Initial implementation
#   - Top movers from watchlist
#   - Volume and price filters
#   - JSON output for Claude Code
#
# Usage: ./tools/scan.sh
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Watchlist of liquid stocks
SYMBOLS="AAPL,MSFT,GOOGL,AMZN,TSLA,META,NVDA,AMD,NFLX,DIS,JPM,BAC,V,MA,GS"

# Get latest bars for all symbols
echo "Scanning market for opportunities..."
echo ""

RESPONSE=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/stocks/bars/latest?symbols=${SYMBOLS}&feed=iex")

# Check for errors
if echo "$RESPONSE" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$RESPONSE" | jq -r '.message')"
    exit 1
fi

# Parse and display results
echo "=== MARKET SCAN RESULTS ==="
echo ""
echo "Symbol | Price    | Volume     | Change"
echo "-------|----------|------------|--------"

# Process each symbol
echo "$RESPONSE" | jq -r '.bars | to_entries[] | "\(.key) | $\(.value.c | tostring | .[0:8]) | \(.value.v) | -"' 2>/dev/null || echo "No data available"

echo ""
echo "---"
echo "Tip: Use ./tools/quote.sh SYMBOL for detailed quote"
echo "Tip: Use ./tools/technicals.sh SYMBOL for technical analysis"
