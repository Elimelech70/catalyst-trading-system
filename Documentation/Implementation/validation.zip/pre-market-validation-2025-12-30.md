# Pre-Market Validation Plan - December 30, 2025

**Name of Application:** Catalyst Trading System  
**Name of file:** pre-market-validation-2025-12-30.md  
**Version:** 1.0.0  
**Last Updated:** 2025-12-28  
**Purpose:** Comprehensive testing before US market opens December 30th

---

## Executive Summary

After significant changes (database consolidation, consciousness framework, C1/C2 fixes), we need thorough validation before market opens.

**Market Open:** December 30, 2025 at 09:30 EST (22:30 AWST / 10:30 AEDT)

---

## Part 1: Infrastructure Verification

### 1.1 Droplet Health

```bash
# Check droplet is running
ssh root@<droplet-ip> "uptime && free -h && df -h"

# Expected:
# - Uptime shows system stable
# - Memory: at least 1GB free
# - Disk: at least 5GB free
```

### 1.2 Docker Services

```bash
# Check all containers running
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

# Expected: All 8 services running
# - catalyst-postgres (or using managed DB)
# - catalyst-scanner
# - catalyst-trading
# - catalyst-risk-manager
# - catalyst-workflow
# - catalyst-coordination
# - catalyst-gateway
# - catalyst-report
```

### 1.3 Service Health Endpoints

```bash
# Test each service health
for port in 5001 5002 5003 5004 5005 5006 5007 5008; do
    echo "Port $port: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:$port/health)"
done

# Expected: All return 200
```

---

## Part 2: Database Verification

### 2.1 Connection Test

```bash
# Test trading database connection
psql "$DATABASE_URL" -c "SELECT 1 as connection_test;"

# Test research database connection
psql "$RESEARCH_DATABASE_URL" -c "SELECT 1 as connection_test;"

# Expected: Both return "1"
```

### 2.2 Trading Database Schema

```sql
-- Connect to trading database
-- Verify critical tables exist

SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN (
    'securities', 'positions', 'orders', 'trading_sessions',
    'scan_results', 'decisions', 'claude_outputs'
)
ORDER BY table_name;

-- Expected: All 7 tables listed
```

### 2.3 Orders Table (C1 Fix)

```sql
-- Verify orders table has correct structure
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'orders'
ORDER BY ordinal_position;

-- Required columns:
-- order_id, position_id, alpaca_order_id, symbol, side, quantity,
-- order_type, status, order_purpose, submitted_at, filled_at, etc.

-- Count orders
SELECT COUNT(*) as total_orders,
       COUNT(CASE WHEN status = 'filled' THEN 1 END) as filled,
       COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending
FROM orders;
```

### 2.4 Positions Table (No Alpaca Columns)

```sql
-- Verify positions table has NO alpaca order columns
SELECT column_name FROM information_schema.columns 
WHERE table_name = 'positions' 
AND column_name LIKE 'alpaca%';

-- Expected: Empty result (no alpaca columns in positions)
```

### 2.5 Research Database (Consciousness)

```sql
-- Connect to research database
-- Verify consciousness tables

SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name LIKE 'claude_%'
ORDER BY table_name;

-- Expected: 8 tables
-- claude_state, claude_messages, claude_observations,
-- claude_learnings, claude_questions, claude_conversations,
-- claude_thinking, sync_log
```

### 2.6 Agent States

```sql
-- Verify agents are initialized
SELECT agent_id, current_mode, daily_budget, error_count_today 
FROM claude_state
ORDER BY agent_id;

-- Expected:
-- big_bro       | sleeping | 10.00 | 0
-- intl_claude   | sleeping |  5.00 | 0
-- public_claude | sleeping |  5.00 | 0
```

### 2.7 Welcome Messages

```sql
-- Check welcome messages are pending
SELECT from_agent, to_agent, subject, status 
FROM claude_messages 
WHERE status = 'pending';

-- Expected: 2 welcome messages from big_bro
```

---

## Part 3: Consciousness Framework Verification

### 3.1 Module Import Test

```python
#!/usr/bin/env python3
"""Test consciousness module imports."""

import sys
sys.path.insert(0, '/root/catalyst-trading-system/services/shared/common')

try:
    from consciousness import ClaudeConsciousness, AgentState, Message
    print("✅ consciousness.py imports successfully")
except Exception as e:
    print(f"❌ consciousness.py import failed: {e}")
    sys.exit(1)

try:
    from database import DatabaseManager, get_database_manager
    print("✅ database.py imports successfully")
except Exception as e:
    print(f"❌ database.py import failed: {e}")
    sys.exit(1)

try:
    from alerts import AlertManager
    print("✅ alerts.py imports successfully")
except Exception as e:
    print(f"❌ alerts.py import failed: {e}")
    sys.exit(1)

try:
    from doctor_claude import DoctorClaude
    print("✅ doctor_claude.py imports successfully")
except Exception as e:
    print(f"❌ doctor_claude.py import failed: {e}")
    sys.exit(1)

print("\n✅ All consciousness modules import successfully")
```

### 3.2 Consciousness Wake Test

```python
#!/usr/bin/env python3
"""Test consciousness wake/sleep cycle."""

import asyncio
import os
import sys

sys.path.insert(0, '/root/catalyst-trading-system/services/shared/common')

from consciousness import ClaudeConsciousness
import asyncpg

async def test_consciousness():
    print("Testing Consciousness Framework")
    print("=" * 50)
    
    research_url = os.environ.get('RESEARCH_DATABASE_URL')
    if not research_url:
        print("❌ RESEARCH_DATABASE_URL not set")
        return False
    
    pool = await asyncpg.create_pool(research_url, min_size=1, max_size=3)
    
    try:
        # Test with test_claude agent (don't disturb real agents)
        c = ClaudeConsciousness('test_claude', pool)
        
        # Test wake up
        print("\n1. Testing wake_up()...")
        state = await c.wake_up()
        print(f"   ✅ Agent: {state.agent_id}")
        print(f"   ✅ Mode: {state.current_mode}")
        print(f"   ✅ Budget: ${state.api_spend_today:.2f}/${state.daily_budget:.2f}")
        
        # Test observe
        print("\n2. Testing observe()...")
        obs_id = await c.observe(
            'system',
            'Pre-market validation',
            'Testing observation recording before market open',
            confidence=0.99,
            horizon='h1',
            market='US'
        )
        print(f"   ✅ Created observation: {obs_id}")
        
        # Test check messages
        print("\n3. Testing check_messages()...")
        messages = await c.check_messages()
        print(f"   ✅ Pending messages: {len(messages)}")
        
        # Test get siblings
        print("\n4. Testing get_sibling_status()...")
        siblings = await c.get_sibling_status()
        for s in siblings:
            print(f"   ✅ {s['agent_id']}: {s['current_mode']}")
        
        # Test get questions
        print("\n5. Testing get_open_questions()...")
        questions = await c.get_open_questions(limit=3)
        for q in questions:
            print(f"   ✅ [P{q.priority}] {q.question[:40]}...")
        
        # Test sleep
        print("\n6. Testing sleep()...")
        await c.sleep("Pre-market validation complete")
        print("   ✅ Agent sleeping")
        
        # Clean up test agent state
        async with pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM claude_state WHERE agent_id = 'test_claude'"
            )
            await conn.execute(
                "DELETE FROM claude_observations WHERE agent_id = 'test_claude'"
            )
        
        print("\n" + "=" * 50)
        print("✅ Consciousness framework fully operational")
        return True
        
    except Exception as e:
        print(f"\n❌ Consciousness test failed: {e}")
        return False
    finally:
        await pool.close()

if __name__ == '__main__':
    success = asyncio.run(test_consciousness())
    sys.exit(0 if success else 1)
```

### 3.3 Doctor Claude Test

```bash
# Run Doctor Claude health check
cd /root/catalyst-trading-system/services/shared/common
python3 doctor_claude.py

# Expected:
# ✅ HEALTHY
# Checks:
#   ✅ Agent Health: 3 agents checked, 0 issues
#   ✅ Database Health: Response: Xms, Connections: Y
#   ✅ Message Queue: Pending: 2, Processed (1h): 0
```

---

## Part 4: Trading System Verification

### 4.1 Alpaca Connection

```python
#!/usr/bin/env python3
"""Test Alpaca API connection."""

import os
from alpaca.trading.client import TradingClient

api_key = os.environ.get('ALPACA_API_KEY')
secret_key = os.environ.get('ALPACA_SECRET_KEY')

if not api_key or not secret_key:
    print("❌ Alpaca credentials not set")
    exit(1)

client = TradingClient(api_key, secret_key, paper=True)

# Get account
account = client.get_account()
print(f"✅ Account Status: {account.status}")
print(f"✅ Buying Power: ${float(account.buying_power):,.2f}")
print(f"✅ Cash: ${float(account.cash):,.2f}")
print(f"✅ Portfolio Value: ${float(account.portfolio_value):,.2f}")

# Check market status
clock = client.get_clock()
print(f"\n✅ Market Open: {clock.is_open}")
print(f"✅ Next Open: {clock.next_open}")
print(f"✅ Next Close: {clock.next_close}")
```

### 4.2 Order Side Mapping Test

```python
#!/usr/bin/env python3
"""Verify order side mapping is correct."""

import sys
sys.path.insert(0, '/root/catalyst-trading-system/services/shared/common')

from alpaca_trader import map_side
from alpaca.trading.enums import OrderSide

# Test all mappings
test_cases = [
    ("buy", OrderSide.BUY),
    ("BUY", OrderSide.BUY),
    ("long", OrderSide.BUY),
    ("LONG", OrderSide.BUY),
    ("sell", OrderSide.SELL),
    ("SELL", OrderSide.SELL),
    ("short", OrderSide.SELL),
    ("SHORT", OrderSide.SELL),
]

all_passed = True
for input_side, expected in test_cases:
    result = map_side(input_side)
    passed = result == expected
    status = "✅" if passed else "❌"
    print(f"{status} map_side('{input_side}') = {result} (expected {expected})")
    if not passed:
        all_passed = False

if all_passed:
    print("\n✅ All order side mappings correct")
else:
    print("\n❌ Order side mapping issues detected!")
    sys.exit(1)
```

### 4.3 Price Rounding Test

```python
#!/usr/bin/env python3
"""Verify sub-penny price rounding."""

import sys
sys.path.insert(0, '/root/catalyst-trading-system/services/shared/common')

from alpaca_trader import round_price

test_cases = [
    (9.050000190734863, 9.05),
    (150.999999, 151.0),
    (10.004, 10.0),
    (10.005, 10.01),  # Rounds up
    (None, None),
]

all_passed = True
for input_price, expected in test_cases:
    result = round_price(input_price)
    passed = result == expected
    status = "✅" if passed else "❌"
    print(f"{status} round_price({input_price}) = {result} (expected {expected})")
    if not passed:
        all_passed = False

if all_passed:
    print("\n✅ All price rounding correct")
else:
    print("\n❌ Price rounding issues detected!")
    sys.exit(1)
```

### 4.4 Symlink Verification (C2 Fix)

```bash
# Verify alpaca_trader.py symlinks
echo "Checking alpaca_trader.py consolidation..."

AUTHORITATIVE="/root/catalyst-trading-system/services/shared/common/alpaca_trader.py"
SYMLINKS=(
    "/root/catalyst-trading-system/services/trading/common/alpaca_trader.py"
    "/root/catalyst-trading-system/services/risk-manager/common/alpaca_trader.py"
    "/root/catalyst-trading-system/services/workflow/common/alpaca_trader.py"
)

if [ -f "$AUTHORITATIVE" ]; then
    echo "✅ Authoritative file exists: $AUTHORITATIVE"
else
    echo "❌ Authoritative file missing: $AUTHORITATIVE"
    exit 1
fi

for symlink in "${SYMLINKS[@]}"; do
    if [ -L "$symlink" ]; then
        target=$(readlink -f "$symlink")
        if [ "$target" = "$AUTHORITATIVE" ]; then
            echo "✅ Correct symlink: $symlink"
        else
            echo "❌ Wrong symlink target: $symlink -> $target"
        fi
    elif [ -f "$symlink" ]; then
        echo "⚠️  Regular file (should be symlink): $symlink"
    else
        echo "❌ Missing: $symlink"
    fi
done
```

---

## Part 5: Cron Verification

### 5.1 Check Cron Jobs

```bash
# List cron jobs
crontab -l

# Expected entries for US market hours (adjust for timezone):
# Pre-market scan
# Trading cycles
# End of day
# Doctor Claude health checks
```

### 5.2 Verify Cron Timing

```bash
# Check current server time
date
TZ=America/New_York date

# Verify timezone handling
# Market opens 09:30 EST = 14:30 UTC
```

---

## Part 6: End-to-End Test (Paper Trading)

### 6.1 Manual Scan Test

```bash
# Trigger a manual scan
curl -X POST http://localhost:5001/api/v1/scan/trigger

# Check scan results
curl http://localhost:5001/api/v1/scan/results | python3 -m json.tool
```

### 6.2 Check Trading Session

```sql
-- Check latest trading session
SELECT session_id, session_date, status, start_time, end_time
FROM trading_sessions
ORDER BY session_date DESC
LIMIT 5;
```

### 6.3 Verify Workflow Status

```bash
# Check workflow logs
docker logs catalyst-workflow --tail 50

# Should not show errors
```

---

## Part 7: Pre-Market Checklist

### To Be Completed BEFORE Market Open

| # | Check | Command/Action | Status |
|---|-------|----------------|--------|
| 1 | Droplet healthy | `uptime && free -h` | ☐ |
| 2 | All Docker services running | `docker ps` | ☐ |
| 3 | All health endpoints return 200 | Loop through ports | ☐ |
| 4 | Trading DB connected | `psql $DATABASE_URL -c "SELECT 1"` | ☐ |
| 5 | Research DB connected | `psql $RESEARCH_DATABASE_URL -c "SELECT 1"` | ☐ |
| 6 | Orders table exists (C1) | Check schema | ☐ |
| 7 | Positions has no alpaca columns (C1) | Check schema | ☐ |
| 8 | Consciousness tables exist | Check claude_* tables | ☐ |
| 9 | Agent states initialized | Check claude_state | ☐ |
| 10 | Consciousness modules import | Run import test | ☐ |
| 11 | Consciousness wake/sleep works | Run wake test | ☐ |
| 12 | Doctor Claude runs clean | `python3 doctor_claude.py` | ☐ |
| 13 | Alpaca connected | Check account status | ☐ |
| 14 | Order side mapping correct | Run mapping test | ☐ |
| 15 | Price rounding correct | Run rounding test | ☐ |
| 16 | alpaca_trader.py symlinks correct | Run symlink check | ☐ |
| 17 | Cron jobs configured | `crontab -l` | ☐ |
| 18 | Manual scan works | Trigger scan | ☐ |
| 19 | No stuck orders | Check orders table | ☐ |
| 20 | No phantom positions | Check positions table | ☐ |

---

## Part 8: Monitoring During First Session

### 8.1 Watch Logs

```bash
# Terminal 1: Watch workflow
docker logs -f catalyst-workflow

# Terminal 2: Watch trading
docker logs -f catalyst-trading

# Terminal 3: Watch for errors
docker logs -f catalyst-risk-manager
```

### 8.2 Check Order Flow

```sql
-- Run periodically during session
SELECT 
    o.order_id,
    o.symbol,
    o.side,
    o.quantity,
    o.status,
    o.order_purpose,
    o.submitted_at
FROM orders o
WHERE o.submitted_at > CURRENT_DATE
ORDER BY o.submitted_at DESC
LIMIT 10;
```

### 8.3 Check Positions

```sql
-- Run periodically during session
SELECT 
    position_id,
    symbol,
    side,
    quantity,
    entry_price,
    status,
    unrealized_pnl
FROM positions
WHERE status = 'open'
ORDER BY opened_at DESC;
```

---

## Part 9: Rollback Plan

### If Critical Issues Occur

```bash
# 1. Stop autonomous trading immediately
docker stop catalyst-workflow

# 2. Close all positions manually via Alpaca dashboard
# https://app.alpaca.markets/paper/dashboard/overview

# 3. Investigate logs
docker logs catalyst-trading --tail 200 > trading_debug.log
docker logs catalyst-workflow --tail 200 > workflow_debug.log

# 4. Contact Craig with findings
```

---

## Summary

This validation plan covers:

1. ✅ Infrastructure (droplet, docker, services)
2. ✅ Database (schema, C1 fixes, consciousness tables)
3. ✅ Consciousness framework (imports, wake/sleep, doctor)
4. ✅ Trading system (Alpaca, order mapping, price rounding, C2 fixes)
5. ✅ Cron configuration
6. ✅ End-to-end testing
7. ✅ Pre-market checklist
8. ✅ Monitoring plan
9. ✅ Rollback plan

**Execute all tests before December 30 09:30 EST.**

---

*Catalyst Trading System - Pre-Market Validation*
*Created: December 28, 2025*
*For: Claude Code execution*
