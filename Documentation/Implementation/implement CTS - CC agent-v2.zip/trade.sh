#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: trade.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Execute a market order via Alpaca
#
# Usage: ./tools/trade.sh AAPL buy 10
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then
    echo "Usage: ./tools/trade.sh SYMBOL SIDE QUANTITY"
    echo "Example: ./tools/trade.sh AAPL buy 10"
    echo ""
    echo "IMPORTANT: Run ./tools/check-risk.sh first!"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')
SIDE=$(echo "$2" | tr '[:upper:]' '[:lower:]')
QTY=$3

# Safety: Only allow buy orders
if [ "$SIDE" != "buy" ]; then
    echo "❌ ERROR: Only 'buy' orders allowed"
    echo "To close a position, use: ./tools/close.sh $SYMBOL"
    exit 1
fi

# Confirm order
echo "=== EXECUTING ORDER ==="
echo ""
echo "Symbol: $SYMBOL"
echo "Side: $SIDE"
echo "Quantity: $QTY"
echo "Type: Market"
echo "Time in Force: Day"
echo ""

# Submit order
RESPONSE=$(curl -s -X POST \
     -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     -H "Content-Type: application/json" \
     -d "{
       \"symbol\": \"$SYMBOL\",
       \"qty\": \"$QTY\",
       \"side\": \"$SIDE\",
       \"type\": \"market\",
       \"time_in_force\": \"day\"
     }" \
     "${ALPACA_BASE_URL}/v2/orders")

# Check for errors
if echo "$RESPONSE" | jq -e '.message' > /dev/null 2>&1; then
    ERROR_MSG=$(echo "$RESPONSE" | jq -r '.message')
    echo "❌ ORDER REJECTED: $ERROR_MSG"
    
    # Log the error
    "$SCRIPT_DIR/log.sh" "ERROR" "Order rejected: $SYMBOL $SIDE $QTY - $ERROR_MSG"
    exit 1
fi

# Parse response
ORDER_ID=$(echo "$RESPONSE" | jq -r '.id')
ORDER_STATUS=$(echo "$RESPONSE" | jq -r '.status')
SUBMITTED_AT=$(echo "$RESPONSE" | jq -r '.submitted_at')

echo "✅ ORDER SUBMITTED"
echo ""
echo "Order ID: $ORDER_ID"
echo "Status: $ORDER_STATUS"
echo "Submitted: $SUBMITTED_AT"
echo ""

# Wait briefly and check fill status
sleep 2

FILLED_ORDER=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/orders/$ORDER_ID")

FILL_STATUS=$(echo "$FILLED_ORDER" | jq -r '.status')
FILLED_QTY=$(echo "$FILLED_ORDER" | jq -r '.filled_qty')
FILLED_PRICE=$(echo "$FILLED_ORDER" | jq -r '.filled_avg_price // "pending"')

echo "=== ORDER STATUS ==="
echo ""
echo "Status: $FILL_STATUS"
echo "Filled Qty: $FILLED_QTY"
echo "Avg Price: \$$FILLED_PRICE"

if [ "$FILL_STATUS" = "filled" ]; then
    TOTAL_VALUE=$(echo "$FILLED_QTY * $FILLED_PRICE" | bc)
    echo ""
    printf "Total Value: \$%.2f\n" $TOTAL_VALUE
    
    # Log success
    "$SCRIPT_DIR/log.sh" "TRADE" "BUY $FILLED_QTY $SYMBOL @ \$$FILLED_PRICE = \$$TOTAL_VALUE"
    
    echo ""
    echo "✅ ORDER FILLED"
elif [ "$FILL_STATUS" = "new" ] || [ "$FILL_STATUS" = "accepted" ]; then
    echo ""
    echo "⏳ Order pending - check ./tools/portfolio.sh in a moment"
else
    echo ""
    echo "⚠️  Unexpected status: $FILL_STATUS"
fi
