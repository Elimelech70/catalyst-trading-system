#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: quote.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Get current quote for a symbol
#
# Usage: ./tools/quote.sh AAPL
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ]; then
    echo "Usage: ./tools/quote.sh SYMBOL"
    echo "Example: ./tools/quote.sh AAPL"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')

echo "Getting quote for $SYMBOL..."
echo ""

# Get latest quote
QUOTE=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/stocks/${SYMBOL}/quotes/latest?feed=iex")

# Check for errors
if echo "$QUOTE" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$QUOTE" | jq -r '.message')"
    exit 1
fi

# Get latest trade for last price
TRADE=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/stocks/${SYMBOL}/trades/latest?feed=iex")

# Parse and display
BID=$(echo "$QUOTE" | jq -r '.quote.bp // "N/A"')
ASK=$(echo "$QUOTE" | jq -r '.quote.ap // "N/A"')
BID_SIZE=$(echo "$QUOTE" | jq -r '.quote.bs // "N/A"')
ASK_SIZE=$(echo "$QUOTE" | jq -r '.quote.as // "N/A"')
LAST=$(echo "$TRADE" | jq -r '.trade.p // "N/A"')
LAST_SIZE=$(echo "$TRADE" | jq -r '.trade.s // "N/A"')
TIMESTAMP=$(echo "$TRADE" | jq -r '.trade.t // "N/A"')

echo "=== QUOTE: $SYMBOL ==="
echo ""
echo "Last Price: \$$LAST (size: $LAST_SIZE)"
echo ""
echo "Bid: \$$BID (size: $BID_SIZE)"
echo "Ask: \$$ASK (size: $ASK_SIZE)"
echo ""

# Calculate spread
if [ "$BID" != "N/A" ] && [ "$ASK" != "N/A" ]; then
    SPREAD=$(echo "$ASK - $BID" | bc 2>/dev/null || echo "N/A")
    echo "Spread: \$$SPREAD"
fi

echo ""
echo "Timestamp: $TIMESTAMP"
