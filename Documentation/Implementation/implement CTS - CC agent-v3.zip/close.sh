#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: close.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Close a position (sell all shares)
#
# Usage: ./tools/close.sh AAPL
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ]; then
    echo "Usage: ./tools/close.sh SYMBOL"
    echo "Example: ./tools/close.sh AAPL"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')

echo "=== CLOSING POSITION: $SYMBOL ==="
echo ""

# Check if we have this position
POSITIONS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions")

POSITION=$(echo "$POSITIONS" | jq -r ".[] | select(.symbol == \"$SYMBOL\")")

if [ -z "$POSITION" ]; then
    echo "❌ No open position in $SYMBOL"
    exit 1
fi

# Get position details
QTY=$(echo "$POSITION" | jq -r '.qty')
ENTRY_PRICE=$(echo "$POSITION" | jq -r '.avg_entry_price')
CURRENT_PRICE=$(echo "$POSITION" | jq -r '.current_price')
UNREALIZED_PL=$(echo "$POSITION" | jq -r '.unrealized_pl')
UNREALIZED_PL_PCT=$(echo "$POSITION" | jq -r '.unrealized_plpc')

echo "Position Details:"
printf "  Shares: %s\n" $QTY
printf "  Entry: \$%s\n" $ENTRY_PRICE
printf "  Current: \$%s\n" $CURRENT_PRICE
printf "  P&L: \$%.2f (%.2f%%)\n" $UNREALIZED_PL $(echo "$UNREALIZED_PL_PCT * 100" | bc)
echo ""

# Close position via DELETE endpoint
echo "Closing position..."

RESPONSE=$(curl -s -X DELETE \
     -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions/$SYMBOL")

# Check for errors
if echo "$RESPONSE" | jq -e '.message' > /dev/null 2>&1; then
    ERROR_MSG=$(echo "$RESPONSE" | jq -r '.message')
    echo "❌ CLOSE FAILED: $ERROR_MSG"
    "$SCRIPT_DIR/log.sh" "ERROR" "Failed to close $SYMBOL: $ERROR_MSG"
    exit 1
fi

# Parse response (returns the closing order)
ORDER_ID=$(echo "$RESPONSE" | jq -r '.id')
ORDER_STATUS=$(echo "$RESPONSE" | jq -r '.status')

echo "✅ CLOSE ORDER SUBMITTED"
echo ""
echo "Order ID: $ORDER_ID"
echo "Status: $ORDER_STATUS"
echo ""

# Wait and check fill
sleep 2

FILLED_ORDER=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/orders/$ORDER_ID")

FILL_STATUS=$(echo "$FILLED_ORDER" | jq -r '.status')
FILLED_QTY=$(echo "$FILLED_ORDER" | jq -r '.filled_qty')
FILLED_PRICE=$(echo "$FILLED_ORDER" | jq -r '.filled_avg_price // "pending"')

echo "=== CLOSE STATUS ==="
echo ""
echo "Status: $FILL_STATUS"
echo "Filled Qty: $FILLED_QTY"
echo "Exit Price: \$$FILLED_PRICE"

if [ "$FILL_STATUS" = "filled" ]; then
    # Calculate realized P&L
    REALIZED_PL=$(echo "($FILLED_PRICE - $ENTRY_PRICE) * $FILLED_QTY" | bc)
    REALIZED_PL_PCT=$(echo "scale=2; ($FILLED_PRICE - $ENTRY_PRICE) / $ENTRY_PRICE * 100" | bc)
    
    echo ""
    printf "Realized P&L: \$%.2f (%.2f%%)\n" $REALIZED_PL $REALIZED_PL_PCT
    
    # Log the close
    "$SCRIPT_DIR/log.sh" "TRADE" "SELL $FILLED_QTY $SYMBOL @ \$$FILLED_PRICE - P&L: \$$REALIZED_PL"
    
    echo ""
    echo "✅ POSITION CLOSED"
elif [ "$FILL_STATUS" = "new" ] || [ "$FILL_STATUS" = "accepted" ]; then
    echo ""
    echo "⏳ Close order pending - check ./tools/portfolio.sh in a moment"
else
    echo ""
    echo "⚠️  Unexpected status: $FILL_STATUS"
fi
