#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: state.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Determine current trading state based on market hours
#
# REVISION HISTORY:
# v1.0.0 (2026-02-01) - Initial implementation
#
# States:
#   MARKET_CLOSED    - Weekend or outside trading hours
#   PRE_MARKET       - 08:00-09:30 EST (scanning/planning)
#   MARKET_OPENING   - 09:30-10:00 EST (observe, don't chase)
#   TRADING          - 10:00-15:30 EST (active trading window)
#   MARKET_CLOSING   - 15:30-16:00 EST (close day trades, no new entries)
#   POST_MARKET      - 16:00-17:00 EST (review/analysis)
#
# Usage: ./tools/state.sh
#        ./tools/state.sh --json
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/../config/.env" ]; then
    source "$SCRIPT_DIR/../config/.env"
fi

# Get current time in EST
EST_TIME=$(TZ="America/New_York" date '+%H:%M')
EST_HOUR=$(TZ="America/New_York" date '+%H')
EST_MIN=$(TZ="America/New_York" date '+%M')
EST_DAY=$(TZ="America/New_York" date '+%u')  # 1=Monday, 7=Sunday
EST_DATE=$(TZ="America/New_York" date '+%Y-%m-%d')
UTC_TIME=$(date -u '+%H:%M')

# Convert to minutes since midnight for easier comparison
CURRENT_MINS=$((10#$EST_HOUR * 60 + 10#$EST_MIN))

# Time boundaries (in minutes since midnight)
PRE_MARKET_START=$((8 * 60))        # 08:00
MARKET_OPEN=$((9 * 60 + 30))        # 09:30
TRADING_START=$((10 * 60))          # 10:00
MARKET_CLOSING_START=$((15 * 60 + 30))  # 15:30
MARKET_CLOSE=$((16 * 60))           # 16:00
POST_MARKET_END=$((17 * 60))        # 17:00

# Determine state
if [ "$EST_DAY" -ge 6 ]; then
    # Weekend
    STATE="MARKET_CLOSED"
    STATE_DESC="Weekend - market closed"
    ALLOWED_ACTIONS="review,analyze,plan"
    BLOCKED_ACTIONS="trade,open_position"
elif [ "$CURRENT_MINS" -lt "$PRE_MARKET_START" ]; then
    STATE="MARKET_CLOSED"
    STATE_DESC="Before pre-market hours"
    ALLOWED_ACTIONS="review,analyze,plan"
    BLOCKED_ACTIONS="trade,open_position"
elif [ "$CURRENT_MINS" -lt "$MARKET_OPEN" ]; then
    STATE="PRE_MARKET"
    STATE_DESC="Pre-market: Scan and prepare watchlist"
    ALLOWED_ACTIONS="scan,analyze,plan,research"
    BLOCKED_ACTIONS="trade,open_position"
elif [ "$CURRENT_MINS" -lt "$TRADING_START" ]; then
    STATE="MARKET_OPENING"
    STATE_DESC="Market opening: Observe volatility, don't chase"
    ALLOWED_ACTIONS="scan,monitor,analyze"
    BLOCKED_ACTIONS="open_position"
elif [ "$CURRENT_MINS" -lt "$MARKET_CLOSING_START" ]; then
    STATE="TRADING"
    STATE_DESC="Active trading window"
    ALLOWED_ACTIONS="scan,trade,monitor,analyze"
    BLOCKED_ACTIONS=""
elif [ "$CURRENT_MINS" -lt "$MARKET_CLOSE" ]; then
    STATE="MARKET_CLOSING"
    STATE_DESC="Market closing: Close day trades, no new entries"
    ALLOWED_ACTIONS="close,monitor,analyze"
    BLOCKED_ACTIONS="open_position"
elif [ "$CURRENT_MINS" -lt "$POST_MARKET_END" ]; then
    STATE="POST_MARKET"
    STATE_DESC="Post-market: Review and record learnings"
    ALLOWED_ACTIONS="review,analyze,log_observations"
    BLOCKED_ACTIONS="trade,open_position"
else
    STATE="MARKET_CLOSED"
    STATE_DESC="After market hours"
    ALLOWED_ACTIONS="review,analyze,plan"
    BLOCKED_ACTIONS="trade,open_position"
fi

# Calculate time until next state change
case "$STATE" in
    MARKET_CLOSED)
        if [ "$EST_DAY" -ge 6 ]; then
            NEXT_STATE="PRE_MARKET (Monday)"
        else
            NEXT_STATE="PRE_MARKET"
        fi
        MINS_TO_NEXT=$((PRE_MARKET_START - CURRENT_MINS))
        if [ "$MINS_TO_NEXT" -lt 0 ]; then
            MINS_TO_NEXT=$((24 * 60 + MINS_TO_NEXT))
        fi
        ;;
    PRE_MARKET)
        NEXT_STATE="MARKET_OPENING"
        MINS_TO_NEXT=$((MARKET_OPEN - CURRENT_MINS))
        ;;
    MARKET_OPENING)
        NEXT_STATE="TRADING"
        MINS_TO_NEXT=$((TRADING_START - CURRENT_MINS))
        ;;
    TRADING)
        NEXT_STATE="MARKET_CLOSING"
        MINS_TO_NEXT=$((MARKET_CLOSING_START - CURRENT_MINS))
        ;;
    MARKET_CLOSING)
        NEXT_STATE="POST_MARKET"
        MINS_TO_NEXT=$((MARKET_CLOSE - CURRENT_MINS))
        ;;
    POST_MARKET)
        NEXT_STATE="MARKET_CLOSED"
        MINS_TO_NEXT=$((POST_MARKET_END - CURRENT_MINS))
        ;;
esac

HOURS_TO_NEXT=$((MINS_TO_NEXT / 60))
MINS_REMAINDER=$((MINS_TO_NEXT % 60))

# Output format
if [ "$1" = "--json" ]; then
    cat <<EOF
{
  "state": "$STATE",
  "description": "$STATE_DESC",
  "time_est": "$EST_TIME",
  "time_utc": "$UTC_TIME",
  "date": "$EST_DATE",
  "day_of_week": $EST_DAY,
  "allowed_actions": "$ALLOWED_ACTIONS",
  "blocked_actions": "$BLOCKED_ACTIONS",
  "next_state": "$NEXT_STATE",
  "minutes_to_next": $MINS_TO_NEXT
}
EOF
else
    echo "=== TRADING STATE ==="
    echo ""
    echo "Current State: $STATE"
    echo "Description:   $STATE_DESC"
    echo ""
    echo "Time (EST):    $EST_TIME"
    echo "Time (UTC):    $UTC_TIME"
    echo "Date:          $EST_DATE"
    echo ""
    echo "Allowed:       $ALLOWED_ACTIONS"
    if [ -n "$BLOCKED_ACTIONS" ]; then
        echo "Blocked:       $BLOCKED_ACTIONS"
    fi
    echo ""
    echo "Next State:    $NEXT_STATE (in ${HOURS_TO_NEXT}h ${MINS_REMAINDER}m)"
    echo ""

    # State-specific guidance
    echo "--- Guidance for $STATE ---"
    case "$STATE" in
        MARKET_CLOSED)
            echo "• Review yesterday's trades and performance"
            echo "• Analyze patterns and record observations"
            echo "• Plan watchlist for next session"
            echo "• No trading actions allowed"
            ;;
        PRE_MARKET)
            echo "• Run ./tools/account.sh to check capital"
            echo "• Run ./tools/scan.sh for opportunities"
            echo "• Research top candidates with quote/technicals/news"
            echo "• Log your pre-market plan"
            echo "• Do NOT enter positions yet"
            ;;
        MARKET_OPENING)
            echo "• First 30 minutes = high volatility"
            echo "• OBSERVE but don't chase moves"
            echo "• Watch how your candidates behave"
            echo "• Identify which setups are forming"
            echo "• Wait for volatility to settle"
            ;;
        TRADING)
            echo "• Active trading window - execute your plan"
            echo "• Always run check-risk.sh before trading"
            echo "• Log every trade immediately"
            echo "• Monitor positions for exit signals"
            echo "• Don't chase - wait for your setup"
            ;;
        MARKET_CLOSING)
            echo "• Close any day trades"
            echo "• Do NOT open new positions"
            echo "• Review open positions for overnight hold"
            echo "• Prepare for EOD summary"
            ;;
        POST_MARKET)
            echo "• Run ./tools/portfolio.sh for final positions"
            echo "• Log daily summary with P&L"
            echo "• Record observations (OBSERVATION level)"
            echo "• Note learnings for consciousness framework"
            echo "• Plan for tomorrow"
            ;;
    esac
fi
