#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: install-position-monitor-us.sh
# Version: 1.0.0
# Last Updated: 2026-01-16
# Purpose: Install US Position Monitor Service for dev_claude
# ============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=========================================="
echo "Installing US Position Monitor Service"
echo "(dev_claude - Alpaca Broker)"
echo -e "==========================================${NC}"
echo ""

# Variables
DEV_DIR="/root/catalyst-dev"
SERVICE_NAME="position-monitor-us"
SERVICE_FILE="${SERVICE_NAME}.service"
PYTHON_FILE="position_monitor_service.py"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Error: Please run as root${NC}"
    exit 1
fi

# Check if dev_claude directory exists
if [ ! -d "$DEV_DIR" ]; then
    echo -e "${RED}Error: Directory not found: $DEV_DIR${NC}"
    echo "Please ensure dev_claude is deployed first."
    exit 1
fi

# Step 1: Copy Python service file
echo -e "${YELLOW}Step 1: Copying service script...${NC}"
if [ -f "$PYTHON_FILE" ]; then
    cp "$PYTHON_FILE" "$DEV_DIR/"
    chmod +x "$DEV_DIR/$PYTHON_FILE"
    echo -e "${GREEN}✓ Copied $PYTHON_FILE to $DEV_DIR/${NC}"
else
    echo -e "${RED}Error: $PYTHON_FILE not found in current directory${NC}"
    exit 1
fi

# Step 2: Install systemd service
echo -e "${YELLOW}Step 2: Installing systemd service...${NC}"
if [ -f "$SERVICE_FILE" ]; then
    cp "$SERVICE_FILE" /etc/systemd/system/
    chmod 644 /etc/systemd/system/$SERVICE_FILE
    echo -e "${GREEN}✓ Installed $SERVICE_FILE${NC}"
else
    echo -e "${RED}Error: $SERVICE_FILE not found in current directory${NC}"
    exit 1
fi

# Step 3: Create logs directory
echo -e "${YELLOW}Step 3: Creating logs directory...${NC}"
mkdir -p "$DEV_DIR/logs"
echo -e "${GREEN}✓ Logs directory ready${NC}"

# Step 4: Check environment file
echo -e "${YELLOW}Step 4: Checking environment...${NC}"
if [ -f "$DEV_DIR/.env" ]; then
    # Check for required variables
    MISSING=""
    
    if ! grep -q "DATABASE_URL\|DEV_DATABASE_URL" "$DEV_DIR/.env"; then
        MISSING="${MISSING}DATABASE_URL "
    fi
    
    if ! grep -q "ALPACA_API_KEY" "$DEV_DIR/.env"; then
        MISSING="${MISSING}ALPACA_API_KEY "
    fi
    
    if ! grep -q "ALPACA_SECRET_KEY" "$DEV_DIR/.env"; then
        MISSING="${MISSING}ALPACA_SECRET_KEY "
    fi
    
    if [ -z "$MISSING" ]; then
        echo -e "${GREEN}✓ Environment file found with required variables${NC}"
    else
        echo -e "${YELLOW}⚠ Warning: Missing variables: $MISSING${NC}"
    fi
else
    echo -e "${RED}Error: .env file not found at $DEV_DIR/.env${NC}"
    echo "Create .env with at minimum:"
    echo "  DATABASE_URL=postgresql://..."
    echo "  ALPACA_API_KEY=PKxxx"
    echo "  ALPACA_SECRET_KEY=xxx"
    echo "  ALPACA_BASE_URL=https://paper-api.alpaca.markets"
    echo "  ANTHROPIC_API_KEY=sk-ant-..."
    exit 1
fi

# Step 5: Check for required Python packages
echo -e "${YELLOW}Step 5: Checking Python dependencies...${NC}"
VENV_PIP="$DEV_DIR/venv/bin/pip"
if [ -f "$VENV_PIP" ]; then
    # Check for alpaca-py
    if $VENV_PIP show alpaca-py > /dev/null 2>&1; then
        echo -e "${GREEN}✓ alpaca-py installed${NC}"
    else
        echo -e "${YELLOW}Installing alpaca-py...${NC}"
        $VENV_PIP install alpaca-py
    fi
    
    # Check for asyncpg
    if $VENV_PIP show asyncpg > /dev/null 2>&1; then
        echo -e "${GREEN}✓ asyncpg installed${NC}"
    else
        echo -e "${YELLOW}Installing asyncpg...${NC}"
        $VENV_PIP install asyncpg
    fi
    
    # Check for anthropic
    if $VENV_PIP show anthropic > /dev/null 2>&1; then
        echo -e "${GREEN}✓ anthropic installed${NC}"
    else
        echo -e "${YELLOW}Installing anthropic...${NC}"
        $VENV_PIP install anthropic
    fi
else
    echo -e "${YELLOW}⚠ Warning: Virtual environment not found, skipping dependency check${NC}"
fi

# Step 6: Reload systemd
echo -e "${YELLOW}Step 6: Reloading systemd...${NC}"
systemctl daemon-reload
echo -e "${GREEN}✓ Systemd reloaded${NC}"

# Step 7: Enable service
echo -e "${YELLOW}Step 7: Enabling service for auto-start...${NC}"
systemctl enable $SERVICE_NAME
echo -e "${GREEN}✓ Service enabled${NC}"

# Step 8: Start service
echo -e "${YELLOW}Step 8: Starting service...${NC}"
systemctl start $SERVICE_NAME
sleep 2

# Step 9: Verify
echo -e "${YELLOW}Step 9: Verifying installation...${NC}"
if systemctl is-active --quiet $SERVICE_NAME; then
    echo -e "${GREEN}✓ Service is running${NC}"
else
    echo -e "${RED}✗ Service failed to start${NC}"
    echo "Check logs: journalctl -u $SERVICE_NAME -n 50"
    exit 1
fi

echo ""
echo -e "${GREEN}=========================================="
echo "Installation Complete!"
echo -e "==========================================${NC}"
echo ""
echo "Service Status:"
systemctl status $SERVICE_NAME --no-pager | head -10
echo ""
echo "Commands:"
echo "  View logs:      journalctl -u $SERVICE_NAME -f"
echo "  Stop service:   systemctl stop $SERVICE_NAME"
echo "  Restart:        systemctl restart $SERVICE_NAME"
echo "  Status:         systemctl status $SERVICE_NAME"
echo ""
echo "The service will:"
echo "  • Check ALL open positions every 5 minutes"
echo "  • Execute exits when signals indicate"
echo "  • Sleep during market closed hours (outside 9:30 AM - 4:00 PM ET)"
echo "  • Auto-restart on failure"
echo ""
echo "Market Hours: 9:30 AM - 4:00 PM ET (Monday-Friday)"
echo "Broker: Alpaca"
echo "Agent: dev_claude"
echo ""
