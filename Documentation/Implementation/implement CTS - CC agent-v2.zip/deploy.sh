#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: deploy.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Deploy dev_claude Claude Code agent to US droplet
#
# Usage: ./deploy.sh
# ============================================================================

set -e

echo "=== Deploying dev_claude Claude Code Agent ==="
echo ""

# Check if we're on the target droplet
if [ ! -d "/root" ]; then
    echo "ERROR: This script should be run on the US droplet as root"
    exit 1
fi

# Create directory structure
echo "Creating directory structure..."
mkdir -p /root/catalyst-dev/{tools,helpers,config,logs,sql}

# Copy files
echo "Copying files..."

# CLAUDE.md (the brain)
if [ -f "CLAUDE.md" ]; then
    cp CLAUDE.md /root/catalyst-dev/
fi

# Tools
for tool in scan quote technicals news portfolio account check-risk trade close close-all log; do
    if [ -f "tools/${tool}.sh" ]; then
        cp "tools/${tool}.sh" /root/catalyst-dev/tools/
    fi
done

# Make tools executable
chmod +x /root/catalyst-dev/tools/*.sh

# Helpers
if [ -f "helpers/alpaca_helper.py" ]; then
    cp helpers/alpaca_helper.py /root/catalyst-dev/helpers/
fi

# Config
if [ -f "config/limits.yaml" ]; then
    cp config/limits.yaml /root/catalyst-dev/config/
fi

if [ -f "config/.env.example" ]; then
    cp config/.env.example /root/catalyst-dev/config/
fi

# Check for existing .env
if [ ! -f "/root/catalyst-dev/config/.env" ]; then
    echo ""
    echo "⚠️  No .env file found. Creating from template..."
    cp /root/catalyst-dev/config/.env.example /root/catalyst-dev/config/.env
    echo "   IMPORTANT: Edit /root/catalyst-dev/config/.env with your credentials!"
fi

# Install dependencies
echo ""
echo "Installing Python dependencies..."
pip3 install requests pyyaml --break-system-packages 2>/dev/null || pip3 install requests pyyaml

# Optional: Install Alpaca SDK
echo "Installing Alpaca SDK (optional)..."
pip3 install alpaca-py --break-system-packages 2>/dev/null || pip3 install alpaca-py || echo "  (Alpaca SDK optional - will use REST API fallback)"

# Verify jq is installed (for bash JSON parsing)
if ! command -v jq &> /dev/null; then
    echo "Installing jq..."
    apt-get update && apt-get install -y jq
fi

# Verify bc is installed (for math)
if ! command -v bc &> /dev/null; then
    echo "Installing bc..."
    apt-get install -y bc
fi

# Verify psql is installed
if ! command -v psql &> /dev/null; then
    echo "Installing postgresql-client..."
    apt-get install -y postgresql-client
fi

# Install cron schedule (optional)
echo ""
read -p "Install cron schedule for autonomous trading? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    if [ -f "config/catalyst-dev-claude-code.cron" ]; then
        cp config/catalyst-dev-claude-code.cron /etc/cron.d/catalyst-dev-claude-code
        chmod 644 /etc/cron.d/catalyst-dev-claude-code
        systemctl restart cron
        echo "✅ Cron schedule installed"
    fi
fi

# Verify Claude Code is installed
echo ""
if command -v claude &> /dev/null; then
    echo "✅ Claude Code CLI found"
else
    echo "⚠️  Claude Code CLI not found"
    echo "   Install from: https://github.com/anthropics/claude-code"
fi

# Summary
echo ""
echo "=== Deployment Complete ==="
echo ""
echo "Directory: /root/catalyst-dev/"
echo ""
echo "Files:"
ls -la /root/catalyst-dev/
echo ""
echo "Tools:"
ls -la /root/catalyst-dev/tools/
echo ""
echo "Next steps:"
echo "  1. Edit /root/catalyst-dev/config/.env with your Alpaca credentials"
echo "  2. Test tools: cd /root/catalyst-dev && source config/.env && ./tools/account.sh"
echo "  3. Run Claude Code: cd /root/catalyst-dev && claude"
echo ""
echo "Manual test sequence:"
echo "  ./tools/account.sh    # Check account"
echo "  ./tools/scan.sh       # Scan market"
echo "  ./tools/quote.sh AAPL # Get quote"
echo "  ./tools/portfolio.sh  # Check positions"
