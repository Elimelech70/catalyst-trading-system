#!/usr/bin/env python3
"""
Name of Application: Catalyst Trading System
Name of file: validate_system_readiness.py
Version: 1.0.0
Last Updated: 2025-12-28
Purpose: Comprehensive system validation before market open

REVISION HISTORY:
v1.0.0 (2025-12-28) - Initial validation script
  - Infrastructure checks
  - Database verification
  - Consciousness framework tests
  - Trading system validation
  - C1/C2 fix verification

USAGE:
    python3 validate_system_readiness.py
    
    Exit codes:
      0 = All checks passed - READY FOR TRADING
      1 = Some checks failed - REVIEW REQUIRED
      2 = Critical failure - DO NOT TRADE
"""

import asyncio
import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from typing import Tuple, List, Dict, Any

# ============================================================================
# CONFIGURATION
# ============================================================================

# Add paths for imports
SHARED_COMMON_PATH = "/root/catalyst-trading-system/services/shared/common"
sys.path.insert(0, SHARED_COMMON_PATH)

# Results tracking
RESULTS = {
    'passed': 0,
    'failed': 0,
    'warnings': 0,
    'critical': False,
    'details': []
}

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def print_header(title: str):
    """Print section header."""
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)


def print_subheader(title: str):
    """Print subsection header."""
    print()
    print(f"--- {title} ---")


def record_result(name: str, passed: bool, details: str = "", critical: bool = False, warning: bool = False):
    """Record and print a test result."""
    if passed:
        status = "✅ PASS"
        RESULTS['passed'] += 1
    elif warning:
        status = "⚠️  WARN"
        RESULTS['warnings'] += 1
    else:
        status = "❌ FAIL"
        RESULTS['failed'] += 1
        if critical:
            RESULTS['critical'] = True
    
    print(f"  {status}: {name}")
    if details:
        print(f"          {details}")
    
    RESULTS['details'].append({
        'name': name,
        'passed': passed,
        'warning': warning,
        'critical': critical,
        'details': details
    })
    
    return passed


def run_command(cmd: str) -> Tuple[bool, str]:
    """Run a shell command and return success status and output."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=30
        )
        return result.returncode == 0, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return False, "Command timed out"
    except Exception as e:
        return False, str(e)


# ============================================================================
# INFRASTRUCTURE CHECKS
# ============================================================================

def check_infrastructure():
    """Check infrastructure health."""
    print_header("INFRASTRUCTURE CHECKS")
    
    # Check Docker is running
    print_subheader("Docker")
    success, output = run_command("docker ps --format '{{.Names}}: {{.Status}}'")
    if success:
        record_result("Docker is running", True)
        
        # Check specific services
        required_services = [
            'catalyst-trading', 'catalyst-workflow', 'catalyst-risk-manager',
            'catalyst-scanner', 'catalyst-coordination'
        ]
        for service in required_services:
            if service in output:
                record_result(f"Service {service} running", True)
            else:
                record_result(f"Service {service} running", False, "Not found", critical=True)
    else:
        record_result("Docker is running", False, "Docker not responding", critical=True)
    
    # Check disk space
    print_subheader("System Resources")
    success, output = run_command("df -h / | tail -1 | awk '{print $5}'")
    if success:
        usage = output.strip().replace('%', '')
        try:
            usage_int = int(usage)
            if usage_int < 80:
                record_result("Disk space", True, f"{usage}% used")
            elif usage_int < 90:
                record_result("Disk space", True, f"{usage}% used", warning=True)
            else:
                record_result("Disk space", False, f"{usage}% used - CRITICAL", critical=True)
        except:
            record_result("Disk space", False, "Could not parse")
    
    # Check memory
    success, output = run_command("free -m | grep Mem | awk '{print $7}'")
    if success:
        try:
            available_mb = int(output.strip())
            if available_mb > 500:
                record_result("Memory available", True, f"{available_mb}MB free")
            else:
                record_result("Memory available", False, f"Only {available_mb}MB free", warning=True)
        except:
            record_result("Memory available", False, "Could not parse")


# ============================================================================
# DATABASE CHECKS
# ============================================================================

async def check_database():
    """Check database connectivity and schema."""
    print_header("DATABASE CHECKS")
    
    database_url = os.environ.get('DATABASE_URL')
    research_url = os.environ.get('RESEARCH_DATABASE_URL')
    
    if not database_url:
        record_result("DATABASE_URL set", False, "Environment variable missing", critical=True)
        return
    else:
        record_result("DATABASE_URL set", True)
    
    if not research_url:
        record_result("RESEARCH_DATABASE_URL set", False, "Environment variable missing", critical=True)
        return
    else:
        record_result("RESEARCH_DATABASE_URL set", True)
    
    try:
        import asyncpg
    except ImportError:
        record_result("asyncpg available", False, "Module not installed", critical=True)
        return
    
    record_result("asyncpg available", True)
    
    # Trading database
    print_subheader("Trading Database")
    try:
        conn = await asyncpg.connect(database_url)
        record_result("Trading DB connection", True)
        
        # Check orders table (C1 fix)
        orders_exists = await conn.fetchval("""
            SELECT EXISTS (
                SELECT 1 FROM information_schema.tables 
                WHERE table_name = 'orders'
            )
        """)
        record_result("Orders table exists (C1)", orders_exists, 
                     "" if orders_exists else "C1 fix not applied", critical=not orders_exists)
        
        # Check positions has no alpaca columns
        alpaca_cols = await conn.fetch("""
            SELECT column_name FROM information_schema.columns 
            WHERE table_name = 'positions' 
            AND column_name LIKE 'alpaca%'
        """)
        no_alpaca = len(alpaca_cols) == 0
        record_result("Positions clean (no alpaca cols)", no_alpaca,
                     f"Found: {[r['column_name'] for r in alpaca_cols]}" if not no_alpaca else "")
        
        # Check claude_outputs table
        outputs_exists = await conn.fetchval("""
            SELECT EXISTS (
                SELECT 1 FROM information_schema.tables 
                WHERE table_name = 'claude_outputs'
            )
        """)
        record_result("claude_outputs table exists", outputs_exists)
        
        # Check for stuck orders
        stuck = await conn.fetchval("""
            SELECT COUNT(*) FROM orders 
            WHERE status IN ('submitted', 'pending', 'accepted')
            AND submitted_at < NOW() - INTERVAL '1 hour'
        """)
        record_result("No stuck orders", stuck == 0, 
                     f"{stuck} orders stuck > 1 hour" if stuck > 0 else "")
        
        await conn.close()
        
    except Exception as e:
        record_result("Trading DB connection", False, str(e), critical=True)
    
    # Research database
    print_subheader("Research Database (Consciousness)")
    try:
        conn = await asyncpg.connect(research_url)
        record_result("Research DB connection", True)
        
        # Check consciousness tables
        tables = await conn.fetch("""
            SELECT table_name FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name LIKE 'claude_%'
        """)
        table_names = [t['table_name'] for t in tables]
        
        required_tables = [
            'claude_state', 'claude_messages', 'claude_observations',
            'claude_learnings', 'claude_questions'
        ]
        
        for table in required_tables:
            exists = table in table_names
            record_result(f"Table {table} exists", exists, critical=not exists)
        
        # Check agent states
        agents = await conn.fetch("SELECT agent_id, current_mode FROM claude_state")
        record_result(f"Agent states initialized", len(agents) >= 3, 
                     f"Found {len(agents)} agents")
        
        await conn.close()
        
    except Exception as e:
        record_result("Research DB connection", False, str(e), critical=True)


# ============================================================================
# CONSCIOUSNESS FRAMEWORK CHECKS
# ============================================================================

async def check_consciousness():
    """Check consciousness framework."""
    print_header("CONSCIOUSNESS FRAMEWORK CHECKS")
    
    # Check module imports
    print_subheader("Module Imports")
    
    modules = [
        ('consciousness', 'ClaudeConsciousness'),
        ('database', 'DatabaseManager'),
        ('alerts', 'AlertManager'),
        ('doctor_claude', 'DoctorClaude')
    ]
    
    for module_name, class_name in modules:
        try:
            module = __import__(module_name)
            cls = getattr(module, class_name)
            record_result(f"{module_name}.py imports", True)
        except Exception as e:
            record_result(f"{module_name}.py imports", False, str(e), critical=True)
    
    # Test consciousness functionality
    print_subheader("Consciousness Functionality")
    
    research_url = os.environ.get('RESEARCH_DATABASE_URL')
    if not research_url:
        record_result("Consciousness test", False, "No RESEARCH_DATABASE_URL", critical=True)
        return
    
    try:
        import asyncpg
        from consciousness import ClaudeConsciousness
        
        pool = await asyncpg.create_pool(research_url, min_size=1, max_size=2)
        
        # Use test agent
        c = ClaudeConsciousness('validation_test', pool)
        
        # Test wake up
        state = await c.wake_up()
        record_result("Consciousness wake_up()", True, f"Agent: {state.agent_id}")
        
        # Test observe
        obs_id = await c.observe('system', 'Validation', 'Pre-market validation test', 0.99)
        record_result("Consciousness observe()", True, f"Observation ID: {obs_id}")
        
        # Test sleep
        await c.sleep("Validation complete")
        record_result("Consciousness sleep()", True)
        
        # Clean up
        async with pool.acquire() as conn:
            await conn.execute("DELETE FROM claude_state WHERE agent_id = 'validation_test'")
            await conn.execute("DELETE FROM claude_observations WHERE agent_id = 'validation_test'")
        
        await pool.close()
        
    except Exception as e:
        record_result("Consciousness functionality", False, str(e), critical=True)


# ============================================================================
# TRADING SYSTEM CHECKS
# ============================================================================

def check_trading_system():
    """Check trading system components."""
    print_header("TRADING SYSTEM CHECKS")
    
    # Check Alpaca credentials
    print_subheader("Alpaca API")
    
    api_key = os.environ.get('ALPACA_API_KEY')
    secret_key = os.environ.get('ALPACA_SECRET_KEY')
    
    if not api_key or not secret_key:
        record_result("Alpaca credentials set", False, "Missing API keys", critical=True)
    else:
        record_result("Alpaca credentials set", True)
        
        # Test connection
        try:
            from alpaca.trading.client import TradingClient
            
            client = TradingClient(api_key, secret_key, paper=True)
            account = client.get_account()
            
            record_result("Alpaca connection", True, f"Status: {account.status}")
            record_result("Account active", account.status == 'ACTIVE',
                         f"Status: {account.status}", critical=account.status != 'ACTIVE')
            
            buying_power = float(account.buying_power)
            record_result("Buying power available", buying_power > 1000,
                         f"${buying_power:,.2f}")
            
        except Exception as e:
            record_result("Alpaca connection", False, str(e), critical=True)
    
    # Check alpaca_trader.py
    print_subheader("alpaca_trader.py (C2 Fix)")
    
    auth_path = Path(f"{SHARED_COMMON_PATH}/alpaca_trader.py")
    if auth_path.exists():
        record_result("Authoritative alpaca_trader.py exists", True)
        
        # Check version
        content = auth_path.read_text()
        if 'Version: 2.0.0' in content or 'v2.0.0' in content:
            record_result("alpaca_trader.py version 2.0.0", True)
        else:
            record_result("alpaca_trader.py version 2.0.0", False, "Old version", warning=True)
        
        # Test order side mapping
        try:
            from alpaca_trader import map_side
            from alpaca.trading.enums import OrderSide
            
            tests = [
                ('buy', OrderSide.BUY),
                ('long', OrderSide.BUY),
                ('sell', OrderSide.SELL),
                ('short', OrderSide.SELL),
            ]
            
            all_passed = True
            for input_side, expected in tests:
                result = map_side(input_side)
                if result != expected:
                    all_passed = False
            
            record_result("Order side mapping correct", all_passed,
                         "" if all_passed else "Mapping errors detected", critical=not all_passed)
            
        except Exception as e:
            record_result("Order side mapping", False, str(e), critical=True)
        
        # Test price rounding
        try:
            from alpaca_trader import round_price
            
            tests = [
                (9.050000190734863, 9.05),
                (150.999999, 151.0),
                (None, None),
            ]
            
            all_passed = True
            for input_price, expected in tests:
                result = round_price(input_price)
                if result != expected:
                    all_passed = False
            
            record_result("Price rounding correct", all_passed,
                         "" if all_passed else "Rounding errors detected")
            
        except Exception as e:
            record_result("Price rounding", False, str(e))
    
    else:
        record_result("Authoritative alpaca_trader.py exists", False, 
                     f"Not found at {auth_path}", critical=True)
    
    # Check symlinks
    symlink_paths = [
        "/root/catalyst-trading-system/services/trading/common/alpaca_trader.py",
        "/root/catalyst-trading-system/services/risk-manager/common/alpaca_trader.py",
        "/root/catalyst-trading-system/services/workflow/common/alpaca_trader.py",
    ]
    
    for symlink in symlink_paths:
        path = Path(symlink)
        if path.is_symlink():
            target = path.resolve()
            correct = str(target) == str(auth_path)
            record_result(f"Symlink {path.parent.parent.name}", correct,
                         f"Points to {'correct' if correct else 'wrong'} location")
        elif path.exists():
            record_result(f"Symlink {path.parent.parent.name}", False, 
                         "Regular file, should be symlink", warning=True)


# ============================================================================
# CRON CHECKS
# ============================================================================

def check_cron():
    """Check cron configuration."""
    print_header("CRON CHECKS")
    
    success, output = run_command("crontab -l")
    
    if success and output.strip():
        record_result("Cron jobs configured", True)
        
        # Check for key entries
        if 'catalyst' in output.lower() or 'workflow' in output.lower():
            record_result("Trading cron jobs present", True)
        else:
            record_result("Trading cron jobs present", False, 
                         "No catalyst/workflow entries found", warning=True)
    else:
        record_result("Cron jobs configured", False, "No cron jobs found", warning=True)


# ============================================================================
# MAIN
# ============================================================================

async def main():
    """Run all validation checks."""
    start_time = datetime.now(timezone.utc)
    
    print()
    print("╔══════════════════════════════════════════════════════════════════╗")
    print("║     CATALYST TRADING SYSTEM - PRE-MARKET VALIDATION              ║")
    print("║     December 30, 2025 Readiness Check                            ║")
    print("╚══════════════════════════════════════════════════════════════════╝")
    print()
    print(f"  Started: {start_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    
    # Run all checks
    check_infrastructure()
    await check_database()
    await check_consciousness()
    check_trading_system()
    check_cron()
    
    # Summary
    print_header("VALIDATION SUMMARY")
    
    duration = (datetime.now(timezone.utc) - start_time).total_seconds()
    
    print(f"  Duration: {duration:.1f} seconds")
    print()
    print(f"  ✅ Passed:   {RESULTS['passed']}")
    print(f"  ⚠️  Warnings: {RESULTS['warnings']}")
    print(f"  ❌ Failed:   {RESULTS['failed']}")
    print()
    
    if RESULTS['critical']:
        print("  🚨 CRITICAL FAILURES DETECTED")
        print("  ⛔ DO NOT PROCEED WITH TRADING")
        print()
        print("  Critical issues:")
        for item in RESULTS['details']:
            if item.get('critical') and not item.get('passed'):
                print(f"    • {item['name']}: {item['details']}")
        return 2
    
    elif RESULTS['failed'] > 0:
        print("  ⚠️  SOME CHECKS FAILED")
        print("  Review failures before proceeding:")
        print()
        for item in RESULTS['details']:
            if not item.get('passed') and not item.get('warning'):
                print(f"    • {item['name']}: {item['details']}")
        return 1
    
    elif RESULTS['warnings'] > 0:
        print("  ✅ PASSED WITH WARNINGS")
        print("  System is ready, but review warnings:")
        print()
        for item in RESULTS['details']:
            if item.get('warning'):
                print(f"    • {item['name']}: {item['details']}")
        return 0
    
    else:
        print("  🎉 ALL CHECKS PASSED")
        print("  ✅ SYSTEM READY FOR TRADING")
        return 0


if __name__ == '__main__':
    exit_code = asyncio.run(main())
    print()
    sys.exit(exit_code)
