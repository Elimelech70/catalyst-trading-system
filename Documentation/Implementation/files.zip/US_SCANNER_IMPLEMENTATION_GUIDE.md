# ==============================================================================
# US SCANNER IMPLEMENTATION GUIDE
# ==============================================================================
# Name of Application: Catalyst Trading System
# Name of file: US_SCANNER_IMPLEMENTATION_GUIDE.md
# Version: 1.0.0
# Last Updated: 2026-01-16
# Purpose: Step-by-step guide to implement full market scanning for US markets
# ==============================================================================

# US Scanner Implementation Guide (dev_claude)

**Date**: 2026-01-16
**Version**: 1.0.0
**Market**: US (NYSE/NASDAQ)
**Broker**: Alpaca

---

## Overview

This guide implements full market scanning capability for the US trading agent.
It uses Alpaca's built-in Screener API for most actives and market movers.

### Key Difference from HKEX

| Aspect | HKEX (intl_claude) | US (dev_claude) |
|--------|-------------------|------------------|
| Screener | Manual plate scanning | Alpaca Screener API |
| Data Source | get_plate_stock() | get_most_actives() |
| Movers | N/A | get_market_movers() |
| Batch Quotes | get_quotes_batch() | get_snapshots_batch() |

### Files Changed

| File | Version | Change Type |
|------|---------|-------------|
| `unified_agent.py` (AlpacaClient) | 1.0.0 → 1.1.0 | ADD methods |
| `unified_agent.py` (_scan_market) | 1.0.0 → 1.1.0 | REPLACE method |
| `config/dev_claude_config.yaml` | - | ADD section |

---

## Step 1: Update AlpacaClient Class

### 1.1 Add Imports

At the top of `unified_agent.py`, add these imports:

```python
from alpaca.data.historical.screener import ScreenerClient
from alpaca.data.requests import (
    MostActivesRequest, 
    MarketMoversRequest,
    StockLatestQuoteRequest,
    StockSnapshotRequest,
)
from alpaca.data.enums import MostActivesBy
```

### 1.2 Update __init__ Method

In `AlpacaClient.__init__()`, add after `self.data_client`:

```python
# Screener client for most actives and market movers
self.screener_client = ScreenerClient(
    api_key=self.api_key,
    secret_key=self.secret_key
)

# Store additional request classes
self._MostActivesRequest = MostActivesRequest
self._MarketMoversRequest = MarketMoversRequest
self._StockLatestQuoteRequest = StockLatestQuoteRequest
self._StockSnapshotRequest = StockSnapshotRequest
self._MostActivesBy = MostActivesBy
```

### 1.3 Add Scanner Methods

Add these methods to `AlpacaClient` class:

```python
def get_most_actives(self, by: str = "volume", top: int = 20) -> list:
    """Get most active stocks by volume or trade count."""
    try:
        by_enum = (
            self._MostActivesBy.VOLUME if by.lower() == "volume" 
            else self._MostActivesBy.TRADES
        )
        
        request = self._MostActivesRequest(top=min(top, 100), by=by_enum)
        response = self.screener_client.get_most_actives(request)
        
        actives = []
        for stock in response.most_actives:
            actives.append({
                "symbol": stock.symbol,
                "volume": stock.volume,
                "trade_count": stock.trade_count,
            })
        
        logger.info(f"Got {len(actives)} most active stocks by {by}")
        return actives
        
    except Exception as e:
        logger.error(f"Failed to get most actives: {e}")
        return []


def get_market_movers(self, top: int = 20) -> dict:
    """Get top market movers (gainers and losers)."""
    try:
        request = self._MarketMoversRequest(top=min(top, 50))
        response = self.screener_client.get_market_movers(request)
        
        gainers = []
        for mover in response.gainers:
            gainers.append({
                "symbol": mover.symbol,
                "price": mover.price,
                "change": mover.change,
                "change_pct": mover.percent_change,
            })
        
        losers = []
        for mover in response.losers:
            losers.append({
                "symbol": mover.symbol,
                "price": mover.price,
                "change": mover.change,
                "change_pct": mover.percent_change,
            })
        
        logger.info(f"Got {len(gainers)} gainers and {len(losers)} losers")
        return {"gainers": gainers, "losers": losers}
        
    except Exception as e:
        logger.error(f"Failed to get market movers: {e}")
        return {"gainers": [], "losers": []}


def get_snapshots_batch(self, symbols: list) -> dict:
    """Get snapshots (quote + trade + bar) for multiple symbols."""
    if not symbols:
        return {}
    
    try:
        request = self._StockSnapshotRequest(symbol_or_symbols=symbols)
        snapshots = self.data_client.get_stock_snapshot(request)
        
        result = {}
        for symbol, snap in snapshots.items():
            trade = snap.latest_trade
            quote = snap.latest_quote
            daily_bar = snap.daily_bar
            prev_daily = snap.previous_daily_bar
            
            prev_close = float(prev_daily.close) if prev_daily else 0
            current = float(trade.price) if trade else 0
            change = current - prev_close if prev_close else 0
            change_pct = (change / prev_close * 100) if prev_close else 0
            
            result[symbol] = {
                "symbol": symbol,
                "price": current,
                "bid": float(quote.bid_price) if quote and quote.bid_price else 0,
                "ask": float(quote.ask_price) if quote and quote.ask_price else 0,
                "volume": int(daily_bar.volume) if daily_bar else 0,
                "prev_close": prev_close,
                "change": round(change, 2),
                "change_pct": round(change_pct, 2),
                "high": float(daily_bar.high) if daily_bar else 0,
                "low": float(daily_bar.low) if daily_bar else 0,
                "vwap": float(daily_bar.vwap) if daily_bar and daily_bar.vwap else 0,
            }
        
        logger.info(f"Got snapshots for {len(result)} symbols")
        return result
        
    except Exception as e:
        logger.error(f"Failed to get snapshots: {e}")
        return {}


def scan_market(
    self,
    min_volume: int = 500_000,
    min_change_pct: float = 1.0,
    max_change_pct: float = 15.0,
    min_price: float = 5.0,
    max_price: float = 500.0,
    include_gainers: bool = True,
    include_losers: bool = False,
    top_actives: int = 50,
    top_n: int = 10,
) -> list:
    """Scan US market for trading candidates."""
    logger.info("Starting US market scan...")
    
    # Get most actives
    try:
        actives = self.get_most_actives(by="volume", top=top_actives)
        active_symbols = [a["symbol"] for a in actives]
        logger.info(f"Got {len(active_symbols)} most active stocks")
    except Exception as e:
        logger.error(f"Failed to get most actives: {e}")
        active_symbols = []
    
    # Get market movers
    all_symbols = set(active_symbols)
    try:
        movers = self.get_market_movers(top=20)
        
        if include_gainers:
            all_symbols.update([g["symbol"] for g in movers.get("gainers", [])])
        
        if include_losers:
            all_symbols.update([l["symbol"] for l in movers.get("losers", [])])
            
    except Exception as e:
        logger.error(f"Failed to get market movers: {e}")
    
    if not all_symbols:
        logger.warning("No symbols to scan")
        return []
    
    symbols_list = list(all_symbols)
    logger.info(f"Total unique symbols: {len(symbols_list)}")
    
    # Get snapshots
    try:
        snapshots = self.get_snapshots_batch(symbols_list)
    except Exception as e:
        logger.error(f"Failed to get snapshots: {e}")
        return []
    
    # Filter and score
    candidates = []
    for symbol, snap in snapshots.items():
        try:
            price = snap.get("price", 0)
            change_pct = snap.get("change_pct", 0)
            volume = snap.get("volume", 0)
            
            if not price or not volume:
                continue
            
            if price < min_price or price > max_price:
                continue
            
            abs_change = abs(change_pct)
            if abs_change < min_change_pct or abs_change > max_change_pct:
                continue
            
            if volume < min_volume:
                continue
            
            # Scoring
            if 2 <= abs_change <= 5:
                momentum_score = 0.4
            elif 1 <= abs_change < 2:
                momentum_score = 0.25
            elif 5 < abs_change <= 8:
                momentum_score = 0.3
            else:
                momentum_score = 0.15
            
            if volume >= 10_000_000:
                volume_score = 0.3
            elif volume >= 5_000_000:
                volume_score = 0.25
            elif volume >= 1_000_000:
                volume_score = 0.2
            else:
                volume_score = 0.15
            
            if 20 <= price <= 200:
                price_score = 0.15
            elif 10 <= price < 20 or 200 < price <= 400:
                price_score = 0.1
            else:
                price_score = 0.05
            
            bid = snap.get("bid", 0)
            ask = snap.get("ask", 0)
            if bid > 0 and ask > 0:
                spread_pct = (ask - bid) / bid * 100
                spread_score = 0.15 if spread_pct < 0.1 else (0.1 if spread_pct < 0.3 else 0.05)
            else:
                spread_score = 0.05
            
            composite_score = momentum_score + volume_score + price_score + spread_score
            
            candidates.append({
                "symbol": symbol,
                "price": round(price, 2),
                "change_pct": round(change_pct, 2),
                "volume": volume,
                "volume_m": round(volume / 1_000_000, 1),
                "bid": snap.get("bid", 0),
                "ask": snap.get("ask", 0),
                "composite_score": round(composite_score, 2),
            })
            
        except Exception as e:
            logger.warning(f"Error processing {symbol}: {e}")
            continue
    
    candidates.sort(key=lambda x: x["composite_score"], reverse=True)
    top_candidates = candidates[:top_n]
    
    logger.info(f"Scan complete: {len(candidates)} passed, returning top {len(top_candidates)}")
    return top_candidates
```

---

## Step 2: Update _scan_market Method

### 2.1 In ToolExecutor Class

Find the existing `_scan_market` method in `ToolExecutor` class and replace:

```python
async def _scan_market(self, inputs: Dict) -> Dict:
    """Scan market for trading candidates using Alpaca Screener API."""
    logger.info("Scanning US market for trading candidates...")
    
    config = self.config.get('scanner', {})
    
    limit = min(inputs.get('limit', config.get('top_n', 10)), 20)
    min_volume = inputs.get('min_volume', config.get('min_volume', 500_000))
    min_change_pct = inputs.get('min_change_pct', config.get('min_change_pct', 1.0))
    max_change_pct = inputs.get('max_change_pct', config.get('max_change_pct', 15.0))
    min_price = inputs.get('min_price', config.get('min_price', 5.0))
    max_price = inputs.get('max_price', config.get('max_price', 500.0))
    include_gainers = inputs.get('include_gainers', config.get('include_gainers', True))
    include_losers = inputs.get('include_losers', config.get('include_losers', False))
    
    if hasattr(self.broker, 'scan_market'):
        try:
            candidates = self.broker.scan_market(
                min_volume=min_volume,
                min_change_pct=min_change_pct,
                max_change_pct=max_change_pct,
                min_price=min_price,
                max_price=max_price,
                include_gainers=include_gainers,
                include_losers=include_losers,
                top_actives=50,
                top_n=limit,
            )
            
            if candidates:
                logger.info(f"Scan found {len(candidates)} candidates")
                for i, c in enumerate(candidates[:5], 1):
                    logger.info(
                        f"  #{i}: {c.get('symbol')} "
                        f"${c.get('price', 0):.2f} "
                        f"({c.get('change_pct', 0):+.1f}%) "
                        f"score={c.get('composite_score', 0):.2f}"
                    )
                
                return {
                    'candidates_found': len(candidates),
                    'candidates': candidates,
                    'timestamp': datetime.now(ET).isoformat()
                }
                
        except Exception as e:
            logger.error(f"Broker scan failed: {e}")
    
    # Fallback to watchlist
    logger.warning("Falling back to curated watchlist")
    watchlist = config.get('watchlist', ['AAPL', 'TSLA', 'NVDA', 'AMD', 'META'])
    
    candidates = []
    for symbol in watchlist[:limit]:
        try:
            quote = self.broker.get_quote(symbol)
            if 'error' not in quote:
                candidates.append({
                    'symbol': symbol,
                    'price': quote.get('mid', 0),
                    'composite_score': 0.5,
                })
        except Exception as e:
            logger.warning(f"Error getting quote for {symbol}: {e}")
    
    return {
        'candidates_found': len(candidates),
        'candidates': candidates,
        'timestamp': datetime.now(ET).isoformat(),
        'source': 'watchlist_fallback'
    }
```

---

## Step 3: Update Config File

Add scanner section to `config/dev_claude_config.yaml`:

```yaml
scanner:
  min_volume: 500000
  min_change_pct: 1.0
  max_change_pct: 15.0
  min_price: 5.0
  max_price: 500.0
  include_gainers: true
  include_losers: false
  top_actives: 50
  top_n: 10
  watchlist:
    - "AAPL"
    - "TSLA"
    - "NVDA"
    - "AMD"
    - "META"
    - "GOOGL"
    - "AMZN"
    - "MSFT"
    - "SPY"
    - "QQQ"
```

---

## Step 4: Test

### 4.1 Test AlpacaClient Scanner

```bash
cd /root/catalyst-dev
source venv/bin/activate
source .env

python3 -c "
# Assuming AlpacaClient is in unified_agent.py
import sys
sys.path.insert(0, '.')

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.historical.screener import ScreenerClient
from alpaca.data.requests import MostActivesRequest, MarketMoversRequest
from alpaca.data.enums import MostActivesBy
import os

api_key = os.getenv('ALPACA_API_KEY')
secret_key = os.getenv('ALPACA_SECRET_KEY')

screener = ScreenerClient(api_key=api_key, secret_key=secret_key)

# Test most actives
request = MostActivesRequest(top=10, by=MostActivesBy.VOLUME)
response = screener.get_most_actives(request)
print('Most Actives:')
for stock in response.most_actives[:5]:
    print(f'  {stock.symbol}: vol={stock.volume:,}')

# Test market movers
request = MarketMoversRequest(top=10)
movers = screener.get_market_movers(request)
print('\nTop Gainers:')
for g in movers.gainers[:5]:
    print(f'  {g.symbol}: \${g.price:.2f} ({g.percent_change:+.1f}%)')
"
```

### 4.2 Test Full Scan

```bash
python3 unified_agent.py --mode scan
```

### 4.3 Expected Output

```
2026-01-16 09:35:00 - Scanning US market for trading candidates...
2026-01-16 09:35:01 - Got 50 most active stocks by volume
2026-01-16 09:35:01 - Got 20 gainers and 20 losers
2026-01-16 09:35:02 - Total unique symbols: 65
2026-01-16 09:35:03 - Got snapshots for 65 symbols
2026-01-16 09:35:03 - Scan complete: 28 passed, returning top 10
2026-01-16 09:35:03 - Scan found 10 candidates
2026-01-16 09:35:03 -   #1: TSLA $248.50 (+4.2%) vol=45.2M score=0.85
2026-01-16 09:35:03 -   #2: NVDA $142.30 (+3.1%) vol=38.5M score=0.80
...
```

---

## Troubleshooting

### "ScreenerClient not found"
- Update alpaca-py: `pip install --upgrade alpaca-py`
- Verify version: `pip show alpaca-py` (need v0.10+)

### "Subscription required" error
- Most actives/movers may require Alpaca data subscription
- Paper trading accounts may have limited access
- Fallback to watchlist will trigger automatically

### Empty scan results
- Check if market is open: `client.trading_client.get_clock()`
- Reduce filters: lower `min_change_pct` to 0.5
- Increase `top_actives` to 100

---

## Summary

| Component | Change | Lines |
|-----------|--------|-------|
| `AlpacaClient.__init__` | +6 lines | ~6 |
| `AlpacaClient` methods | +4 methods | ~200 |
| `ToolExecutor._scan_market` | Replace | ~60 |
| Config YAML | +1 section | ~25 |

**Total: ~290 lines of changes**

---

## Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    US SCANNER DATA FLOW                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ToolExecutor._scan_market(inputs)                              │
│           │                                                      │
│           ▼                                                      │
│  AlpacaClient.scan_market()                                     │
│           │                                                      │
│           ├── get_most_actives()     # Alpaca Screener API      │
│           │   └── ScreenerClient.get_most_actives()             │
│           │                                                      │
│           ├── get_market_movers()    # Alpaca Screener API      │
│           │   └── ScreenerClient.get_market_movers()            │
│           │                                                      │
│           └── get_snapshots_batch()  # Batch price data         │
│               └── StockHistoricalDataClient.get_stock_snapshot()│
│                      │                                           │
│                      ▼                                           │
│              Filter & Score                                      │
│              • Volume > 500K                                     │
│              • Price change 1-15%                                │
│              • Price $5-500                                      │
│              • Composite scoring                                 │
│                      │                                           │
│                      ▼                                           │
│              Return Top 10 Candidates                            │
└─────────────────────────────────────────────────────────────────┘
```

---

*US Scanner Implementation Guide v1.0.0*
*2026-01-16*
*Market: US (NYSE/NASDAQ)*
*Broker: Alpaca*
