#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: portfolio.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Get current portfolio positions
#
# Usage: ./tools/portfolio.sh
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

echo "Getting portfolio positions..."
echo ""

# Get all positions
POSITIONS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions")

# Check for errors
if echo "$POSITIONS" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$POSITIONS" | jq -r '.message')"
    exit 1
fi

# Count positions
POSITION_COUNT=$(echo "$POSITIONS" | jq 'length')

echo "=== PORTFOLIO: $POSITION_COUNT Position(s) ==="
echo ""

if [ "$POSITION_COUNT" -eq 0 ]; then
    echo "No open positions."
    echo ""
    echo "Tip: Use ./tools/scan.sh to find opportunities"
    exit 0
fi

# Display positions
echo "Symbol | Qty | Entry    | Current  | P&L      | P&L %"
echo "-------|-----|----------|----------|----------|-------"

echo "$POSITIONS" | jq -r '.[] | "\(.symbol) | \(.qty) | $\(.avg_entry_price | tonumber | . * 100 | floor / 100) | $\(.current_price | tonumber | . * 100 | floor / 100) | $\(.unrealized_pl | tonumber | . * 100 | floor / 100) | \(.unrealized_plpc | tonumber | . * 10000 | floor / 100)%"'

echo ""

# Calculate totals
TOTAL_VALUE=$(echo "$POSITIONS" | jq '[.[].market_value | tonumber] | add')
TOTAL_PL=$(echo "$POSITIONS" | jq '[.[].unrealized_pl | tonumber] | add')

printf "Total Market Value: \$%.2f\n" $TOTAL_VALUE
printf "Total Unrealized P&L: \$%.2f\n" $TOTAL_PL

echo ""
echo "---"
echo "Tip: Use ./tools/close.sh SYMBOL to close a position"
echo "Tip: Watch for 3% stop loss or 6%+ take profit signals"
