#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: check-risk.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Validate trade against risk limits before execution
#
# Usage: ./tools/check-risk.sh AAPL buy 10
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Load limits from config
LIMITS_FILE="$SCRIPT_DIR/../config/limits.yaml"

# Hard-coded limits (from CLAUDE.md constraints)
MAX_POSITIONS=5
MAX_POSITION_VALUE=1000
DAILY_LOSS_LIMIT=500
STOP_LOSS_PCT=0.03

# Validate input
if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then
    echo "Usage: ./tools/check-risk.sh SYMBOL SIDE QUANTITY"
    echo "Example: ./tools/check-risk.sh AAPL buy 10"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')
SIDE=$(echo "$2" | tr '[:upper:]' '[:lower:]')
QTY=$3

echo "=== RISK CHECK: $SYMBOL $SIDE $QTY ==="
echo ""

# Validate side
if [ "$SIDE" != "buy" ]; then
    echo "❌ REJECTED: Only 'buy' orders allowed (no short selling)"
    exit 1
fi

PASS_COUNT=0
TOTAL_CHECKS=5

# Check 1: Get current position count
echo "Checking position count..."
POSITIONS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions")

POSITION_COUNT=$(echo "$POSITIONS" | jq 'length')

if [ "$POSITION_COUNT" -ge "$MAX_POSITIONS" ]; then
    echo "❌ REJECTED: Max positions reached ($POSITION_COUNT/$MAX_POSITIONS)"
    exit 1
else
    echo "✅ Position count OK ($POSITION_COUNT/$MAX_POSITIONS)"
    PASS_COUNT=$((PASS_COUNT + 1))
fi

# Check 2: Already have this position?
EXISTING=$(echo "$POSITIONS" | jq -r ".[] | select(.symbol == \"$SYMBOL\") | .qty")
if [ -n "$EXISTING" ]; then
    echo "⚠️  WARNING: Already have position in $SYMBOL ($EXISTING shares)"
    echo "   Consider whether to add or skip."
fi

# Check 3: Get current price and calculate position value
echo "Checking position value..."
TRADE=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/stocks/${SYMBOL}/trades/latest?feed=iex")

PRICE=$(echo "$TRADE" | jq -r '.trade.p // 0')

if [ "$PRICE" = "0" ] || [ "$PRICE" = "null" ]; then
    echo "❌ REJECTED: Could not get price for $SYMBOL"
    exit 1
fi

POSITION_VALUE=$(echo "$PRICE * $QTY" | bc)

if (( $(echo "$POSITION_VALUE > $MAX_POSITION_VALUE" | bc -l) )); then
    MAX_SHARES=$(echo "$MAX_POSITION_VALUE / $PRICE" | bc)
    echo "❌ REJECTED: Position value \$$POSITION_VALUE exceeds max \$$MAX_POSITION_VALUE"
    echo "   Max shares at \$$PRICE: $MAX_SHARES"
    exit 1
else
    printf "✅ Position value OK (\$%.2f / \$%d)\n" $POSITION_VALUE $MAX_POSITION_VALUE
    PASS_COUNT=$((PASS_COUNT + 1))
fi

# Check 4: Sufficient buying power?
echo "Checking buying power..."
ACCOUNT=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/account")

CASH=$(echo "$ACCOUNT" | jq -r '.cash')
TRADING_BLOCKED=$(echo "$ACCOUNT" | jq -r '.trading_blocked')

if [ "$TRADING_BLOCKED" = "true" ]; then
    echo "❌ REJECTED: Trading is blocked on this account"
    exit 1
fi

if (( $(echo "$POSITION_VALUE > $CASH" | bc -l) )); then
    echo "❌ REJECTED: Insufficient cash (\$$CASH available)"
    MAX_SHARES=$(echo "$CASH / $PRICE" | bc)
    echo "   Max shares you can afford: $MAX_SHARES"
    exit 1
else
    printf "✅ Buying power OK (\$%.2f available)\n" $CASH
    PASS_COUNT=$((PASS_COUNT + 1))
fi

# Check 5: Price within allowed range ($5 - $500)
echo "Checking price range..."
if (( $(echo "$PRICE < 5" | bc -l) )); then
    echo "❌ REJECTED: Price \$$PRICE below minimum \$5 (penny stock)"
    exit 1
elif (( $(echo "$PRICE > 500" | bc -l) )); then
    echo "❌ REJECTED: Price \$$PRICE above maximum \$500"
    exit 1
else
    printf "✅ Price in range (\$%.2f)\n" $PRICE
    PASS_COUNT=$((PASS_COUNT + 1))
fi

# Check 6: Day trade count
echo "Checking day trade limit..."
DAYTRADE_COUNT=$(echo "$ACCOUNT" | jq -r '.daytrade_count')
if [ "$DAYTRADE_COUNT" -ge 3 ]; then
    echo "⚠️  WARNING: At day trade limit ($DAYTRADE_COUNT/3)"
    echo "   You can still trade, but cannot exit same-day without PDT violation"
else
    echo "✅ Day trades available ($DAYTRADE_COUNT/3 used)"
    PASS_COUNT=$((PASS_COUNT + 1))
fi

echo ""
echo "=== RISK CHECK SUMMARY ==="
echo ""
echo "Checks Passed: $PASS_COUNT/5"
echo ""

if [ "$PASS_COUNT" -ge 4 ]; then
    echo "✅ APPROVED: Trade meets risk criteria"
    echo ""
    printf "Order Details:\n"
    printf "  Symbol: %s\n" $SYMBOL
    printf "  Side: %s\n" $SIDE
    printf "  Quantity: %s\n" $QTY
    printf "  Est. Price: \$%.2f\n" $PRICE
    printf "  Est. Value: \$%.2f\n" $POSITION_VALUE
    echo ""
    echo "Proceed with: ./tools/trade.sh $SYMBOL $SIDE $QTY"
    exit 0
else
    echo "❌ NOT APPROVED: Trade does not meet risk criteria"
    exit 1
fi
