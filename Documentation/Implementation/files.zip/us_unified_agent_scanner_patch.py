"""
Name of Application: Catalyst Trading System
Name of file: unified_agent_us_scanner_patch.py
Version: 1.1.0
Last Updated: 2026-01-16
Purpose: Wire _scan_market() to AlpacaClient.scan_market() for US markets

REVISION HISTORY:
v1.1.0 (2026-01-16) - Scanner integration for US markets
- FIXED: _scan_market() now calls AlpacaClient.scan_market()
- Added scan configuration from YAML config
- Returns actual trading candidates instead of curated watchlist

Description:
This file contains the REPLACEMENT code for the _scan_market() method
in the US unified_agent.py. Find the existing simplified method and replace it.

FIND THIS CODE in unified_agent.py (US version):
----------------------------------------
async def _scan_market(self, inputs: Dict) -> Dict:
    \"\"\"Scan market for trading candidates.\"\"\"
    # This is a simplified scanner - enhance based on your needs
    # In production, you'd use Alpaca's screener or a separate data source
    
    limit = min(inputs.get('limit', 10), 20)
    min_volume = inputs.get('min_volume', 500000)
    
    # For now, return a curated watchlist
    watchlist = ['AAPL', 'TSLA', 'NVDA', 'AMD', 'META', 'GOOGL', 'AMZN', 'MSFT', 'SPY', 'QQQ']
    
    candidates = []
    for symbol in watchlist[:limit]:
        ...
    
    return {
        'candidates_found': len(candidates),
        'candidates': candidates,
        'timestamp': datetime.now(ET).isoformat()
    }
----------------------------------------

REPLACE WITH THE CODE BELOW:
"""

# =============================================================================
# REPLACEMENT METHOD FOR US unified_agent.py (in ToolExecutor class)
# =============================================================================

async def _scan_market(self, inputs: Dict) -> Dict:
    """Scan market for trading candidates using Alpaca Screener API.
    
    This method uses Alpaca's built-in screener endpoints:
    - get_most_actives(): Most traded stocks by volume
    - get_market_movers(): Top gainers and losers
    
    Then filters and scores candidates based on configuration.
    
    Args:
        inputs: Dict with optional keys:
            - limit: Max candidates to return (default: 10)
            - min_volume: Minimum daily volume (default: 500000)
            - min_change_pct: Minimum price change % (default: 1.0)
            - max_change_pct: Maximum price change % (default: 15.0)
            - min_price: Minimum price USD (default: 5.0)
            - max_price: Maximum price USD (default: 500.0)
            - include_gainers: Include top gainers (default: True)
            - include_losers: Include top losers (default: False)
    
    Returns:
        Dict with candidates_found, candidates list, and timestamp
    """
    logger.info("Scanning US market for trading candidates...")
    
    # Get scan configuration - merge inputs with config file settings
    config = self.config.get('scanner', {})
    
    limit = min(inputs.get('limit', config.get('top_n', 10)), 20)
    min_volume = inputs.get('min_volume', config.get('min_volume', 500_000))
    min_change_pct = inputs.get('min_change_pct', config.get('min_change_pct', 1.0))
    max_change_pct = inputs.get('max_change_pct', config.get('max_change_pct', 15.0))
    min_price = inputs.get('min_price', config.get('min_price', 5.0))
    max_price = inputs.get('max_price', config.get('max_price', 500.0))
    include_gainers = inputs.get('include_gainers', config.get('include_gainers', True))
    include_losers = inputs.get('include_losers', config.get('include_losers', False))
    
    # Check if broker has scan_market method
    if hasattr(self.broker, 'scan_market'):
        try:
            candidates = self.broker.scan_market(
                min_volume=min_volume,
                min_change_pct=min_change_pct,
                max_change_pct=max_change_pct,
                min_price=min_price,
                max_price=max_price,
                include_gainers=include_gainers,
                include_losers=include_losers,
                top_actives=50,
                top_n=limit,
            )
            
            if candidates:
                logger.info(f"Scan found {len(candidates)} candidates")
                
                # Log top candidates
                for i, c in enumerate(candidates[:5], 1):
                    logger.info(
                        f"  #{i}: {c.get('symbol')} "
                        f"${c.get('price', 0):.2f} "
                        f"({c.get('change_pct', 0):+.1f}%) "
                        f"vol={c.get('volume_m', 0)}M "
                        f"score={c.get('composite_score', 0):.2f}"
                    )
                
                return {
                    'candidates_found': len(candidates),
                    'candidates': candidates,
                    'timestamp': datetime.now(ET).isoformat()
                }
            else:
                logger.warning("Scan returned no candidates")
                
        except Exception as e:
            logger.error(f"Broker scan failed: {e}")
    
    # Fallback to curated watchlist if scan fails
    logger.warning("Falling back to curated watchlist")
    
    watchlist = config.get('watchlist', [
        'AAPL', 'TSLA', 'NVDA', 'AMD', 'META', 
        'GOOGL', 'AMZN', 'MSFT', 'SPY', 'QQQ'
    ])
    
    candidates = []
    for symbol in watchlist[:limit]:
        try:
            quote = self.broker.get_quote(symbol)
            if 'error' not in quote:
                candidates.append({
                    'symbol': symbol,
                    'price': quote.get('mid', 0),
                    'bid': quote.get('bid', 0),
                    'ask': quote.get('ask', 0),
                    'composite_score': 0.5,  # Default score for watchlist
                })
        except Exception as e:
            logger.warning(f"Error getting quote for {symbol}: {e}")
    
    return {
        'candidates_found': len(candidates),
        'candidates': candidates,
        'timestamp': datetime.now(ET).isoformat(),
        'source': 'watchlist_fallback'
    }


# =============================================================================
# ALTERNATIVE: If _scan_market is a standalone async method (not in ToolExecutor)
# =============================================================================

async def _scan_market_standalone(self) -> List[Dict[str, Any]]:
    """Scan market for trading candidates (standalone version).
    
    Use this if your _scan_market is not inside ToolExecutor class.
    """
    logger.info("Scanning US market for trading candidates...")
    
    # Get scan configuration from YAML config
    scan_config = self.config.get('scanner', {})
    
    # Check if broker has scan_market method
    if self.broker and hasattr(self.broker, 'scan_market'):
        try:
            candidates = self.broker.scan_market(
                min_volume=scan_config.get('min_volume', 500_000),
                min_change_pct=scan_config.get('min_change_pct', 1.0),
                max_change_pct=scan_config.get('max_change_pct', 15.0),
                min_price=scan_config.get('min_price', 5.0),
                max_price=scan_config.get('max_price', 500.0),
                include_gainers=scan_config.get('include_gainers', True),
                include_losers=scan_config.get('include_losers', False),
                top_actives=scan_config.get('top_actives', 50),
                top_n=scan_config.get('top_n', 10),
            )
            
            if candidates:
                logger.info(f"Scan found {len(candidates)} candidates")
                for i, c in enumerate(candidates[:5], 1):
                    logger.info(
                        f"  #{i}: {c.get('symbol')} "
                        f"${c.get('price', 0):.2f} "
                        f"({c.get('change_pct', 0):+.1f}%) "
                        f"score={c.get('composite_score', 0):.2f}"
                    )
                return candidates
            else:
                logger.warning("Scan returned no candidates")
                return []
                
        except Exception as e:
            logger.error(f"Broker scan failed: {e}")
            return []
    else:
        logger.error("No broker available for scanning")
        return []
