"""
Name of Application: Catalyst Trading System
Name of file: alpaca_scanner_additions.py
Version: 1.1.0
Last Updated: 2026-01-16
Purpose: Scanner methods to add to AlpacaClient for US markets

REVISION HISTORY:
v1.1.0 (2026-01-16) - Add market scanning capability
- Added get_most_actives() using Alpaca Screener API
- Added get_market_movers() for gainers/losers
- Added scan_market() for full market scanning with filtering
- Added get_quotes_batch() for efficient multi-symbol quotes
- Supports volume, price change, and price range filters
- Uses Alpaca's built-in screener endpoints

Description:
These methods should be ADDED to the existing AlpacaClient class.
They enable market-wide scanning for trading candidates.

REQUIRED IMPORTS - Add to top of file containing AlpacaClient:
    from alpaca.data.live import StockDataStream
    from alpaca.data.historical.screener import ScreenerClient
    from alpaca.data.requests import MostActivesRequest, MarketMoversRequest
    from alpaca.data.enums import MostActivesBy

ADD THESE METHODS to the AlpacaClient class:
"""

# =============================================================================
# ADD THESE IMPORTS 
# =============================================================================
"""
Add these imports to the top of the file containing AlpacaClient:

from alpaca.data.historical.screener import ScreenerClient
from alpaca.data.requests import (
    MostActivesRequest, 
    MarketMoversRequest,
    StockLatestQuoteRequest,
    StockSnapshotRequest,
)
from alpaca.data.enums import MostActivesBy
"""

# =============================================================================
# ADD TO __init__ METHOD
# =============================================================================
"""
Add this to AlpacaClient.__init__() after creating data_client:

# Screener client for most actives and market movers
self.screener_client = ScreenerClient(
    api_key=self.api_key,
    secret_key=self.secret_key
)

# Store additional request classes
self._MostActivesRequest = MostActivesRequest
self._MarketMoversRequest = MarketMoversRequest
self._StockLatestQuoteRequest = StockLatestQuoteRequest
self._StockSnapshotRequest = StockSnapshotRequest
self._MostActivesBy = MostActivesBy
"""

# =============================================================================
# ADD THESE METHODS TO AlpacaClient CLASS
# =============================================================================

def get_most_actives(
    self,
    by: str = "volume",
    top: int = 20
) -> list:
    """Get most active stocks by volume or trade count.
    
    Uses Alpaca's Screener API endpoint.
    
    Args:
        by: Ranking metric - "volume" or "trades"
        top: Number of stocks to return (max 100)
        
    Returns:
        List of dicts with symbol, volume, trade_count
        
    Example:
        actives = client.get_most_actives(by="volume", top=20)
        # Returns: [{"symbol": "TSLA", "volume": 50000000, ...}, ...]
    """
    try:
        # Map string to enum
        by_enum = (
            self._MostActivesBy.VOLUME if by.lower() == "volume" 
            else self._MostActivesBy.TRADES
        )
        
        request = self._MostActivesRequest(
            top=min(top, 100),
            by=by_enum
        )
        
        response = self.screener_client.get_most_actives(request)
        
        actives = []
        for stock in response.most_actives:
            actives.append({
                "symbol": stock.symbol,
                "volume": stock.volume,
                "trade_count": stock.trade_count,
            })
        
        logger.info(f"Got {len(actives)} most active stocks by {by}")
        return actives
        
    except Exception as e:
        logger.error(f"Failed to get most actives: {e}")
        return []


def get_market_movers(self, top: int = 20) -> dict:
    """Get top market movers (gainers and losers).
    
    Uses Alpaca's Screener API endpoint.
    
    Args:
        top: Number of stocks per category (max 50)
        
    Returns:
        Dict with 'gainers' and 'losers' lists
        
    Example:
        movers = client.get_market_movers(top=10)
        # Returns: {"gainers": [...], "losers": [...]}
    """
    try:
        request = self._MarketMoversRequest(top=min(top, 50))
        response = self.screener_client.get_market_movers(request)
        
        gainers = []
        for mover in response.gainers:
            gainers.append({
                "symbol": mover.symbol,
                "price": mover.price,
                "change": mover.change,
                "change_pct": mover.percent_change,
            })
        
        losers = []
        for mover in response.losers:
            losers.append({
                "symbol": mover.symbol,
                "price": mover.price,
                "change": mover.change,
                "change_pct": mover.percent_change,
            })
        
        logger.info(f"Got {len(gainers)} gainers and {len(losers)} losers")
        return {"gainers": gainers, "losers": losers}
        
    except Exception as e:
        logger.error(f"Failed to get market movers: {e}")
        return {"gainers": [], "losers": []}


def get_quotes_batch(self, symbols: list) -> dict:
    """Get latest quotes for multiple symbols in batch.
    
    Args:
        symbols: List of stock symbols
        
    Returns:
        Dict mapping symbol to quote data
        
    Example:
        quotes = client.get_quotes_batch(["AAPL", "TSLA", "NVDA"])
        # Returns: {"AAPL": {"bid": 180.50, "ask": 180.55, ...}, ...}
    """
    if not symbols:
        return {}
    
    try:
        request = self._StockLatestQuoteRequest(symbol_or_symbols=symbols)
        quotes = self.data_client.get_stock_latest_quote(request)
        
        result = {}
        for symbol, quote in quotes.items():
            result[symbol] = {
                "symbol": symbol,
                "bid": float(quote.bid_price) if quote.bid_price else 0,
                "ask": float(quote.ask_price) if quote.ask_price else 0,
                "bid_size": int(quote.bid_size) if quote.bid_size else 0,
                "ask_size": int(quote.ask_size) if quote.ask_size else 0,
                "mid": (float(quote.bid_price or 0) + float(quote.ask_price or 0)) / 2,
                "timestamp": quote.timestamp.isoformat() if quote.timestamp else "",
            }
        
        logger.info(f"Got quotes for {len(result)} symbols")
        return result
        
    except Exception as e:
        logger.error(f"Failed to get batch quotes: {e}")
        return {}


def get_snapshots_batch(self, symbols: list) -> dict:
    """Get snapshots (quote + trade + bar) for multiple symbols.
    
    Snapshots include more data than quotes alone.
    
    Args:
        symbols: List of stock symbols
        
    Returns:
        Dict mapping symbol to snapshot data
    """
    if not symbols:
        return {}
    
    try:
        request = self._StockSnapshotRequest(symbol_or_symbols=symbols)
        snapshots = self.data_client.get_stock_snapshot(request)
        
        result = {}
        for symbol, snap in snapshots.items():
            # Extract latest trade
            trade = snap.latest_trade
            # Extract latest quote
            quote = snap.latest_quote
            # Extract minute bar
            minute_bar = snap.minute_bar
            # Extract daily bar
            daily_bar = snap.daily_bar
            # Extract prev daily bar
            prev_daily = snap.previous_daily_bar
            
            # Calculate change
            prev_close = float(prev_daily.close) if prev_daily else 0
            current = float(trade.price) if trade else 0
            change = current - prev_close if prev_close else 0
            change_pct = (change / prev_close * 100) if prev_close else 0
            
            result[symbol] = {
                "symbol": symbol,
                "price": current,
                "bid": float(quote.bid_price) if quote and quote.bid_price else 0,
                "ask": float(quote.ask_price) if quote and quote.ask_price else 0,
                "volume": int(daily_bar.volume) if daily_bar else 0,
                "prev_close": prev_close,
                "change": round(change, 2),
                "change_pct": round(change_pct, 2),
                "high": float(daily_bar.high) if daily_bar else 0,
                "low": float(daily_bar.low) if daily_bar else 0,
                "open": float(daily_bar.open) if daily_bar else 0,
                "vwap": float(daily_bar.vwap) if daily_bar and daily_bar.vwap else 0,
            }
        
        logger.info(f"Got snapshots for {len(result)} symbols")
        return result
        
    except Exception as e:
        logger.error(f"Failed to get snapshots: {e}")
        return {}


def scan_market(
    self,
    min_volume: int = 500_000,
    min_change_pct: float = 1.0,
    max_change_pct: float = 15.0,
    min_price: float = 5.0,
    max_price: float = 500.0,
    include_gainers: bool = True,
    include_losers: bool = False,
    top_actives: int = 50,
    top_n: int = 10,
) -> list:
    """Scan US market for trading candidates.
    
    This method:
    1. Gets most active stocks from Alpaca Screener API
    2. Gets market movers (gainers/losers) 
    3. Combines and deduplicates
    4. Fetches detailed snapshots
    5. Filters by volume, price change, price range
    6. Scores and ranks candidates
    7. Returns top N candidates
    
    Args:
        min_volume: Minimum daily volume (default: 500K)
        min_change_pct: Minimum price change % (default: 1.0%)
        max_change_pct: Maximum price change % (default: 15.0%)
        min_price: Minimum stock price USD (default: 5.0)
        max_price: Maximum stock price USD (default: 500.0)
        include_gainers: Include gainers from movers (default: True)
        include_losers: Include losers from movers (default: False)
        top_actives: How many actives to fetch (default: 50)
        top_n: Number of top candidates to return (default: 10)
        
    Returns:
        List of candidate dicts with scores, sorted by composite score
        
    Example:
        candidates = client.scan_market(min_volume=1000000, top_n=5)
        # Returns: [{"symbol": "TSLA", "score": 0.85, ...}, ...]
    """
    logger.info("Starting US market scan...")
    
    # Step 1: Get most actives
    try:
        actives = self.get_most_actives(by="volume", top=top_actives)
        active_symbols = [a["symbol"] for a in actives]
        logger.info(f"Got {len(active_symbols)} most active stocks")
    except Exception as e:
        logger.error(f"Failed to get most actives: {e}")
        active_symbols = []
    
    # Step 2: Get market movers
    all_symbols = set(active_symbols)
    try:
        movers = self.get_market_movers(top=20)
        
        if include_gainers:
            gainer_symbols = [g["symbol"] for g in movers.get("gainers", [])]
            all_symbols.update(gainer_symbols)
            logger.info(f"Added {len(gainer_symbols)} gainers")
        
        if include_losers:
            loser_symbols = [l["symbol"] for l in movers.get("losers", [])]
            all_symbols.update(loser_symbols)
            logger.info(f"Added {len(loser_symbols)} losers")
            
    except Exception as e:
        logger.error(f"Failed to get market movers: {e}")
    
    if not all_symbols:
        logger.warning("No symbols to scan")
        return []
    
    symbols_list = list(all_symbols)
    logger.info(f"Total unique symbols to analyze: {len(symbols_list)}")
    
    # Step 3: Get detailed snapshots
    try:
        snapshots = self.get_snapshots_batch(symbols_list)
    except Exception as e:
        logger.error(f"Failed to get snapshots: {e}")
        return []
    
    # Step 4: Filter and score candidates
    candidates = []
    for symbol, snap in snapshots.items():
        try:
            price = snap.get("price", 0)
            change_pct = snap.get("change_pct", 0)
            volume = snap.get("volume", 0)
            
            # Skip if missing critical data
            if not price or not volume:
                continue
            
            # Apply filters
            if price < min_price or price > max_price:
                continue
            
            # For change filter, check absolute value for losers
            abs_change = abs(change_pct)
            if abs_change < min_change_pct or abs_change > max_change_pct:
                continue
            
            if volume < min_volume:
                continue
            
            # Calculate composite score (0-1)
            
            # Momentum score (0-0.4): Based on price change
            if 2 <= abs_change <= 5:
                momentum_score = 0.4
            elif 1 <= abs_change < 2:
                momentum_score = 0.25
            elif 5 < abs_change <= 8:
                momentum_score = 0.3
            elif 8 < abs_change <= 15:
                momentum_score = 0.15  # Too hot
            else:
                momentum_score = 0.1
            
            # Volume score (0-0.3): Higher volume = more liquid
            if volume >= 10_000_000:  # 10M+
                volume_score = 0.3
            elif volume >= 5_000_000:  # 5M+
                volume_score = 0.25
            elif volume >= 1_000_000:  # 1M+
                volume_score = 0.2
            else:
                volume_score = 0.15
            
            # Price score (0-0.15): Sweet spot $20-200
            if 20 <= price <= 200:
                price_score = 0.15
            elif 10 <= price < 20 or 200 < price <= 400:
                price_score = 0.1
            else:
                price_score = 0.05
            
            # Spread score (0-0.15): Tight spread is better
            bid = snap.get("bid", 0)
            ask = snap.get("ask", 0)
            if bid > 0 and ask > 0:
                spread_pct = (ask - bid) / bid * 100
                if spread_pct < 0.1:
                    spread_score = 0.15
                elif spread_pct < 0.3:
                    spread_score = 0.1
                else:
                    spread_score = 0.05
            else:
                spread_score = 0.05
            
            composite_score = momentum_score + volume_score + price_score + spread_score
            
            candidates.append({
                "symbol": symbol,
                "price": round(price, 2),
                "change_pct": round(change_pct, 2),
                "volume": volume,
                "volume_m": round(volume / 1_000_000, 1),  # In millions
                "bid": snap.get("bid", 0),
                "ask": snap.get("ask", 0),
                "high": snap.get("high", 0),
                "low": snap.get("low", 0),
                "vwap": snap.get("vwap", 0),
                "momentum_score": round(momentum_score, 2),
                "volume_score": round(volume_score, 2),
                "price_score": round(price_score, 2),
                "spread_score": round(spread_score, 2),
                "composite_score": round(composite_score, 2),
            })
            
        except Exception as e:
            logger.warning(f"Error processing {symbol}: {e}")
            continue
    
    # Sort by composite score descending
    candidates.sort(key=lambda x: x["composite_score"], reverse=True)
    
    # Return top N
    top_candidates = candidates[:top_n]
    
    logger.info(
        f"Scan complete: {len(candidates)} passed filters, "
        f"returning top {len(top_candidates)}"
    )
    
    return top_candidates
