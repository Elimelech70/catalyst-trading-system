#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: patterns.sh
# Version: 1.1.0
# Last Updated: 2026-02-01
# Purpose: Detect chart patterns for a symbol
#
# REVISION HISTORY:
# v1.1.0 (2026-02-01) - Fixed duplicate Python logic, consolidated detection
# v1.0.0 (2026-02-01) - Initial implementation
#
# Detects: breakout, near_breakout, bull_flag, bear_flag,
#          ascending_triangle, descending_triangle, momentum_continuation
#
# Usage: ./tools/patterns.sh AAPL
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

# Validate input
if [ -z "$1" ]; then
    echo "Usage: ./tools/patterns.sh SYMBOL"
    echo "Example: ./tools/patterns.sh AAPL"
    exit 1
fi

SYMBOL=$(echo "$1" | tr '[:lower:]' '[:upper:]')

echo "Detecting patterns for $SYMBOL..."
echo ""

# Get historical bars (30 days for pattern analysis)
END_DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ)
START_DATE=$(date -u -d "35 days ago" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -v-35d -u +%Y-%m-%dT%H:%M:%SZ)

BARS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/stocks/${SYMBOL}/bars?timeframe=1Day&start=${START_DATE}&limit=30&feed=iex")

# Check for errors
if echo "$BARS" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$BARS" | jq -r '.message')"
    exit 1
fi

# Check if we have enough data
BAR_COUNT=$(echo "$BARS" | jq '.bars | length')
if [ "$BAR_COUNT" -lt 20 ]; then
    echo "Insufficient data for pattern detection ($BAR_COUNT bars, need 20+)"
    exit 1
fi

# Run pattern detection via Python
python3 -c "
import json
import sys

# Load bar data
bars_json = '''$(echo "$BARS" | tr -d '\n')'''
symbol = '$SYMBOL'

data = json.loads(bars_json)
bars = data.get('bars', [])

if not bars:
    print('No bar data available')
    sys.exit(1)

# Extract and reverse to chronological order (oldest first)
closes = [b['c'] for b in bars][::-1]
highs = [b['h'] for b in bars][::-1]
lows = [b['l'] for b in bars][::-1]
volumes = [b['v'] for b in bars][::-1]

patterns_found = []

# ============================================================================
# PATTERN DETECTION FUNCTIONS
# ============================================================================

def detect_breakout():
    '''Detect breakout pattern - price breaking above resistance.'''
    if len(closes) < 20:
        return None

    # Find resistance (highest high in last 20 days excluding last 2)
    resistance = max(highs[:-2])
    current = closes[-1]
    prev = closes[-2]

    # Volume check
    avg_volume = sum(volumes[:-1]) / len(volumes[:-1])
    vol_ratio = volumes[-1] / avg_volume if avg_volume > 0 else 0

    # Breakout: current above resistance, prev was below/at resistance
    if current > resistance and prev <= resistance * 1.02 and vol_ratio > 1.3:
        confidence = min(0.85, 0.5 + (vol_ratio - 1.3) * 0.1)
        return {
            'pattern': 'breakout',
            'direction': 'long',
            'confidence': round(confidence, 2),
            'entry': round(current, 2),
            'resistance': round(resistance, 2),
            'stop_loss': round(resistance * 0.97, 2),
            'take_profit': round(current + (current - resistance) * 2, 2),
            'volume_ratio': round(vol_ratio, 1)
        }
    return None

def detect_near_breakout():
    '''Detect near-breakout - within 2% of resistance.'''
    if len(closes) < 20:
        return None

    resistance = max(highs[:-2])
    current = closes[-1]

    # Volume check
    avg_volume = sum(volumes[:-1]) / len(volumes[:-1])
    vol_ratio = volumes[-1] / avg_volume if avg_volume > 0 else 0

    # Near breakout: within 2% of resistance
    distance_pct = (resistance - current) / resistance
    if 0 < distance_pct <= 0.02 and vol_ratio > 1.0:
        confidence = min(0.6, 0.4 + vol_ratio * 0.05)
        return {
            'pattern': 'near_breakout',
            'direction': 'long',
            'confidence': round(confidence, 2),
            'current': round(current, 2),
            'resistance': round(resistance, 2),
            'distance_pct': round(distance_pct * 100, 2),
            'volume_ratio': round(vol_ratio, 1),
            'note': 'Watch for breakout confirmation'
        }
    return None

def detect_bull_flag():
    '''Detect bull flag - strong uptrend followed by consolidation.'''
    if len(closes) < 20:
        return None

    mid = len(closes) // 2

    # Pole: strong uptrend in first half (>5% gain)
    pole_return = (closes[mid] - closes[0]) / closes[0]
    if pole_return < 0.05:
        return None

    # Flag: tight consolidation in second half
    flag_high = max(highs[mid:])
    flag_low = min(lows[mid:])
    flag_range = (flag_high - flag_low) / flag_low

    if flag_range > 0.05:  # Flag should be tight (<5% range)
        return None

    # Flag should slope down or flat
    flag_slope = (closes[-1] - closes[mid]) / closes[mid]
    if flag_slope > 0.02:
        return None

    # Retracement check
    retracement = (closes[mid] - closes[-1]) / (closes[mid] - closes[0])
    if retracement > 0.5:  # Should not retrace more than 50%
        return None

    entry = closes[-1]
    stop = flag_low * 0.98
    target = entry + (entry - stop) * 2.5

    confidence = 0.7 + min(0.2, pole_return * 2)  # Higher pole = higher confidence

    return {
        'pattern': 'bull_flag',
        'direction': 'long',
        'confidence': round(confidence, 2),
        'entry': round(entry, 2),
        'stop_loss': round(stop, 2),
        'take_profit': round(target, 2),
        'pole_gain_pct': round(pole_return * 100, 1),
        'flag_range_pct': round(flag_range * 100, 1)
    }

def detect_bear_flag():
    '''Detect bear flag - strong downtrend followed by consolidation.'''
    if len(closes) < 20:
        return None

    mid = len(closes) // 2

    # Pole: strong downtrend in first half (>5% drop)
    pole_return = (closes[mid] - closes[0]) / closes[0]
    if pole_return > -0.05:
        return None

    # Flag: tight consolidation
    flag_high = max(highs[mid:])
    flag_low = min(lows[mid:])
    flag_range = (flag_high - flag_low) / flag_low

    if flag_range > 0.05:
        return None

    # Flag should slope up or flat
    flag_slope = (closes[-1] - closes[mid]) / closes[mid]
    if flag_slope < -0.02:
        return None

    return {
        'pattern': 'bear_flag',
        'direction': 'short',
        'confidence': 0.7,
        'entry': round(closes[-1], 2),
        'stop_loss': round(flag_high * 1.02, 2),
        'pole_drop_pct': round(abs(pole_return) * 100, 1),
        'note': 'BEARISH - for awareness only (no short selling allowed)'
    }

def detect_ascending_triangle():
    '''Detect ascending triangle - flat resistance, rising support.'''
    if len(closes) < 20:
        return None

    # Check for flat resistance (last 10 days)
    recent_highs = highs[-10:]
    resistance = max(recent_highs)
    resistance_std = (max(recent_highs) - min(recent_highs)) / resistance

    if resistance_std > 0.02:  # Resistance should be flat (within 2%)
        return None

    # Check for rising lows
    recent_lows = lows[-10:]
    lows_slope = (recent_lows[-1] - recent_lows[0]) / recent_lows[0]

    if lows_slope < 0.02:  # Lows should be rising
        return None

    entry = resistance * 1.01  # Entry on breakout
    stop = min(recent_lows) * 0.98
    target = entry + (entry - stop) * 2

    return {
        'pattern': 'ascending_triangle',
        'direction': 'long',
        'confidence': 0.75,
        'entry': round(entry, 2),
        'resistance': round(resistance, 2),
        'support': round(min(recent_lows), 2),
        'stop_loss': round(stop, 2),
        'take_profit': round(target, 2),
        'note': 'Enter on resistance breakout'
    }

def detect_descending_triangle():
    '''Detect descending triangle - falling resistance, flat support.'''
    if len(closes) < 20:
        return None

    # Check for flat support
    recent_lows = lows[-10:]
    support = min(recent_lows)
    support_std = (max(recent_lows) - min(recent_lows)) / support

    if support_std > 0.02:
        return None

    # Check for falling highs
    recent_highs = highs[-10:]
    highs_slope = (recent_highs[-1] - recent_highs[0]) / recent_highs[0]

    if highs_slope > -0.02:
        return None

    return {
        'pattern': 'descending_triangle',
        'direction': 'short',
        'confidence': 0.7,
        'support': round(support, 2),
        'resistance': round(max(recent_highs), 2),
        'note': 'BEARISH - potential breakdown below support'
    }

def detect_momentum_continuation():
    '''Detect strong momentum continuation.'''
    if len(closes) < 5:
        return None

    # Check for strong daily gain
    daily_gain = (closes[-1] - closes[-2]) / closes[-2]
    if daily_gain < 0.03:  # Need >3% daily gain
        return None

    # Volume spike
    avg_volume = sum(volumes[:-1]) / len(volumes[:-1])
    vol_ratio = volumes[-1] / avg_volume if avg_volume > 0 else 0

    if vol_ratio < 1.5:  # Need >1.5x volume
        return None

    # 3-day trend
    three_day_gain = (closes[-1] - closes[-4]) / closes[-4] if len(closes) >= 4 else 0
    if three_day_gain < 0.05:  # Need >5% 3-day gain
        return None

    confidence = min(0.5, 0.35 + (vol_ratio - 1.5) * 0.05)

    return {
        'pattern': 'momentum_continuation',
        'direction': 'long',
        'confidence': round(confidence, 2),
        'current': round(closes[-1], 2),
        'daily_gain_pct': round(daily_gain * 100, 1),
        'three_day_gain_pct': round(three_day_gain * 100, 1),
        'volume_ratio': round(vol_ratio, 1),
        'note': 'Strong momentum - consider trailing stop'
    }

def detect_support_bounce():
    '''Detect bounce off support level.'''
    if len(closes) < 20:
        return None

    # Find support (lowest low in last 20 days)
    support = min(lows[:-2])
    current = closes[-1]
    yesterday_low = lows[-2]

    # Check if touched support and bounced
    if yesterday_low <= support * 1.01 and current > yesterday_low * 1.01:
        return {
            'pattern': 'support_bounce',
            'direction': 'long',
            'confidence': 0.6,
            'support': round(support, 2),
            'current': round(current, 2),
            'entry': round(current, 2),
            'stop_loss': round(support * 0.98, 2),
            'take_profit': round(current + (current - support) * 2, 2)
        }
    return None


# ============================================================================
# RUN ALL DETECTORS
# ============================================================================

detectors = [
    detect_breakout,
    detect_near_breakout,
    detect_bull_flag,
    detect_bear_flag,
    detect_ascending_triangle,
    detect_descending_triangle,
    detect_momentum_continuation,
    detect_support_bounce
]

for detector in detectors:
    try:
        result = detector()
        if result:
            patterns_found.append(result)
    except Exception as e:
        pass  # Skip failed detectors


# ============================================================================
# OUTPUT
# ============================================================================

print('=== PATTERN DETECTION: {} ==='.format(symbol))
print()

if not patterns_found:
    print('No patterns detected.')
    print()
    print('Current price: \${:.2f}'.format(closes[-1]))
    print('20-day high: \${:.2f}'.format(max(highs)))
    print('20-day low: \${:.2f}'.format(min(lows)))
    print()
    print('Tip: Check ./tools/technicals.sh for RSI/MACD analysis')
else:
    print('Found {} pattern(s):'.format(len(patterns_found)))
    print()
    for i, p in enumerate(patterns_found, 1):
        print('--- Pattern {}: {} ---'.format(i, p['pattern'].upper()))
        print('Direction: {}'.format(p['direction'].upper()))
        print('Confidence: {:.0%}'.format(p['confidence']))

        if 'entry' in p:
            print('Entry: \${}'.format(p['entry']))
        if 'stop_loss' in p:
            print('Stop Loss: \${}'.format(p['stop_loss']))
        if 'take_profit' in p:
            print('Take Profit: \${}'.format(p['take_profit']))
        if 'resistance' in p:
            print('Resistance: \${}'.format(p['resistance']))
        if 'support' in p:
            print('Support: \${}'.format(p['support']))
        if 'current' in p:
            print('Current: \${}'.format(p['current']))
        if 'volume_ratio' in p:
            print('Volume Ratio: {}x'.format(p['volume_ratio']))
        if 'note' in p:
            print('Note: {}'.format(p['note']))
        print()

print('---')
print('Pattern Legend:')
print('  breakout         - Price broke above resistance')
print('  near_breakout    - Within 2% of resistance (watch)')
print('  bull_flag        - Uptrend + consolidation (bullish)')
print('  bear_flag        - Downtrend + consolidation (bearish)')
print('  asc_triangle     - Flat resistance + rising lows')
print('  desc_triangle    - Flat support + falling highs')
print('  momentum_cont    - Strong trend continuing')
print('  support_bounce   - Bounced off support level')
print()
print('Tip: Combine with ./tools/technicals.sh for RSI/MACD confirmation')
"
