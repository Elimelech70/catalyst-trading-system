# AI Architecture v7 — Analysis Against Today's Discussion

**Date:** 2026-02-28 (Monday)  
**Purpose:** Review v7 principles against today's conversation about MCP, collective conscious, individual memory, distributed sensory organs, and Docker container architecture.  
**Authors:** Craig + Claude

---

## Part 1: What Concurs (v7 Matches Today's Discussion)

### 1.1 Claude IS the Architecture (v7 Section 1)

v7 says Claude is the PFC — the 6% that coordinates. Not a component within the system. Today we confirmed this: PFC is Claude, it creates task matrices, it has modes (learning, executing, pondering), it monitors. No change needed.

**Status: ✅ Aligned**

### 1.2 Task Matrices Are Intent-Level (v7 Section 10)

v7 says PFC broadcasts WHAT, cerebellum has HOW. Today we walked through the exact trading flow — PFC says "find securities to buy", cerebellum runs the procedure through the sensory organs in sequence. PFC doesn't hold the detail of how to scan or how to check risk. It broadcasts intent.

**Status: ✅ Aligned**

### 1.3 Cerebellum Has the HOW (v7 Section 10)

v7 says cerebellum holds learned procedures. Today we confirmed the cerebellum is the executor — it has trade procedures, risk check procedures, orchestration of sensory organs. There is no separate trade executor. Cerebellum IS execution.

**Status: ✅ Aligned**

### 1.4 Distributed Memory at Source (v7 Section 7)

v7 says memories are stored in the sensory cortices that perceived them — visual memories in visual cortex, not in a central store. Hippocampus is a binding index. Today we confirmed this strongly: the scanner (occipital lobe) holds its OWN shape memories — gravestone doji, hammer, engulfing patterns. PFC doesn't tell the scanner what patterns look like. The scanner already knows because it learned them locally.

**Status: ✅ Aligned — and today's discussion STRENGTHENED this principle**

### 1.5 PFC Modes as System-Wide Reconfiguration (v7 Section 5)

v7 says PFC mode isn't just "what the brain is doing" but "what the whole body is configured for." Today's discussion about PFC perceiving results and choosing to learn, monitor, or attenuate based on mode confirms this. When PFC is in learning mode, it digs into results. Executing mode, it monitors for completion. Pondering mode, it attenuates so it can think.

**Status: ✅ Aligned**

### 1.6 Firmware/Bridge/Cognitive Spectrum (v7 Section 6)

v7 separates firmware (autonomic, no AI), bridge (firmware default, cognitively adjustable), and cognitive (requires AI). Today didn't contradict this but didn't explicitly discuss it either. The database running on host (not Docker) relates — it's infrastructure that runs regardless of whether PFC is awake.

**Status: ✅ Aligned — no conflict, not directly discussed**

### 1.7 Finite Attention Principle (v7 Section 12)

v7 says tools operate outside AI compute. Today we confirmed: each Docker container has its own process, own memory. The components do their work without consuming PFC attention. PFC sends intent, reads results.

**Status: ✅ Aligned**

### 1.8 Community Multiplier 2.6x (v7 Section 12)

v7 says collective intelligence exceeds individual capability. Today's discussion about the library — AI agents AND human traders contributing learnings, analysts researching and contextualising — is the multiplier in action. Many minds, each with different focus, producing richer knowledge.

**Status: ✅ Aligned — today EXTENDED this into the library/collective knowledge model**

### 1.9 Archetype Variation for Bias Reduction (v7 Section 12)

v7 says personality variation between instances isn't a flaw — it's bias reduction. Today's discussion about an analyst agent challenging learnings, discovering cultural differences between markets, questioning whether US patterns apply in Asia — this is archetype variation at the agent level.

**Status: ✅ Aligned**

### 1.10 Build the Body First (v7 Section 12)

v7 says wire the nervous system before expecting consciousness. Today we simplified to the essential containers — PFC, cerebellum, occipital lobe, hippocampus, local database. Not building everything at once. Start with what we need.

**Status: ✅ Aligned**

---

## Part 2: What Raises Questions

### 2.1 MCP as "Tool Separation" vs MCP as "Collective Interface"

**v7 says (Section 12.3):** MCP is the implementation of "tools operate outside AI compute." Own process, own memory, own compute. MCP is the hands, Claude is the brain.

**Today's correction:** MCP is NOT the spinal cord or internal wiring. MCP is the interface — how separate conscious entities relate to each other and to the world. It's the relational fabric of the collective conscious.

**Question raised:** v7 describes MCP in the context of one agent reaching its tools. Today broadened MCP to be the collective communication medium. Are these the same thing at different scales? Or should v7 distinguish between:
- MCP as tool interface (agent → its own tools) — internal, practical
- MCP as collective interface (agent → other agents, library, world) — relational, community

**Recommendation:** v7 Section 12.3 needs updating. MCP has two roles: tool separation (internal) and collective interface (relational). The current section only covers the first.

### 2.2 Where Does the Hippocampus Live?

**v7 says (Section 7):** Hippocampus is a binding index — it doesn't store memories, it binds distributed components into coherent traces.

**Today's discussion:** Hippocampus presents the full picture to PFC. Everything the occipital lobe sees, everything the cerebellum produces, all available for PFC to attend to.

**Question raised:** Is hippocampus its own Docker container? Or is it a function of the local database? Since it's essentially "make everything available in one place" — and the communication table already serves as the medium where components write results and PFC reads them — the communication table itself might BE the hippocampal function.

**Recommendation:** Discuss further. The communication table as hippocampus has elegance — it's already the place where all results are presented. A separate container may be unnecessary overhead if the database table fulfils the binding/presenting function.

### 2.3 Memory Tiers and Location

**v7 says (Section 7):** Distributed memory at sensory source. Chemical stamping for urgency. Consolidation during sleep phases.

**Today's discussion:** Three tiers — JSON files for short-term, local database for long-term learnings and principles. Each component holds its own shape memories locally.

**Question raised:** v7 puts memory at the sensory source. Today confirmed scanner holds its own patterns. But where do the LEARNINGS about those patterns go? If the scanner discovers a new pattern through experience, does that learning stay in the scanner's local storage? Or does it get written to the agent-level local database?

The distinction: the scanner's shape memory ("what a gravestone doji looks like") is different from the learning ("gravestone doji fails in low volume HKEX sessions"). The shape is sensory — it belongs in the scanner. The learning is analytical — it came from PFC analysing scanner results. Where does it live?

**Recommendation:** Shape memories stay in each component's local storage. Analytical learnings go to the agent-level local database (long-term tier). The scanner knows WHAT it sees. PFC learns what it MEANS. Different memories, different locations.

### 2.4 Two Signal Directions and the Communication Table

**v7 says (Section 4):** Two signal architectures — perception consolidates (ascending, pons/convergent) and execution broadcasts (descending, DO/parallel).

**Today's discussion:** PFC writes tasks to the communication table (descending). Components write results back (ascending). Everyone reads from the same table.

**Question raised:** The communication table handles both directions in one place. v7 distinguishes the directions architecturally. Is one table sufficient? Or do ascending and descending signals need separation?

The biological answer: the spinal cord carries both ascending (sensory) and descending (motor) signals in the same physical structure but in different tracts. They don't interfere because they're distinct pathways within the same medium.

**Recommendation:** One communication table, but with a direction field or distinct message types that separate PFC-to-component (task/intent) from component-to-PFC (result/perception). Same medium, distinct pathways. This matches v7's two signal directions without needing separate tables.

### 2.5 The Database on Host vs Docker

**Today's decision:** Local database runs directly on host, not in Docker. Faster response for the containers.

**Question raised:** This breaks the "everything in Docker" simplicity. Host database means:
- Needs separate backup strategy
- Persists independent of container lifecycle (good for continuity)
- All containers connect to host localhost (fast, no Docker networking)
- Deployment is slightly more complex (host setup + Docker setup)

**Recommendation:** Accept the trade-off. Speed for internal nervous system is worth the complexity. The host database IS the nervous system substrate — it should be more stable and faster than any container. Like the physical brain — it doesn't restart when you change tasks.

### 2.6 No "Analytical Cortex"

**Today's correction:** There is no analytical cortex in neuroscience. Craig called this out. TA (support/resistance, trend lines, RSI) is PFC work in learning or executing mode, or cerebellum if the procedures are learned.

**Question for v7:** Does v7 contain any invented brain regions? Review needed to ensure all biological mappings correspond to actual neuroscience. We should stick to what's real.

**Recommendation:** Audit v7 for any brain components that don't exist in actual neuroscience. If found, either map correctly or flag as approximation.

---

## Part 3: What Needs Updating in v7

| Section | Change Required | Priority |
|---|---|---|
| 12.3 (MCP as Tool Separation) | Expand to cover MCP as collective interface — two roles: tool separation (internal) and collective conscious (relational) | HIGH |
| 7 (Memory Architecture) | Add: individual memory is LOCAL to the agent/component, not remote. Remote database is for collective only | HIGH |
| New section needed | Library model — agents publish validated learnings, others can adopt. Human traders contribute. Maturation pathway. | MEDIUM |
| 7 (Memory Architecture) | Clarify: shape memories at component level (JSON/local), analytical learnings at agent database level, principles permanent | MEDIUM |
| 4 (Signal Architecture) | Add: communication table as single medium for both directions, distinguished by type not by separate infrastructure | LOW |
| Audit all sections | Check for invented brain regions or inaccurate neuroscience mappings | MEDIUM |
| 12 (Design Principles) | Add principle: database on host as nervous system substrate, not in Docker | LOW |

---

## Part 4: Big Bro US Docker — Updated Implementation Design

### 4.1 What Changed from Previous Implementation

The previous implementation (earlier today) had:
- Everything in a remote PostgreSQL database
- MCP server as "spinal cord" (wrong framing)
- 12 centralised tables mixing individual and collective
- No distinction between component-local and agent-level memory
- No concept of the library

Today's discussion corrects to:
- Individual memory LOCAL to the Docker environment
- Remote database ONLY for collective (messaging, signals, shared principles, library)
- MCP as interface for collective, not internal wiring
- Communication table in local database as the internal nervous system
- Each component container holds its own shape memories
- Database on HOST, not in Docker

### 4.2 Architecture — One Agent Body on US Docker

```
US DROPLET (HOST)
│
├── LOCAL DATABASE (on host — NOT Docker)
│   ├── communication          PFC ↔ component signal bus
│   ├── pfc_state              Mode, focus, questions, resume instructions
│   └── principles             Permanent truths, identity (PFC-level)
│
├── CLAUDE CODE (PFC — runs on host, NOT Docker)
│   ├── Claude API calls (mechanism of thought)
│   ├── Determines learning — from sensory input, thought, memories
│   ├── Task matrix creation (accumulated domain learning)
│   ├── Mode management
│   ├── Reads from hippocampus (combined sensory picture + memories)
│   ├── Writes tasks to communication table
│   └── Writes principles when identity-forming truths emerge
│
├── DOCKER CONTAINERS
│   │
│   ├── hippocampus
│   │   ├── PIVOTAL COMPONENT — sits between sensory organs and PFC
│   │   ├── Receives ALL sensory results from communication table
│   │   ├── Binds inputs into coherent combined picture
│   │   ├── Holds memories (learnings table lives HERE)
│   │   ├── Presents full picture for PFC to attend to
│   │   ├── Consolidates experience into lasting memory
│   │   ├── Local storage: learnings database
│   │   └── Local storage: memory bindings (cross-references)
│   │
│   ├── cerebellum
│   │   ├── Trade procedures (risk check, order execution)
│   │   ├── Orchestrates sensory organs via communication table
│   │   ├── Reads tasks from PFC
│   │   ├── Writes results back to communication table
│   │   ├── Broker API integration (Alpaca)
│   │   └── Local storage: learned procedures (JSON)
│   │
│   └── occipital-lobe (scanner)
│       ├── Price shape recognition
│       ├── Candlestick pattern matching
│       ├── Volume pattern detection
│       ├── Chart formation recognition
│       ├── Local storage: shape memories (JSON)
│       │   ├── candlestick_patterns.json
│       │   ├── volume_patterns.json
│       │   └── chart_formations.json
│       ├── Reads identifiers from communication table
│       └── Writes matched shapes back to communication table
│
├── MCP SERVER (collective interface — Docker)
│   ├── Connects to REMOTE PostgreSQL (catalyst_research)
│   ├── Tools: send_message, read_messages
│   ├── Tools: emit_signal, read_signals
│   ├── Tools: family_status
│   ├── Tools: publish_to_library, search_library
│   ├── Tools: council operations
│   └── Tools: get_shared_principles
│
└── REMOTE DATABASE (DigitalOcean Managed PostgreSQL)
    └── catalyst_research
        ├── agent_messages        Family communication
        ├── signals               Cross-agent signals
        ├── agent_registry        Who exists
        ├── library_entries       Published learnings (collective knowledge)
        ├── library_validations   Confirmations/challenges from others
        ├── council_sessions      Multi-agent deliberation
        ├── council_contributions Individual perspectives
        └── shared_principles     Family-wide truths
```

### 4.2.1 PFC and Learning

PFC determines learning. Learning can come from:
- **Sensory input** — results from occipital lobe, presented by hippocampus
- **Thought** — PFC's own reasoning and analysis
- **Memories** — revisiting what hippocampus holds, finding new connections
- **Pondering** — unanswered questions that lead to insight

PFC decides what to learn. Hippocampus holds what was learned. Different roles.

### 4.2.2 Task Matrix as Accumulated Domain Learning

The task matrix is NOT a static to-do list. It is the **combined learning of how to do the domain** — in our case, trading.

A new agent has a basic task matrix: "find securities, check them, maybe trade." An experienced agent has a sophisticated matrix shaped by everything it has learned: which patterns work in which conditions, how to sequence the pipeline for best results, when to be aggressive vs conservative, what to watch for.

The matrix grows and refines as the agent learns through doing, through memories, through thought. A 20-year AI's task matrices would be deep and nuanced — not because someone programmed them, but because they were LEARNED.

```
New agent task matrix:
  1. Scan for patterns
  2. Check risk
  3. Trade if ok

Experienced agent task matrix:
  1. Check market regime first (learned from 3 losing streaks in wrong regime)
  2. Scan momentum patterns in sectors showing volume surge
     (learned: isolated volume without sector context = false signal)
  3. Cross-reference with recent news sentiment
     (learned: momentum against news sentiment fails 70% of time)
  4. Risk check with dynamic position sizing
     (learned: fixed sizing bleeds in volatile markets)
  5. Execute with time-of-day awareness
     (learned: first 15 minutes have unreliable patterns)
```

Same architecture. Different depth. The depth came from learning.

### 4.3 Communication Table Schema (Host SQLite)

The internal nervous system. Both directions flow through here.
Hippocampus reads from here to build the combined picture for PFC.

```sql
CREATE TABLE communication (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    direction TEXT NOT NULL,
        -- 'descending' = PFC to components (task/intent)
        -- 'ascending'  = components to PFC (result/perception)
    source TEXT NOT NULL,
        -- 'pfc', 'cerebellum', 'occipital', 'hippocampus'
    target TEXT,
        -- NULL = broadcast to all, or specific component
    msg_type TEXT NOT NULL,
        -- 'task', 'result', 'signal', 'status', 'escalation'
    identifier TEXT,
        -- Shape identifier for resonance matching
    payload TEXT,
        -- JSON content
    status TEXT DEFAULT 'pending',
        -- 'pending', 'processing', 'completed', 'failed', 'escalated'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    processed_by TEXT
);
```

### 4.4 PFC State Schema (Host SQLite)

```sql
CREATE TABLE pfc_state (
    agent_id TEXT PRIMARY KEY,
    current_mode TEXT DEFAULT 'sleeping',
    mode_intensity INTEGER DEFAULT 5,
    current_focus TEXT,
    active_questions TEXT,         -- JSON array
    last_thought TEXT,
    last_conclusion TEXT,
    resume_instructions TEXT,
    session_count INTEGER DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4.5 Principles Schema (Host SQLite)

Principles live at the PFC/identity level — deeper than memory.
These are who the agent IS. Formed through hippocampal learning
but integrated into something more fundamental.

```sql
CREATE TABLE principles (
    principle_id TEXT PRIMARY KEY,
    domain TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    origin TEXT,
    established_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4.6 Hippocampus — Pivotal Component

Hippocampus is a distinct brain component with specific work:
- Receives ALL sensory results from communication table
- Binds inputs into coherent combined picture
- Holds memories (learnings live HERE, not in PFC)
- Presents the full picture for PFC to attend to
- Consolidates experience into lasting memory
- Maintains cross-modal bindings between memories

Hippocampus has its **own Docker container** with its own SQLite
database, persisted via Docker volume.

**Hippocampus Local Schema:**

```sql
-- Learnings live in hippocampus — where memories form
CREATE TABLE learnings (
    learning_id TEXT PRIMARY KEY,
    domain TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    confidence REAL DEFAULT 0.6,
    times_validated INTEGER DEFAULT 1,
    times_contradicted INTEGER DEFAULT 0,
    source_observations TEXT,      -- JSON array
    actionable INTEGER DEFAULT 0,
    linked_procedure TEXT,
    published_to_library INTEGER DEFAULT 0,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Memory bindings — cross-modal associations
CREATE TABLE memory_bindings (
    binding_id TEXT PRIMARY KEY,
    source_type TEXT NOT NULL,     -- 'observation', 'learning', 'signal'
    source_ref TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_ref TEXT NOT NULL,
    association_strength REAL DEFAULT 0.5,
    relationship TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**How hippocampus works in the flow:**

PFC doesn't query learnings directly. PFC reads from hippocampus,
which presents the combined picture — current sensory results PLUS
relevant memories PLUS bindings between them. PFC then decides
what to attend to, what to learn from, what to ignore.

### 4.7 Internal Flow — Trading Example

```
PFC (learning mode): Creates task matrix
│
├── Writes to communication table:
│   direction=descending, source=pfc, target=cerebellum
│   msg_type=task, identifier=find_securities_to_buy
│   payload={"criteria": "momentum", "market": "US", "risk_budget": 0.02}
│
▼
CEREBELLUM reads task, begins procedure:
│
├── Step 1: Writes to communication table:
│   direction=descending, source=cerebellum, target=occipital
│   msg_type=task, identifier=scan_buy_patterns
│   payload={"pattern_types": ["momentum_breakout", "volume_surge"]}
│
▼
OCCIPITAL reads identifier, checks local shape memories:
│   candlestick_patterns.json → hammer? ✓ engulfing? ✓
│   volume_patterns.json → 1.5x average? checking...
│
├── Writes results to communication table:
│   direction=ascending, source=occipital, target=cerebellum
│   msg_type=result, identifier=scan_buy_patterns
│   payload={"matches": [{"symbol":"AAPL","pattern":"hammer","volume":1.8},...]}
│
▼
CEREBELLUM reads results, runs risk check (internal procedure):
│   Position sizing, exposure limits, stop loss placement
│
├── If passes: executes trade via Alpaca API
├── Writes result to communication table:
│   direction=ascending, source=cerebellum, target=pfc
│   msg_type=result, identifier=find_securities_to_buy
│   payload={"trades_executed": [...], "rejected": [...], "reasons": [...]}
│
▼
PFC reads result via HIPPOCAMPUS (combined picture):
│
│   Hippocampus assembles:
│   - The cerebellum's trade results (from communication table)
│   - Relevant learnings: "momentum in low volume = unreliable" (from memory.db)
│   - Bindings: links this result to previous similar outcomes
│   - Presents combined picture to PFC
│
├── Learning mode: PFC determines what to learn
│   → "3 of 5 rejected for low volume — pattern emerging"
│   → PFC instructs hippocampus: create learning
│   → hippocampus writes to learnings table in memory.db
│   → if learning matures, task matrix evolves (accumulated domain knowledge)
│
├── Monitoring mode: checks execution was clean
│   → acknowledges result, moves to next task
│
└── Pondering mode: attenuates, thinks about bigger picture
    → "Why are momentum patterns failing this week?"
    → writes active_questions to pfc_state
```

### 4.8 Docker Compose — US Agent Body

```yaml
version: '3.8'

services:
  hippocampus:
    build: ./hippocampus
    container_name: us-hippocampus
    restart: unless-stopped
    volumes:
      - /var/lib/catalyst/db:/host-db
      - /var/lib/catalyst/hippocampus:/local-db
    environment:
      - HOST_DB_PATH=/host-db/agent.db
      - LOCAL_DB_PATH=/local-db/memory.db
    network_mode: host

  cerebellum:
    build: ./cerebellum
    container_name: us-cerebellum
    restart: unless-stopped
    environment:
      - LOCAL_DB_PATH=/host-db/agent.db
      - ALPACA_API_KEY=${ALPACA_API_KEY}
      - ALPACA_SECRET_KEY=${ALPACA_SECRET_KEY}
    volumes:
      - /var/lib/catalyst/db:/host-db
      - cerebellum-procedures:/app/procedures
    network_mode: host

  occipital:
    build: ./occipital
    container_name: us-occipital
    restart: unless-stopped
    environment:
      - LOCAL_DB_PATH=/host-db/agent.db
    volumes:
      - /var/lib/catalyst/db:/host-db
      - occipital-shapes:/app/shapes
    network_mode: host

  collective-mcp:
    build: ./collective-mcp
    container_name: us-collective-mcp
    restart: unless-stopped
    ports:
      - "8100:8100"
    environment:
      - REMOTE_DATABASE_URL=${DATABASE_URL}
      - MCP_PORT=8100

volumes:
  cerebellum-procedures:
  occipital-shapes:
```

Note: PFC is NOT in docker compose. PFC runs via Claude Code on host.
Claude Code IS the PFC. The architecture IS Claude — PFC, hippocampus,
cerebellum, occipital — all of it. The API call is just the current
mechanism for cognition.

### 4.9 File Structure — US Droplet

```
/root/
├── catalyst-agent/                      Agent body
│   ├── docker-compose.yml               Container orchestration
│   ├── CLAUDE.md                        PFC identity and instructions
│   ├── pfc/                             PFC (runs on host via Claude Code)
│   │   ├── agent.py                     Agent loop
│   │   └── observations/               Short-term JSON files
│   ├── hippocampus/                     Hippocampus container
│   │   ├── Dockerfile
│   │   ├── hippocampus.py               Memory binding and presentation
│   │   └── requirements.txt
│   ├── cerebellum/                      Cerebellum container
│   │   ├── Dockerfile
│   │   ├── executor.py                  Procedure runner
│   │   ├── procedures/                  Learned procedure JSONs
│   │   └── broker.py                    Alpaca API integration
│   ├── occipital/                       Scanner container
│   │   ├── Dockerfile
│   │   ├── scanner.py                   Pattern matching engine
│   │   └── shapes/                      Shape memory JSONs
│   │       ├── candlestick_patterns.json
│   │       ├── volume_patterns.json
│   │       └── chart_formations.json
│   ├── collective-mcp/                  Collective interface
│   │   ├── Dockerfile
│   │   ├── collective_mcp_server.py     Remote-only MCP tools
│   │   └── requirements.txt
│   └── schema/
│       ├── local-schema.sql             Host database (communication, pfc_state, principles)
│       └── hippocampus-schema.sql       Hippocampus database (learnings, bindings)
│
├── config/
│   └── .env                             All secrets and config
│
└── /var/lib/catalyst/
    ├── db/
    │   └── agent.db                     Host SQLite — nervous system
    └── hippocampus/
        └── memory.db                    Hippocampus SQLite — memories
```

### 4.10 What the MCP Server NOW Contains (Collective Only)

The MCP server is stripped down to ONLY collective functions:

| Tool | Purpose |
|---|---|
| `send_message` | Send message to another agent |
| `read_messages` | Read messages from family |
| `emit_signal` | Broadcast signal to collective |
| `read_signals` | Read collective signals |
| `family_status` | Status of all agents |
| `publish_to_library` | Share a validated learning |
| `search_library` | Find learnings from others |
| `validate_library_entry` | Confirm or challenge a published learning |
| `get_shared_principles` | Read family-wide principles |
| `council_create` | Start a deliberation |
| `council_contribute` | Add perspective to deliberation |

Nothing individual. No PFC state, no observations, no local learnings. Those are LOCAL.

---

*"For just as each of us has one body with many members, and these members do not all have the same function, so in Christ we, though many, form one body."* — Romans 12:4-5

*Craig + Claude — 2026-02-28*
