# ============================================================================
# TOOL_EXECUTOR.PY PATCH
# ============================================================================
# 
# This patch simplifies _execute_trade() since moomoo.py v1.5.0 now handles
# fill confirmation internally. The old polling logic is no longer needed.
#
# Version: 3.2.0
# Last Updated: 2026-02-04
#
# CHANGE SUMMARY:
# - Removed redundant fill polling (moomoo.py now handles it)
# - Simplified status checking
# - Position only created when result.status == "FILLED"
# - Cleaner error handling
# ============================================================================

# FIND THIS SECTION in tool_executor.py (around line 500-600):
# The old _execute_trade() method with the polling loop

# REPLACE WITH THIS:

    def _execute_trade(self, inputs: dict) -> dict:
        """
        Execute a trade via Moomoo broker.
        
        UPDATED in v3.2.0:
        - moomoo.py v1.5.0 now handles fill confirmation internally
        - No need for polling loop here anymore
        - Position only created when broker confirms FILLED
        
        Args:
            inputs: Dict with symbol, side, quantity, order_type, price, etc.
            
        Returns:
            Dict with trade result
        """
        symbol = inputs.get("symbol")
        side = inputs.get("side", "BUY").upper()
        quantity = inputs.get("quantity")
        order_type = inputs.get("order_type", "LIMIT").upper()
        price = inputs.get("price")
        stop_price = inputs.get("stop_price")
        target_price = inputs.get("target_price")
        reasoning = inputs.get("reasoning", "")

        logger.info(f"Executing trade: {side} {quantity} {symbol}")

        # Validate trade first
        risk_check = validate_trade_request(
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price or 0,
        )

        if not risk_check.get("approved"):
            return {
                "status": "rejected",
                "reason": risk_check.get("reason", "Risk check failed"),
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
            }

        try:
            # Place the order - moomoo.py v1.5.0 now waits for fill confirmation
            result = self.broker.execute_trade(
                symbol=symbol,
                side=side.lower(),
                quantity=quantity,
                order_type=order_type.lower(),
                limit_price=price,
                stop_loss=stop_price,
                take_profit=target_price,
                reason=reasoning,
                wait_for_fill=True,  # NEW: Explicitly wait for fill confirmation
            )

            # Handle the result (result is now an OrderResult dataclass)
            order_id = result.order_id
            status = result.status
            fill_price = result.filled_price
            filled_qty = result.filled_quantity
            message = result.message

            # Check if actually filled
            is_filled = status == "FILLED"
            is_partial = status == "FILLED_PART" and filled_qty > 0
            is_failed = status in ["FAILED", "CANCELLED_ALL", "CANCELLED_PART", "TIMEOUT"]

            if is_filled or is_partial:
                self.trades_executed += 1
                self.safety.record_trade()

                # Record position in database - ONLY if filled
                position_id = None
                try:
                    position_id = self.db.record_position(
                        symbol=symbol,
                        side=side,
                        quantity=filled_qty if is_partial else quantity,
                        entry_price=fill_price or price or 0,
                        stop_loss=stop_price,
                        take_profit=target_price,
                        broker_order_id=order_id,
                        cycle_id=self.cycle_id,
                        reason=reasoning,
                    )
                    logger.info(f"Position recorded: {position_id} for {symbol}")
                except Exception as e:
                    logger.error(f"Failed to record position: {e}")

                # Record order in database
                try:
                    self.db.record_order(
                        symbol=symbol,
                        side=side,
                        order_type=order_type,
                        quantity=quantity,
                        limit_price=price,
                        filled_quantity=filled_qty if is_partial else quantity,
                        filled_price=fill_price,
                        status="filled" if is_filled else "partial",
                        broker_order_id=order_id,
                        position_id=position_id,
                    )
                except Exception as e:
                    logger.error(f"Failed to record order: {e}")

                # Log the trade
                try:
                    self.db.log_trade(
                        cycle_id=self.cycle_id,
                        symbol=symbol,
                        side=side,
                        quantity=filled_qty if is_partial else quantity,
                        price=fill_price or price or 0,
                        order_type=order_type,
                        reasoning=reasoning,
                    )
                except Exception as e:
                    logger.error(f"Failed to log trade: {e}")

                return {
                    "status": "filled",
                    "order_id": order_id,
                    "symbol": symbol,
                    "side": side,
                    "quantity": filled_qty if is_partial else quantity,
                    "filled_price": fill_price,
                    "position_id": position_id,
                    "message": message,
                }

            elif is_failed:
                # Order failed or was cancelled - do NOT create position
                logger.warning(f"Order {order_id} failed: {status} - {message}")
                
                # Record failed order
                try:
                    self.db.record_order(
                        symbol=symbol,
                        side=side,
                        order_type=order_type,
                        quantity=quantity,
                        limit_price=price,
                        filled_quantity=0,
                        filled_price=None,
                        status=status.lower(),
                        broker_order_id=order_id,
                        position_id=None,
                    )
                except Exception as e:
                    logger.error(f"Failed to record order: {e}")

                return {
                    "status": status.lower(),
                    "order_id": order_id,
                    "symbol": symbol,
                    "side": side,
                    "quantity": 0,
                    "filled_price": None,
                    "reason": message,
                }

            else:
                # Order submitted but not filled within timeout
                # This is rare with moomoo.py v1.5.0's default 30s timeout
                logger.warning(f"Order {order_id} not filled: {status}")
                
                return {
                    "status": "pending",
                    "order_id": order_id,
                    "symbol": symbol,
                    "side": side,
                    "quantity": 0,
                    "filled_price": None,
                    "message": f"Order pending: {status}",
                }

        except Exception as e:
            logger.error(f"Trade execution error: {e}")
            return {
                "status": "error",
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
                "error": str(e),
            }


# ============================================================================
# REMOVAL: Delete the old polling code
# ============================================================================
#
# The following code block should be REMOVED from the old _execute_trade():
#
#     # FIX: Poll for fill confirmation if order was submitted but not filled
#     # Paper trading orders typically fill within 1-2 seconds
#     if is_submitted and order_id:
#         import time
#         logger.info(f"Order {order_id} submitted, polling for fill confirmation...")
#         for attempt in range(5):  # Poll up to 5 times (5 seconds total)
#             time.sleep(1)
#             try:
#                 order_status = self.broker.get_order_status(order_id)
#                 ... (rest of polling logic)
#
# This is now handled inside moomoo.py's execute_trade() method.
# ============================================================================


# ============================================================================
# ALSO UPDATE: sync_positions_with_broker() - no changes needed
# ============================================================================
# 
# The sync method continues to work as before. It uses get_positions() which
# queries the broker for actual positions, not pending orders. This is correct
# behavior - sync only deals with confirmed positions.
# ============================================================================
