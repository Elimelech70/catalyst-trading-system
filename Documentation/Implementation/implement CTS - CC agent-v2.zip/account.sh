#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: account.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Get account balance, equity, and buying power
#
# Usage: ./tools/account.sh
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

echo "Getting account information..."
echo ""

# Get account
ACCOUNT=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/account")

# Check for errors
if echo "$ACCOUNT" | jq -e '.message' > /dev/null 2>&1; then
    echo "Error: $(echo "$ACCOUNT" | jq -r '.message')"
    exit 1
fi

# Parse account data
CASH=$(echo "$ACCOUNT" | jq -r '.cash')
EQUITY=$(echo "$ACCOUNT" | jq -r '.equity')
BUYING_POWER=$(echo "$ACCOUNT" | jq -r '.buying_power')
PORTFOLIO_VALUE=$(echo "$ACCOUNT" | jq -r '.portfolio_value')
LAST_EQUITY=$(echo "$ACCOUNT" | jq -r '.last_equity')
STATUS=$(echo "$ACCOUNT" | jq -r '.status')
TRADING_BLOCKED=$(echo "$ACCOUNT" | jq -r '.trading_blocked')
PATTERN_DAY_TRADER=$(echo "$ACCOUNT" | jq -r '.pattern_day_trader')
DAYTRADE_COUNT=$(echo "$ACCOUNT" | jq -r '.daytrade_count')

# Calculate daily change
DAILY_CHANGE=$(echo "$EQUITY - $LAST_EQUITY" | bc)
DAILY_CHANGE_PCT=$(echo "scale=2; ($EQUITY - $LAST_EQUITY) / $LAST_EQUITY * 100" | bc 2>/dev/null || echo "0")

echo "=== ACCOUNT STATUS ==="
echo ""
echo "Status: $STATUS"
echo "Trading Blocked: $TRADING_BLOCKED"
echo "Pattern Day Trader: $PATTERN_DAY_TRADER"
echo "Day Trades Used: $DAYTRADE_COUNT / 3"
echo ""
echo "=== BALANCES ==="
echo ""
printf "Cash Available:  \$%'.2f\n" $CASH
printf "Portfolio Value: \$%'.2f\n" $PORTFOLIO_VALUE
printf "Total Equity:    \$%'.2f\n" $EQUITY
printf "Buying Power:    \$%'.2f\n" $BUYING_POWER
echo ""
echo "=== DAILY PERFORMANCE ==="
echo ""
printf "Yesterday Close: \$%'.2f\n" $LAST_EQUITY
printf "Current Equity:  \$%'.2f\n" $EQUITY
printf "Daily Change:    \$%'.2f (%s%%)\n" $DAILY_CHANGE $DAILY_CHANGE_PCT

echo ""
echo "---"

# Warnings
if [ "$TRADING_BLOCKED" = "true" ]; then
    echo "⚠️  WARNING: Trading is blocked on this account!"
fi

if [ "$DAYTRADE_COUNT" -ge 3 ]; then
    echo "⚠️  WARNING: At day trade limit! PDT rule applies."
fi

# Calculate max position (20% of cash, capped at $1000)
MAX_POS=$(echo "scale=2; if ($CASH * 0.20 > 1000) 1000 else $CASH * 0.20" | bc)
printf "\nMax Position Size (20%% of cash, capped): \$%.2f\n" $MAX_POS
