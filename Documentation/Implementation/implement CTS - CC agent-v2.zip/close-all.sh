#!/bin/bash
# ============================================================================
# Name of Application: Catalyst Trading System
# Name of file: close-all.sh
# Version: 1.0.0
# Last Updated: 2026-02-01
# Purpose: Emergency close ALL positions
#
# Usage: ./tools/close-all.sh
# ============================================================================

set -e

# Load environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config/.env"

echo "=== EMERGENCY: CLOSE ALL POSITIONS ==="
echo ""
echo "⚠️  This will close ALL open positions immediately!"
echo ""

# Get current positions first
POSITIONS=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions")

POSITION_COUNT=$(echo "$POSITIONS" | jq 'length')

if [ "$POSITION_COUNT" -eq 0 ]; then
    echo "No open positions to close."
    exit 0
fi

echo "Positions to close:"
echo "$POSITIONS" | jq -r '.[] | "  - \(.symbol): \(.qty) shares @ $\(.current_price)"'
echo ""

# Close all positions via DELETE
echo "Executing close-all..."

RESPONSE=$(curl -s -X DELETE \
     -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions")

# Log the action
"$SCRIPT_DIR/log.sh" "ALERT" "EMERGENCY CLOSE-ALL executed - $POSITION_COUNT positions"

echo "Close-all orders submitted."
echo ""

# Wait and check status
sleep 3

# Check remaining positions
REMAINING=$(curl -s -H "APCA-API-KEY-ID: $ALPACA_API_KEY" \
     -H "APCA-API-SECRET-KEY: $ALPACA_SECRET_KEY" \
     "${ALPACA_BASE_URL}/v2/positions")

REMAINING_COUNT=$(echo "$REMAINING" | jq 'length')

echo "=== CLOSE-ALL RESULT ==="
echo ""
echo "Positions before: $POSITION_COUNT"
echo "Positions after: $REMAINING_COUNT"
echo ""

if [ "$REMAINING_COUNT" -eq 0 ]; then
    echo "✅ ALL POSITIONS CLOSED"
else
    echo "⚠️  Some positions may still be pending closure"
    echo "Check ./tools/portfolio.sh in a moment"
fi
